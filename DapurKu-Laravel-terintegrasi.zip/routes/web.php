<?php

use App\Http\Controllers\Admin\ActivityLogController as AdminLog;
use App\Http\Controllers\Admin\BannerController as AdminBanner;
use App\Http\Controllers\Admin\CategoryController as AdminCategory;
use App\Http\Controllers\Admin\CommentController as AdminComment;
use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Admin\IngredientController as AdminIngredient;
use App\Http\Controllers\Admin\MessageController as AdminMessage;
use App\Http\Controllers\Admin\RecipeController as AdminRecipe;
use App\Http\Controllers\Admin\ReportController as AdminReport;
use App\Http\Controllers\Admin\ReviewController as AdminReview;
use App\Http\Controllers\Admin\SettingController as AdminSetting;
use App\Http\Controllers\Admin\StatisticsController as AdminStatistics;
use App\Http\Controllers\Admin\UserController as AdminUser;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\CommunityController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\SearchController;
use Illuminate\Support\Facades\Route;

/* ---------- publik ---------- */
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/resep', [RecipeController::class, 'index'])->name('recipes.index');
Route::get('/resep/cari', [RecipeController::class, 'search'])->name('recipes.search');
Route::get('/resep/semua-kategori', [RecipeController::class, 'allCategories'])->name('recipes.allCategories');
Route::get('/resep/semua-daerah', [RecipeController::class, 'allRegions'])->name('recipes.allRegions');
Route::get('/resep/terpopuler', [RecipeController::class, 'popular'])->name('recipes.popular');
Route::get('/resep/terbaru', [RecipeController::class, 'latest'])->name('recipes.latest');
Route::get('/resep/resep-harian', [RecipeController::class, 'daily'])->name('recipes.daily');
Route::get('/resep/roulette', [RecipeController::class, 'roulette'])->name('recipes.roulette');
Route::get('/resep/alergi', [RecipeController::class, 'allergy'])->name('recipes.allergy');
Route::get('/resep/rating-tertinggi', [RecipeController::class, 'topRated'])->name('recipes.topRated');
Route::get('/resep/resep-mudah', [RecipeController::class, 'easy'])->name('recipes.easy');
Route::get('/resep/kategori/{slug}', [RecipeController::class, 'category'])->name('recipes.category');
Route::get('/resep/daerah/{slug}', [RecipeController::class, 'region'])->name('recipes.region');
Route::get('/bahan', [RecipeController::class, 'ingredients'])->name('ingredients.index');
Route::get('/bahan/{slug}', [RecipeController::class, 'byIngredient'])->name('ingredients.show');

/* Detail resep paling akhir agar tidak menelan rute di atas. */
Route::get('/resep/{slug}', [RecipeController::class, 'show'])->name('recipes.show');

/* ---------- auth ---------- */
Route::get('/masuk', [AuthController::class, 'showLogin'])->name('login');
Route::post('/masuk', [AuthController::class, 'login']);
Route::get('/daftar', [AuthController::class, 'showRegister'])->name('register');
Route::post('/daftar', [AuthController::class, 'register']);
Route::post('/keluar', [AuthController::class, 'logout'])->name('logout');

/* ---------- api ringan (JSON) ---------- */
Route::get('/api/cari', [SearchController::class, 'index'])->name('api.search');
Route::post('/api/favorit', [FavoriteController::class, 'toggle'])->name('favorites.toggle')->middleware('auth');
Route::post('/api/nilai', [RatingController::class, 'store'])->name('ratings.store')->middleware('auth');

/* ---------- halaman statis & komunitas ---------- */
Route::get('/perjalanan-dapur', [PageController::class, 'perjalanan'])->name('pages.perjalanan');
Route::get('/tentang', [PageController::class, 'tentang'])->name('pages.tentang');
Route::get('/kebijakan-privasi', [PageController::class, 'privasi'])->name('pages.privasi');
Route::get('/syarat-ketentuan', [PageController::class, 'syarat'])->name('pages.syarat');
Route::get('/kontak', [PageController::class, 'kontak'])->name('pages.kontak');
Route::post('/kontak', [PageController::class, 'storeContact']);
Route::get('/komunitas', [CommunityController::class, 'index'])->name('community.index');
Route::post('/komunitas', [CommunityController::class, 'store'])->name('community.store')->middleware('auth');

/* ---------- pengguna masuk ---------- */
Route::middleware('auth')->group(function () {
    Route::get('/favorit', [FavoriteController::class, 'index'])->name('favorites.index');
    Route::post('/resep/{slug}/ulasan', [ReviewController::class, 'store'])->name('reviews.store');
    Route::post('/resep/{slug}/komentar', [CommentController::class, 'store'])->name('comments.store');
});

/* ---------- admin ---------- */
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminDashboard::class, 'index'])->name('dashboard');

    /* --- Utama --- */
    Route::resource('resep', AdminRecipe::class)->parameters(['resep' => 'recipe'])->except('show');
    Route::resource('kategori', AdminCategory::class)->parameters(['kategori' => 'category'])->except('show');
    Route::resource('bahan', AdminIngredient::class)->parameters(['bahan' => 'bahan'])->except('show');

    /* --- Komunitas --- */
    Route::get('pengguna', [AdminUser::class, 'index'])->name('pengguna.index');
    Route::patch('pengguna/{pengguna}', [AdminUser::class, 'update'])->name('pengguna.update');
    Route::delete('pengguna/{pengguna}', [AdminUser::class, 'destroy'])->name('pengguna.destroy');

    Route::get('ulasan', [AdminReview::class, 'index'])->name('ulasan.index');
    Route::patch('ulasan/{ulasan}', [AdminReview::class, 'update'])->name('ulasan.update');
    Route::delete('ulasan/{ulasan}', [AdminReview::class, 'destroy'])->name('ulasan.destroy');

    Route::get('komentar', [AdminComment::class, 'index'])->name('komentar.index');
    Route::patch('komentar/{komentar}', [AdminComment::class, 'update'])->name('komentar.update');
    Route::delete('komentar/{komentar}', [AdminComment::class, 'destroy'])->name('komentar.destroy');

    Route::get('laporan', [AdminReport::class, 'index'])->name('laporan.index');
    Route::patch('laporan/{laporan}', [AdminReport::class, 'update'])->name('laporan.update');
    Route::post('laporan/{laporan}/takedown', [AdminReport::class, 'takedown'])->name('laporan.takedown');
    Route::delete('laporan/{laporan}', [AdminReport::class, 'destroy'])->name('laporan.destroy');

    Route::get('pesan', [AdminMessage::class, 'index'])->name('pesan.index');
    Route::get('pesan/{pesan}', [AdminMessage::class, 'show'])->name('pesan.show');
    Route::post('pesan/{pesan}/balas', [AdminMessage::class, 'reply'])->name('pesan.reply');
    Route::patch('pesan/{pesan}/baca', [AdminMessage::class, 'toggleRead'])->name('pesan.read');
    Route::delete('pesan/{pesan}', [AdminMessage::class, 'destroy'])->name('pesan.destroy');

    /* --- Situs --- */
    Route::patch('banner/{banner}/toggle', [AdminBanner::class, 'toggle'])->name('banner.toggle');
    Route::resource('banner', AdminBanner::class)->except('show');

    Route::get('statistik', [AdminStatistics::class, 'index'])->name('statistik');
    Route::get('pengaturan', [AdminSetting::class, 'index'])->name('pengaturan.index');
    Route::put('pengaturan', [AdminSetting::class, 'update'])->name('pengaturan.update');
    Route::get('log', [AdminLog::class, 'index'])->name('log.index');
    Route::post('log/bersihkan', [AdminLog::class, 'clear'])->name('log.clear');
});
