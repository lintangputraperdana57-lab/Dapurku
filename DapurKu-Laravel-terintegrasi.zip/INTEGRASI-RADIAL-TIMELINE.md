# Integrasi Radial Orbital Timeline ke DapurKu-Laravel

Komponen `RadialOrbitalTimeline` (React + shadcn/ui) sudah diintegrasikan ke
project Laravel ini dan bisa dibuka di rute **`/perjalanan-dapur`**
(menu navbar → **Perjalanan dapur**).

> Preview langsung tanpa PHP: jalankan `npm run dev`, lalu buka
> `http://localhost:5173/timeline-preview.html`
> (file `timeline-preview.html` di root — khusus preview Vite, tidak dipakai produksi).

---

## 1. Hasil analisis codebase (sebelum integrasi)

| Kebutuhan task | Kondisi awal DapurKu-Laravel | Status |
|---|---|---|
| Struktur shadcn | Tidak ada (`components.json`, `components/ui/`, `lib/utils` tidak ada) | ❌ → dibuatkan |
| Tailwind CSS | Ada, **Tailwind v4** via `@tailwindcss/vite` (`resources/css/app.css`) | ✅ (dipakai ulang) |
| TypeScript | Tidak ada (`tsconfig.json` tidak ada, entry JS polos) | ❌ → dibuatkan |
| React | Tidak ada (hanya Blade + JS vanilla di `public/assets/js/`) | ❌ → ditambahkan via Vite |
| Path komponen default | Belum ada folder komponen sama sekali | ❌ → dibuatkan (lihat §3) |

Kesimpulan: project **belum** mendukung shadcn + TypeScript + React, jadi
setup dilakukan manual mengikuti pola resmi shadcn untuk Tailwind v4,
disesuaikan dengan struktur Laravel (bukan Next.js).

---

## 2. Instruksi setup (untuk project baru via shadcn CLI)

Kalau ini project Next.js/Vite React kosong, setup resminya:

```bash
# 1. Buat project (pilih TypeScript + Tailwind saat ditanya)
npx create-next-app@latest my-app --typescript --tailwind --eslint

# 2. Inisialisasi shadcn (akan membuat components.json, lib/utils, globals.css)
npx shadcn@latest init

# 3. Tambah komponen yang dibutuhkan
npx shadcn@latest add badge button card

# 4. Install dependency komponen ini
npm install lucide-react class-variance-authority @radix-ui/react-slot
```

Untuk **Laravel + Vite** (kasus DapurKu), CLI shadcn tidak bisa dipakai
langsung karena ia mengasumsikan struktur Next.js. Yang dilakukan di sini
adalah ekuivalen manualnya:

1. Install React + TypeScript + plugin React untuk Vite:
   `npm i -S react react-dom lucide-react class-variance-authority @radix-ui/react-slot clsx tailwind-merge`
   `npm i -D @vitejs/plugin-react typescript @types/react @types/react-dom tw-animate-css`
2. Buat `tsconfig.json` (+ `tsconfig.node.json`) dengan path alias `@/*`.
3. Buat `components.json` (konfigurasi shadcn) yang menunjuk ke
   `resources/css/app.css` dan `resources/js/...`.
4. Tambah plugin `react()` di `vite.config.js` dan ganti input JS menjadi
   `resources/js/app.tsx`.
5. Tambah variabel tema shadcn ke `resources/css/app.css` (gaya Tailwind v4).
6. Copy-paste komponen ke folder `components/ui/` (lihat §3).

---

## 3. Path default komponen & kenapa folder `components/ui` penting

**Path default shadcn adalah `/components/ui`** (dari root project Next.js).
Di Laravel, ekuivalennya adalah **`resources/js/components/ui/`** — semua
import di komponen memakai alias `@/components/ui/...` yang dipetakan ke
folder tersebut lewat `paths` di `tsconfig.json`:

```json
"paths": { "@/*": ["./resources/js/*"] }
```

Kenapa folder `components/ui` penting dibuat terpisah:

1. **Kontrak CLI shadcn** — `npx shadcn add` selalu menaruh komponen di
   `components/ui` sesuai `components.json`. Kalau foldernya beda, CLI
   gagal / import-nya pecah.
2. **Konsistensi import** — semua komponen shadcn saling mengimpor lewat
   `@/components/ui/...` dan `@/lib/utils`. Satu lokasi = tidak ada import
   relatif yang rapuh (`../../ui/button`).
3. **Pemisahan tanggung jawab** — `ui/` hanya berisi komponen dasar
   (badge, button, card, timeline) yang bisa dipakai ulang di mana saja;
   logika halaman tinggal di `pages/` atau `components/` biasa.
4. **Mudah di-upgrade** — komponen shadcn bisa ditimpa ulang dari CLI
   tanpa menyentuh kode halaman.

Struktur yang dibuat:

```
resources/js/
├── app.tsx                              # entry React (mount #react-timeline)
├── lib/
│   └── utils.ts                         # helper cn() (clsx + tailwind-merge)
├── components/
│   ├── ui/
│   │   ├── badge.tsx                    # shadcn/badge (copy-paste)
│   │   ├── button.tsx                   # shadcn/button (copy-paste)
│   │   ├── card.tsx                     # shadcn/card (copy-paste)
│   │   └── radial-orbital-timeline.tsx  # komponen utama (copy-paste)
│   └── timeline-demo.tsx                # data demo (disesuaikan DapurKu)
└── pages/
    └── TimelinePage.tsx                 # halaman React untuk /perjalanan-dapur
```

---

## 4. Analisis komponen: props, state, hooks, dependensi

### Props (satu-satunya input)

```ts
interface TimelineItem {
  id: number;            // id unik node
  title: string;         // label di bawah node
  date: string;          // teks bebas (di demo asli: "Jan 2024"; di DapurKu: "10 mnt")
  content: string;       // isi kartu detail saat node diklik
  category: string;      // kategori bebas
  icon: React.ElementType; // komponen ikon lucide (mis. Calendar, Flame)
  relatedIds: number[];  // id node yang terhubung (untuk efek pulse + tombol "Connected Nodes")
  status: "completed" | "in-progress" | "pending";
  energy: number;        // 0–100, mengatur ukuran glow & bar energi
}
interface RadialOrbitalTimelineProps { timelineData: TimelineItem[] }
```

### State lokal (semua `useState`, tanpa store global)

| State | Fungsi |
|---|---|
| `expandedItems` | Node mana yang sedang terbuka (kartu detail) |
| `rotationAngle` | Sudut putaran orbit (di-animasi `setInterval` 50ms) |
| `autoRotate` | Putaran otomatis berhenti saat node diklik |
| `pulseEffect` | Node terkait node aktif ikut berdenyut |
| `activeNodeId` | Node yang sedang aktif |
| `centerOffset`, `viewMode` | Offset pusat & mode tampilan (bawaan, tidak diubah) |

### Hooks & dependensi

- Hooks: `useState`, `useEffect` (timer rotasi), `useRef` (container, orbit, node).
- **Tidak ada** context provider, router, atau state management eksternal —
  komponen murni presentasional + state lokal. Aman dipakai di mana saja.
- Dependensi npm: `lucide-react` (ikon), `class-variance-authority` +
  `@radix-ui/react-slot` (button), `clsx` + `tailwind-merge` (helper `cn`).
- Dependensi internal: `@/components/ui/badge`, `@/components/ui/button`,
  `@/components/ui/card`, `@/lib/utils`.

### Penyesuaian kecil dari kode asli (agar lolos TypeScript + React 19)

1. `import * as React from "react"` ditambahkan (dibutuhkan untuk tipe
   `React.ElementType` / `React.MouseEvent` pada JSX transform baru).
2. `NodeJS.Timeout` → `ReturnType<typeof setInterval>` (project browser
   tidak punya `@types/node`).
3. Ref callback ditulis sebagai blok `{ ... }` (React 19 mewajibkan ref
   callback mengembalikan `void`, bukan nilai assignment).

Selain itu komponen **disalin persis** seperti aslinya.

---

## 5. Jawaban pertanyaan implementasi

- **Data/props apa yang diberikan?**
  Satu array `timelineData: TimelineItem[]`. Di DapurKu isinya alur masak
  rendang (Persiapan → Bumbu Halus → Tumis Bumbu → Masak Santan →
  Koreksi Rasa → Plating) dengan ikon lucide dan durasi sebagai `date`.
  Data demo asli (Planning/Design/Development/Testing/Release) diganti
  agar nyambung dengan konteks aplikasi resep — strukturnya identik.
- **Butuh state management khusus?** Tidak. Semua state lokal di dalam
  komponen. Kalau nanti datanya mau diambil dari database Laravel, cukup
  kirim JSON lewat Blade (`@json(...)`) ke komponen React.
- **Butuh aset gambar?** Tidak. Komponen ini 100% ikon + CSS (tidak ada
  `<img>`), jadi **tidak perlu Unsplash**. Semua ikon memakai `lucide-react`
  (`ShoppingBasket`, `ChefHat`, `Flame`, `CookingPot`, `Scale`,
  `UtensilsCrossed`). Kalau ingin foto makanan di kartu detail, tambahkan
  field `image` sendiri dan render `<img>` di `CardContent`.
- **Perilaku responsif?** Radius orbit bawaan adalah 200px (diameter 400px),
  sehingga di layar < 400px node akan terpotong. Di `TimelinePage` sudah
  ditangani dengan wrapper `scale-[0.55] sm:scale-75 md:scale-90 xl:scale-100`.
  Alternatif lanjutan: hitung radius dari lebar container via
  `ResizeObserver` di dalam `calculateNodePosition`.
- **Tempat terbaik memakai komponen ini?**
  1. Halaman khusus **`/perjalanan-dapur`** (sudah dibuat — layar penuh gelap,
     cocok untuk visualisasi imersif seperti ini).
  2. Nanti bisa dipakai ulang di halaman detail resep sebagai
     "timeline langkah masak" dengan data dari `recipe_steps`.
  3. Atau sebagai section di beranda (perlu membungkus dengan tinggi
     tetap karena komponen memakai `h-screen`).

---

## 6. `globals.css` (di Laravel: `resources/css/app.css`)

Blok CSS dari task sudah ditambahkan di akhir file. Catatan penting:
project ini memakai **Tailwind v4**, yang sebenarnya **sudah menyediakan**
hampir semua utilitas di blok tersebut (`animate-pulse`, `animate-ping`,
`backdrop-blur-lg`, `scale-125/150`, `opacity-*`, `border-white/*`, dsb.)
— jadi blok itu aman diduplikasi tanpa mengubah tampilan. Yang benar-benar
kustom dan dipertahankan adalah `.bg-gradient-orbital` dan `.shadow-orbital`.

Selain itu file CSS dilengkapi variabel tema shadcn untuk Tailwind v4
(`:root`, `.dark`, `@theme inline`, `@custom-variant dark`) agar kelas
seperti `bg-primary`, `text-card-foreground`, `ring-ring` pada
badge/button/card berfungsi. Halaman timeline memakai `class="dark"` di
`<html>` supaya tema gelap aktif.

---

## 7. Langkah integrasi yang sudah dikerjakan

1. ✅ Install dependency (React 19, lucide-react, class-variance-authority,
   @radix-ui/react-slot, clsx, tailwind-merge, @vitejs/plugin-react,
   typescript, @types/react(-dom), tw-animate-css).
2. ✅ Buat `tsconfig.json`, `tsconfig.node.json`, `components.json`.
3. ✅ Update `vite.config.js` (plugin React + input `app.tsx` + `allowedHosts`).
4. ✅ Update `resources/css/app.css` (tema shadcn v4 + CSS orbital).
5. ✅ Copy-paste `badge.tsx`, `button.tsx`, `card.tsx`,
   `radial-orbital-timeline.tsx` ke `resources/js/components/ui/`.
6. ✅ Buat `resources/js/lib/utils.ts` (helper `cn`).
7. ✅ Buat demo DapurKu (`timeline-demo.tsx`), halaman (`TimelinePage.tsx`),
   dan entry (`app.tsx`).
8. ✅ Sisi Laravel: method `PageController::perjalanan()`, route
   `GET /perjalanan-dapur` (nama `pages.perjalanan`), view standalone
   `resources/views/timeline.blade.php`, dan link menu navbar
   "Perjalanan dapur" (ikon `compass`).
9. ✅ Verifikasi: `npm run build` sukses, `npx tsc --noEmit` bersih,
   semua modul ter-serve Vite tanpa error.

Halaman Blade dibuat **standalone** (tidak memakai `layouts/app`) karena
komponen React butuh layar penuh gelap tanpa navbar/footer Blade yang
terbatas lebar container. Halaman lain tidak terpengaruh sama sekali
(`app.css` Vite hanya dimuat di halaman ini).

---

## 8. Cara menjalankan

Di Laragon / terminal lokal (butuh Node 20+):

```bash
cd DapurKu-Laravel
npm install          # jika node_modules belum ada
npm run dev          # Vite (HMR) — terminal 1
php artisan serve    # Laravel — terminal 2
```

Buka `http://localhost:8000/perjalanan-dapur` (atau port sesuai
`php artisan serve`). Untuk produksi:

```bash
npm run build        # hasil ke public/build/, dimuat otomatis oleh @vite
```

Cek tipe kapan saja dengan `npx tsc --noEmit`.

---

## 9. Kustomisasi & pemakaian ulang

- **Ganti data:** edit array `timelineData` di
  `resources/js/components/timeline-demo.tsx`. `relatedIds` harus merujuk
  ke `id` yang ada; `status` hanya tiga nilai di atas; `energy` 0–100.
- **Ambil dari database:** buat JSON di controller, lalu di Blade:
  `<script>window.TIMELINE = @json($items);</script>` dan baca di React.
- **Pakai di halaman React lain:** impor langsung
  `import RadialOrbitalTimeline from "@/components/ui/radial-orbital-timeline"`
  lalu `<RadialOrbitalTimeline timelineData={data} />`.
- **Tambah komponen shadcn lain:** taruh di `resources/js/components/ui/`
  dengan import `@/lib/utils` — pola yang sama seperti badge/button/card.
