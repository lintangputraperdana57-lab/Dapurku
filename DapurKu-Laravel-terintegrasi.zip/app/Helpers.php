<?php

declare(strict_types=1);

/**
 * Helper global DapurKu-Laravel — ikon SVG, format, dan path gambar.
 */

use Illuminate\Support\Str;

/** @return array<string,string> nama ikon => isi SVG */
function dk_icons(): array
{
    static $icons = null;
    if ($icons !== null) {
        return $icons;
    }

    $icons = [
        // ---- navigasi / dapur ----
        'home' => '<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6 9.6V20h12V9.6"/><path class="nv-door" d="M10 20v-5h4v5Z"/>',
        'pot' => '<path d="M4 10h16"/><path d="M5 10v6.5A3.5 3.5 0 0 0 8.5 20h7a3.5 3.5 0 0 0 3.5-3.5V10"/><path d="M3 10h18"/><path d="M8.5 6.8c0-1.4 1.6-1.5 1.6-2.9"/><path d="M13.4 6.8c0-1.4 1.6-1.5 1.6-2.9"/>',
        'globe' => '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.4 2.6 14.6 0 17M12 3.5c-2.6 2.4-2.6 14.6 0 17"/>',
        'map' => '<path d="m9 4.5-5.2 2v13L9 17.5l6 2 5.2-2v-13L15 6.5 9 4.5Z"/><path d="M9 4.5v13M15 6.5v13"/>',
        'bookmark' => '<path d="M6.5 3.8h11a1 1 0 0 1 1 1v15.4l-6.5-4-6.5 4V4.8a1 1 0 0 1 1-1Z"/>',
        'star' => '<path d="m12 3.6 2.6 5.4 5.9.8-4.3 4.1 1.1 5.9-5.3-2.9-5.3 2.9 1.1-5.9L3.5 9.8l5.9-.8L12 3.6Z"/>',
        'flame' => '<path d="M12 21c3.9 0 6.5-2.5 6.5-6 0-4.4-4.3-6.3-3.6-11.5-2.9 1-4.7 3.7-4.7 6 0 1.3.5 2.2.5 3 0 1-.8 1.8-1.8 1.8-1.2 0-2-1-2-2.6C5.7 13.2 5.5 14.3 5.5 15c0 3.5 2.6 6 6.5 6Z"/>',
        'leaf' => '<path d="M4.5 19.5C3 15 5 8.5 11 6.2c3-1.1 6.2-1 8.5-1.2.3 3-.1 6.4-1.5 9-2.4 4.4-7.6 6.2-11.5 4.6"/><path d="M4.5 19.5C7 15.5 10.5 12 15.5 9.5"/>',
        'dice' => '<rect x="3.8" y="3.8" width="16.4" height="16.4" rx="4"/><circle cx="9" cy="9" r="1.25" fill="currentColor" stroke="none"/><circle cx="15" cy="15" r="1.25" fill="currentColor" stroke="none"/><circle cx="15" cy="9" r="1.25" fill="currentColor" stroke="none"/><circle cx="9" cy="15" r="1.25" fill="currentColor" stroke="none"/>',
        'chef' => '<path d="M6.5 13.5a4 4 0 1 1 1.9-7.5 4 4 0 0 1 7.2 0 4 4 0 1 1 1.9 7.5"/><path d="M7 13.5v4.2h10v-4.2"/><path d="M7 20.2h10"/>',
        'basket' => '<path d="M3.5 9.5h17l-1.7 9.2a2 2 0 0 1-2 1.6H7.2a2 2 0 0 1-2-1.6L3.5 9.5Z"/><path d="m8.5 9.5 2-5.8M15.5 9.5l-2-5.8"/>',
        'search' => '<circle cx="11" cy="11" r="6.6"/><path d="m16 16 4.4 4.4"/>',
        'heart' => '<path d="M12 20.3 4.9 13.5a4.3 4.3 0 0 1 6.1-6l1 1 1-1a4.3 4.3 0 0 1 6.1 6L12 20.3Z"/>',
        'user' => '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.8 20c1.2-3.4 4-5 7.2-5s6 1.6 7.2 5"/>',
        'clock' => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.4V12l3.2 2"/>',
        'eye' => '<path d="M2.6 12S6 5.9 12 5.9 21.4 12 21.4 12 18 18.1 12 18.1 2.6 12 2.6 12Z"/><circle cx="12" cy="12" r="2.9"/>',
        'chart' => '<path d="M4 20V9.5M10 20V4.5M16 20v-7M22 20H2"/>',
        'shield' => '<path d="M12 3.2 5 6v6c0 4.3 3 7.4 7 8.8 4-1.4 7-4.5 7-8.8V6l-7-2.8Z"/><path d="m9.2 12 2 2 3.6-3.8"/>',
        'bell' => '<path d="M6.5 10a5.5 5.5 0 0 1 11 0c0 4 1.5 5.5 1.5 5.5H5S6.5 14 6.5 10Z"/><path d="M10 18.5a2 2 0 0 0 4 0"/>',
        'grid' => '<rect x="3.8" y="3.8" width="7" height="7" rx="2"/><rect x="13.2" y="3.8" width="7" height="7" rx="2"/><rect x="3.8" y="13.2" width="7" height="7" rx="2"/><rect x="13.2" y="13.2" width="7" height="7" rx="2"/>',
        'layers' => '<path d="m12 3.5 8.5 4.3L12 12 3.5 7.8 12 3.5Z"/><path d="m3.5 12.2 8.5 4.3 8.5-4.3"/><path d="m3.5 16.4 8.5 4.3 8.5-4.3"/>',
        'compass' => '<circle cx="12" cy="12" r="8.6"/><path d="m14.9 9.1-1.7 4.1-4.1 1.7 1.7-4.1 4.1-1.7Z"/>',
        'logout' => '<path d="M14.5 4.5H6.8a1.8 1.8 0 0 0-1.8 1.8v11.4a1.8 1.8 0 0 0 1.8 1.8h7.7"/><path d="m17 8.5 3.5 3.5L17 15.5"/><path d="M20.5 12H10"/>',
        'sun' => '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M18.5 5.5l-1.7 1.7M7.2 16.8l-1.7 1.7"/>',
        'moon' => '<path d="M20 14.4A8.4 8.4 0 0 1 9.6 4a8.5 8.5 0 1 0 10.4 10.4Z"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'close' => '<path d="m5.5 5.5 13 13M18.5 5.5l-13 13"/>',
        'chevron-down' => '<path d="m6 9.5 6 6 6-6"/>',
        'chevron-right' => '<path d="m9.5 6 6 6-6 6"/>',
        'chevron-left' => '<path d="m14.5 6-6 6 6 6"/>',
        'arrow-right' => '<path d="M4.5 12h15M13.5 6l6 6-6 6"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'check' => '<path d="m4.8 12.6 4.6 4.6L19.2 7.4"/>',
        'edit' => '<path d="M4.5 19.5h4L20 8a2.5 2.5 0 0 0-3.5-3.5L5 16v3.5Z"/><path d="m14.5 6.5 3 3"/>',
        'trash' => '<path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l1 12.2a1.8 1.8 0 0 0 1.8 1.6h5.4a1.8 1.8 0 0 0 1.8-1.6L17.5 7"/>',
        'mail' => '<rect x="3" y="5.5" width="18" height="13" rx="2.4"/><path d="m3.8 7 8.2 6 8.2-6"/>',
        'info' => '<circle cx="12" cy="12" r="8.6"/><path d="M12 11v5.4"/><circle cx="12" cy="8" r="1.05" fill="currentColor" stroke="none"/>',
        'sparkle' => '<path d="M12 3.5 13.7 9l5.5 1.7-5.5 1.7L12 18l-1.7-5.6L4.8 10.7 10.3 9 12 3.5Z"/><path d="M18.6 16.4l.7 2.1 2.1.7-2.1.7-.7 2.1-.7-2.1-2.1-.7 2.1-.7.7-2.1Z"/>',
        'users' => '<circle cx="9.4" cy="8.4" r="3.4"/><path d="M3.2 19.6c.9-3 3.2-4.6 6.2-4.6s5.3 1.6 6.2 4.6"/><path d="M16.2 5.4a3.4 3.4 0 0 1 0 6.6M17.6 15.4c2 .5 3.3 1.9 3.9 4.2"/>',
        'doc' => '<path d="M6.5 3.8h7L18.5 9v11.2a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1V4.8a1 1 0 0 1 1-1Z"/><path d="M13.2 3.8V9h5.3"/><path d="M8.8 13h6.4M8.8 16.4h6.4"/>',
        'scale' => '<path d="M12 4.2v15.6M7.4 19.8h9.2M4.6 8.2h14.8"/><path d="m4.6 8.2-2.4 5a2.8 2.8 0 0 0 4.8 0l-2.4-5ZM19.4 8.2 17 13.2a2.8 2.8 0 0 0 4.8 0l-2.4-5Z"/>',
        'drop' => '<path d="M12 3.5s6 6.4 6 10.6a6 6 0 0 1-12 0C6 9.9 12 3.5 12 3.5Z"/>',
        'wheel' => '<circle cx="12" cy="12" r="8.6"/><circle cx="12" cy="12" r="2.4"/><path d="M12 3.4v6.2M12 14.4v6.2M3.4 12h6.2M14.4 12h6.2"/>',
    ];

    return $icons;
}

/**
 * Kembalikan string SVG untuk sebuah ikon.
 *
 * @param string $name  nama ikon (lihat dk_icons())
 * @param int    $size  lebar/tinggi dalam px
 * @param string $class kelas CSS tambahan
 */
function dk_icon(string $name, int $size = 18, string $class = ''): string
{
    $body = dk_icons()[$name] ?? dk_icons()['sparkle'];
    $cls = trim('dk-icon ' . $class);

    return '<svg class="' . e($cls) . '" viewBox="0 0 24 24" width="' . $size
        . '" height="' . $size . '" fill="none" stroke="currentColor" stroke-width="1.8" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
        . $body . '</svg>';
}


/** Nama ikon per level kesulitan resep. */
function dk_difficulty_icon(?string $difficulty): string
{
    return match ($difficulty) {
        'mudah' => 'leaf',
        'sedang' => 'flame',
        'sulit' => 'chef',
        default => 'pot',
    };
}

function format_minutes(?int $m): string
{
    $m = (int) $m;
    if ($m < 60) {
        return $m . ' menit';
    }
    $h = intdiv($m, 60);
    $r = $m % 60;

    return $r ? "{$h} jam {$r} menit" : "{$h} jam";
}

function format_number(int|float $n): string
{
    return number_format((float) $n, 0, ',', '.');
}

function difficulty_label(?string $d): string
{
    return match ($d) {
        'mudah' => 'Mudah',
        'sedang' => 'Sedang',
        'sulit' => 'Sulit',
        default => ucfirst((string) $d),
    };
}

function excerpt_text(?string $text, int $len = 140): string
{
    return Str::limit(trim(strip_tags((string) $text)), $len, '…');
}

/** URL gambar resep (berkas lokal di public/uploads). */
function recipe_image(?string $path): string
{
    if (!$path) {
        return asset('assets/images/placeholder.svg');
    }
    if (str_starts_with($path, 'http')) {
        return $path;
    }

    return url('uploads/' . ltrim($path, '/'));
}

/** Peta slug => label daerah Nusantara. */
function region_labels(): array
{
    return [
        'sumatera' => 'Sumatera',
        'jawa' => 'Jawa',
        'bali-nusa' => 'Bali & Nusa Tenggara',
        'kalimantan' => 'Kalimantan',
        'sulawesi' => 'Sulawesi',
        'maluku-papua' => 'Maluku & Papua',
    ];
}

/** Ambil nilai pengaturan situs (tabel settings) dengan nilai cadangan. */
function setting(string $key, ?string $default = null): ?string
{
    return \App\Models\Setting::get($key, $default);
}

/**
 * Catat aksi admin/pengguna ke tabel activity_logs.
 * Tidak pernah melempar error agar alur utama tetap jalan.
 *
 * @param array<string,mixed> $meta
 */
function admin_log(string $action, array $meta = []): void
{
    try {
        \App\Models\ActivityLog::create([
            'user_id' => auth()->id(),
            'action' => $action,
            'meta' => $meta === [] ? null : $meta,
        ]);
    } catch (\Throwable) {
        // diamkan: log tidak boleh mengganggu permintaan pengguna
    }
}

/** Kelas CSS badge untuk sebuah status konten. */
function status_class(?string $status): string
{
    return 'status status-' . preg_replace('/[^a-z0-9]+/', '-', strtolower((string) $status));
}

/** Label status konten dalam bahasa Indonesia. */
function status_label(?string $status): string
{
    return match ($status) {
        'published' => 'Terbit',
        'draft' => 'Draft',
        'arsip' => 'Arsip',
        'approved' => 'Disetujui',
        'pending' => 'Menunggu',
        'rejected' => 'Ditolak',
        'open' => 'Terbuka',
        'resolved' => 'Selesai',
        'dismissed' => 'Diabaikan',
        'active' => 'Aktif',
        'banned' => 'Diblokir',
        'admin' => 'Admin',
        'moderator' => 'Moderator',
        'user' => 'Pengguna',
        default => ucfirst((string) $status),
    };
}
