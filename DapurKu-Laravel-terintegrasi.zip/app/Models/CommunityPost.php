<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommunityPost extends Model
{
    public $timestamps = true;

    /** Tabel warisan hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['user_id', 'recipe_id', 'title', 'body'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function recipe()
    {
        return $this->belongsTo(Recipe::class);
    }
}
