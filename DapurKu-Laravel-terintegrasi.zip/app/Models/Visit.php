<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Visit extends Model
{
    public $timestamps = true;

    /** Tabel warisan hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['path', 'ip'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }
}
