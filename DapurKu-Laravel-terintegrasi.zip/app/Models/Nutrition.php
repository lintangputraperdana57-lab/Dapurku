<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nutrition extends Model
{
    public $timestamps = false;

    protected $table = 'recipe_nutrition';
    protected $primaryKey = 'recipe_id';
    public $incrementing = false;

    protected $fillable = ['recipe_id', 'protein', 'fat', 'carbs', 'fiber'];
}
