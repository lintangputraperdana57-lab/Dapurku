<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    protected $fillable = ['name', 'slug', 'description', 'unit'];

    public function recipes()
    {
        return $this->hasMany(RecipeIngredient::class);
    }
}
