<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    public $timestamps = true;

    /** Tabel log hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['user_id', 'action', 'meta'];

    protected function casts(): array
    {
        return [
            'created_at' => 'datetime',
            'meta' => 'array',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /** Label manusiawi dari sebuah aksi, mis. "resep.hapus" => "Resep · hapus". */
    public function actionLabel(): string
    {
        [$group, $verb] = array_pad(explode('.', (string) $this->action, 2), 2, '');

        return ucfirst($group) . ($verb !== '' ? ' · ' . str_replace('-', ' ', $verb) : '');
    }
}
