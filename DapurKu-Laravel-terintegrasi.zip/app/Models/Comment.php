<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    public $timestamps = true;

    /** Tabel warisan hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['user_id', 'recipe_id', 'parent_id', 'body', 'status'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function recipe()
    {
        return $this->belongsTo(Recipe::class);
    }

    /** Komentar induk (bila ini sebuah balasan). */
    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function replies()
    {
        return $this->hasMany(self::class, 'parent_id');
    }
}
