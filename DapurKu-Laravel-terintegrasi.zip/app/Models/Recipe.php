<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    protected $fillable = [
        'user_id', 'category_id', 'title', 'slug', 'excerpt', 'description',
        'image', 'cook_time', 'prep_time', 'servings', 'difficulty', 'calories',
        'status', 'is_featured', 'views', 'region', 'region_slug',
    ];

    protected function casts(): array
    {
        return [
            'is_featured' => 'boolean',
            'cook_time' => 'integer',
            'prep_time' => 'integer',
            'servings' => 'integer',
            'calories' => 'integer',
            'views' => 'integer',
        ];
    }

    /* ---------- scopes ---------- */

    public function scopePublished(Builder $q): Builder
    {
        return $q->where('status', 'published');
    }

    public function scopeFeatured(Builder $q): Builder
    {
        return $q->where('is_featured', true);
    }

    public function scopeRegion(Builder $q, string $slug): Builder
    {
        return $q->where('region_slug', $slug);
    }

    /* ---------- relasi ---------- */

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function author()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function ingredients()
    {
        return $this->hasMany(RecipeIngredient::class)->orderBy('sort_order');
    }

    public function steps()
    {
        return $this->hasMany(RecipeStep::class)->orderBy('step_number');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class)->where('status', 'approved')->latest();
    }

    public function allReviews()
    {
        return $this->hasMany(Review::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class)->where('status', 'approved')->with('user');
    }

    public function allergens()
    {
        return $this->belongsToMany(Ingredient::class, 'recipe_allergens', 'recipe_id', 'allergen', 'id', 'name');
    }

    public function allergenNames(): array
    {
        return \DB::table('recipe_allergens')->where('recipe_id', $this->id)->pluck('allergen')->all();
    }

    public function nutrition()
    {
        return $this->hasOne(Nutrition::class, 'recipe_id');
    }

    /* ---------- relasi ---------- */

    public function favorites()
    {
        return $this->belongsToMany(User::class, 'favorites')->withPivot('created_at');
    }

    /* ---------- nilai ---------- */

    public function avgRating(): float
    {
        return round((float) $this->allReviews()->avg('rating'), 1);
    }

    public function isFavoritedBy(?int $userId): bool
    {
        if (!$userId) {
            return false;
        }

        return \DB::table('favorites')->where('user_id', $userId)->where('recipe_id', $this->id)->exists();
    }
}
