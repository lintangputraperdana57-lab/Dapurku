<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    public $timestamps = true;

    /** Tabel laporan hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['user_id', 'target_type', 'target_id', 'reason', 'status'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /** Label jenis konten yang dilaporkan. */
    public function targetLabel(): string
    {
        return match ($this->target_type) {
            'recipe' => 'Resep',
            'review' => 'Ulasan',
            'comment' => 'Komentar',
            'user' => 'Pengguna',
            'community_post' => 'Postingan',
            default => ucfirst((string) $this->target_type),
        };
    }

    /** Model asal laporan, null bila kontennya sudah dihapus. */
    public function targetModel(): ?Model
    {
        return match ($this->target_type) {
            'recipe' => Recipe::find($this->target_id),
            'review' => Review::find($this->target_id),
            'comment' => Comment::find($this->target_id),
            'user' => User::find($this->target_id),
            'community_post' => CommunityPost::find($this->target_id),
            default => null,
        };
    }

    /** Ringkasan konten yang dilaporkan untuk ditampilkan di tabel. */
    public function targetSummary(): string
    {
        $model = $this->targetModel();

        return match (true) {
            $model instanceof Recipe => $model->title,
            $model instanceof Review, $model instanceof Comment => excerpt_text($model->body, 80),
            $model instanceof CommunityPost => $model->title,
            $model instanceof User => $model->name . ' · ' . $model->email,
            default => '#' . $this->target_id . ' (tidak ditemukan)',
        };
    }

    public function statusLabel(): string
    {
        return match ($this->status) {
            'open' => 'Terbuka',
            'resolved' => 'Selesai',
            'dismissed' => 'Diabaikan',
            default => ucfirst((string) $this->status),
        };
    }
}
