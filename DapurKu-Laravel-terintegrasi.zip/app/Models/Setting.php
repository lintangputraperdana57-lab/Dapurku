<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $table = 'settings';

    protected $primaryKey = 'key';

    public $incrementing = false;

    protected $keyType = 'string';

    public $timestamps = false;

    protected $fillable = ['key', 'value'];

    /** Cache per-request agar tabel setting tidak dibaca berulang kali. */
    protected static ?array $cache = null;

    /** Semua setting sebagai array key => value. */
    public static function map(): array
    {
        if (static::$cache === null) {
            try {
                static::$cache = static::query()->pluck('value', 'key')->all();
            } catch (\Throwable) {
                static::$cache = [];
            }
        }

        return static::$cache;
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        $value = static::map()[$key] ?? null;

        return ($value === null || $value === '') ? $default : $value;
    }

    public static function put(string $key, ?string $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value === '' ? null : $value]);
        static::$cache = null;
    }

    /** Simpan banyak setting sekaligus. */
    public static function putMany(array $values): void
    {
        foreach ($values as $key => $value) {
            static::put((string) $key, $value === null ? null : (string) $value);
        }
    }
}
