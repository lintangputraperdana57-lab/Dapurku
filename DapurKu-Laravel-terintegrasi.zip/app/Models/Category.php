<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['name', 'slug', 'description', 'image', 'sort_order'];

    public function recipes()
    {
        return $this->hasMany(Recipe::class);
    }
}
