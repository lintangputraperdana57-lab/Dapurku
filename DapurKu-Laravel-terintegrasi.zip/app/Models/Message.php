<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    public $timestamps = true;

    /** Tabel warisan hanya punya created_at (tanpa updated_at). */
    const UPDATED_AT = null;

    protected $fillable = ['name', 'email', 'subject', 'body', 'reply', 'is_read', 'replied_at'];

    protected function casts(): array
    {
        return [
            'created_at' => 'datetime',
            'replied_at' => 'datetime',
            'is_read' => 'boolean',
        ];
    }
}
