<?php

namespace App\Http\Middleware;

use App\Models\Visit;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TrackVisits
{
    /** Catat kunjungan halaman GET (dipakai grafik dasbor admin). */
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->isMethod('GET') && !$request->is('assets/*', 'uploads/*')) {
            Visit::create(['path' => $request->path(), 'ip' => $request->ip()]);
        }

        return $next($request);
    }
}
