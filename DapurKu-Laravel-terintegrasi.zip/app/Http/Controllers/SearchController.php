<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    /** Saran pencarian langsung (JSON) — dipakai search.js. */
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        if (mb_strlen($q) < 2) {
            return response()->json(['items' => []]);
        }

        $items = Recipe::published()
            ->where(fn ($w) => $w->where('title', 'like', "%{$q}%")->orWhere('excerpt', 'like', "%{$q}%"))
            ->orderByDesc('views')->limit(8)->get(['title', 'slug']);

        return response()->json(['items' => $items]);
    }
}
