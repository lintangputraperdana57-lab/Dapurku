<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Recipe;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function store(Request $request, string $slug)
    {
        $recipe = Recipe::where('slug', $slug)->firstOrFail();

        $data = $request->validate(['body' => ['required', 'string', 'max:1000']]);

        Comment::create($data + [
            'user_id' => auth()->id(),
            'recipe_id' => $recipe->id,
            'status' => 'approved',
        ]);

        return back()->with('success', 'Komentar terkirim.');
    }
}
