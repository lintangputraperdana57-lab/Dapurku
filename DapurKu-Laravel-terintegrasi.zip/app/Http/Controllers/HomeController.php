<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use App\Models\Category;
use App\Models\Recipe;

class HomeController extends Controller
{
    public function index()
    {
        $featured = Recipe::with('category')->published()->featured()->orderByDesc('views')->limit(6)->get();
        $latest = Recipe::with('category')->published()->latest()->limit(6)->get();
        $cats = Category::where('sort_order', '<', 20)->orderBy('sort_order')->get();
        $banners = Banner::where('is_active', true)->orderBy('sort_order')->get();

        $counts = [
            'recipes' => Recipe::published()->count(),
            'cats' => Category::count(),
            'regions' => count(region_labels()),
        ];

        $hero = $featured->first() ?? $latest->first();

        return view('home', [
            'featured' => $featured,
            'latest' => $latest,
            'cats' => $cats,
            'banners' => $banners,
            'counts' => $counts,
            'hero' => $hero,
            'conveyor' => $this->conveyorItems(),
            'wheel' => $this->wheelItems(),
        ]);
    }

    /** Piring sabuk konveyor: resep terpopuler. */
    private function conveyorItems(): array
    {
        return Recipe::with('category')->published()
            ->orderByDesc('is_featured')->orderByDesc('views')->limit(9)->get()
            ->map(function (Recipe $r) {
                $details = array_values(array_unique(array_filter([
                    format_minutes($r->cook_time),
                    $r->prep_time ? 'Persiapan ' . format_minutes($r->prep_time) : null,
                    $r->servings ? $r->servings . ' porsi' : null,
                    $r->calories ? format_number($r->calories) . ' kkal' : null,
                    difficulty_label($r->difficulty),
                    $r->category?->name,
                ])));

                return [
                    'id' => 'resep-' . $r->id,
                    'name' => $r->title,
                    'description' => excerpt_text($r->excerpt ?? $r->description, 130),
                    'price' => format_minutes($r->cook_time),
                    'labels' => array_values(array_filter([$r->category?->name, format_minutes($r->cook_time)])),
                    'tier' => $this->tier($r),
                    'image' => recipe_image($r->image),
                    'details' => $details,
                    'href' => route('recipes.show', $r->slug),
                ];
            })->all();
    }

    /** Butir roda kreasi: resep paling dilihat + penulisnya. */
    private function wheelItems(): array
    {
        return Recipe::with('author')->published()->whereNotNull('image')->where('image', '!=', '')
            ->orderByDesc('views')->limit(9)->get()
            ->map(fn (Recipe $r) => [
                'title' => $r->title,
                'image' => recipe_image($r->image),
                'href' => route('recipes.show', $r->slug),
                'meta' => $r->author ? 'oleh ' . $r->author->name : '',
            ])->all();
    }

    /** Tingkat 1–5 dari kesulitan + waktu masak (warna cincin piring). */
    private function tier(Recipe $r): int
    {
        $base = match ($r->difficulty) {
            'mudah' => 1,
            'sedang' => 3,
            'sulit' => 5,
            default => 2,
        };
        if ($base === 1 && $r->cook_time > 45) {
            $base = 2;
        }
        if ($base === 3 && $r->cook_time > 75) {
            $base = 4;
        }

        return max(1, min(5, $base));
    }
}
