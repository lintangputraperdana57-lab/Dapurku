<?php

namespace App\Http\Controllers;

use App\Models\CommunityPost;
use Illuminate\Http\Request;

class CommunityController extends Controller
{
    public function index()
    {
        return view('community.index', [
            'posts' => CommunityPost::with(['user', 'recipe'])->latest()->limit(50)->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'body' => ['required', 'string', 'max:2000'],
            'recipe_id' => ['nullable', 'integer', 'exists:recipes,id'],
        ]);

        CommunityPost::create($data + ['user_id' => auth()->id()]);

        return back()->with('success', 'Cerita terkirim ke komunitas.');
    }
}
