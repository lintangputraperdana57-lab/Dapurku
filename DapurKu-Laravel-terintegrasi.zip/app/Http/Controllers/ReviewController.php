<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use App\Models\Review;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function store(Request $request, string $slug)
    {
        $recipe = Recipe::where('slug', $slug)->firstOrFail();

        $data = $request->validate([
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'body' => ['nullable', 'string', 'max:1000'],
        ]);

        Review::updateOrCreate(
            ['user_id' => auth()->id(), 'recipe_id' => $recipe->id],
            ['rating' => (int) $data['rating'], 'body' => $data['body'] ?? null, 'status' => 'approved'],
        );

        return back()->with('success', 'Ulasan tersimpan. Terima kasih!');
    }
}
