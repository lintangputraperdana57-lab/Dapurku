<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    /** Kunci pengaturan yang boleh diubah dari panel. */
    private const KEYS = [
        'site_name', 'tagline', 'contact_email', 'contact_phone',
        'instagram', 'footer_note', 'items_per_page',
    ];

    public function index()
    {
        return view('admin.settings', [
            'values' => collect(self::KEYS)->mapWithKeys(fn ($k) => [$k => Setting::get($k)])->all(),
            'maintenance' => Setting::get('maintenance', '0') === '1',
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'site_name' => ['required', 'string', 'max:60'],
            'tagline' => ['nullable', 'string', 'max:120'],
            'contact_email' => ['nullable', 'email', 'max:120'],
            'contact_phone' => ['nullable', 'string', 'max:40'],
            'instagram' => ['nullable', 'string', 'max:80'],
            'footer_note' => ['nullable', 'string', 'max:200'],
            'items_per_page' => ['nullable', 'integer', 'min:6', 'max:60'],
        ]);

        Setting::putMany($data);
        Setting::put('maintenance', $request->boolean('maintenance') ? '1' : '0');

        admin_log('pengaturan.simpan', ['keys' => array_keys($data)]);

        return back()->with('success', 'Pengaturan disimpan.');
    }
}
