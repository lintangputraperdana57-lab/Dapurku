<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Review;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function index(Request $request)
    {
        $status = (string) $request->query('status', '');
        $rating = (int) $request->query('rating', 0);

        $reviews = Review::with(['user', 'recipe'])
            ->when(in_array($status, ['approved', 'pending', 'rejected'], true), fn ($q) => $q->where('status', $status))
            ->when($rating >= 1 && $rating <= 5, fn ($q) => $q->where('rating', $rating))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('admin.reviews.index', [
            'reviews' => $reviews,
            'status' => $status,
            'rating' => $rating,
            'counts' => [
                'all' => Review::count(),
                'approved' => Review::where('status', 'approved')->count(),
                'pending' => Review::where('status', 'pending')->count(),
                'rejected' => Review::where('status', 'rejected')->count(),
                'avg' => round((float) Review::avg('rating'), 1),
            ],
        ]);
    }

    public function update(Request $request, Review $ulasan)
    {
        $data = $request->validate(['status' => ['required', 'in:approved,pending,rejected']]);
        $ulasan->update($data);
        admin_log('ulasan.moderasi', ['id' => $ulasan->id, 'status' => $data['status']]);

        return back()->with('success', 'Status ulasan diperbarui menjadi ' . status_label($data['status']) . '.');
    }

    public function destroy(Review $ulasan)
    {
        $ulasan->delete();
        admin_log('ulasan.hapus', ['id' => $ulasan->id]);

        return back()->with('success', 'Ulasan dihapus.');
    }
}
