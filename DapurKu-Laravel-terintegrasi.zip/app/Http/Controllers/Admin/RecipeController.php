<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class RecipeController extends Controller
{
    public function index()
    {
        return view('admin.recipes.index', [
            'recipes' => Recipe::with('category')->latest()->paginate(15)->withQueryString(),
        ]);
    }

    public function create()
    {
        return view('admin.recipes.form', [
            'recipe' => new Recipe(),
            'cats' => Category::orderBy('sort_order')->get(),
            'ingsText' => '',
            'stepsText' => '',
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['slug'] = $this->uniqueSlug($data['title']);
        $data['image'] = $this->storeImage($request);
        $recipe = Recipe::create($data + ['user_id' => auth()->id()]);
        $this->syncChildren($request, $recipe);

        return redirect()->route('admin.resep.index')->with('success', 'Resep ditambahkan.');
    }

    public function edit(Recipe $recipe)
    {
        $recipe->load(['ingredients', 'steps']);
        $ingsText = $recipe->ingredients->sortBy('sort_order')
            ->map(fn ($i) => trim($i->name . '|' . ($i->quantity ?? '') . '|' . ($i->unit ?? ''), '|'))
            ->implode("\n");
        $stepsText = $recipe->steps->sortBy('step_number')->pluck('instruction')->implode("\n");

        return view('admin.recipes.form', [
            'recipe' => $recipe,
            'cats' => Category::orderBy('sort_order')->get(),
            'ingsText' => $ingsText,
            'stepsText' => $stepsText,
        ]);
    }

    public function update(Request $request, Recipe $recipe)
    {
        $data = $this->validated($request);
        if ($request->hasFile('image')) {
            $data['image'] = $this->storeImage($request);
        }
        $recipe->update($data);
        $this->syncChildren($request, $recipe, true);

        return redirect()->route('admin.resep.index')->with('success', 'Resep diperbarui.');
    }

    public function destroy(Recipe $recipe)
    {
        $recipe->delete();

        return redirect()->route('admin.resep.index')->with('success', 'Resep dihapus.');
    }

    /* ---------- bantuan ---------- */

    private function validated(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'category_id' => ['nullable', 'exists:categories,id'],
            'region_slug' => ['nullable', 'string', 'max:40'],
            'excerpt' => ['nullable', 'string', 'max:400'],
            'description' => ['nullable', 'string'],
            'cook_time' => ['required', 'integer', 'min:1', 'max:1440'],
            'prep_time' => ['nullable', 'integer', 'min:0', 'max:1440'],
            'servings' => ['nullable', 'integer', 'min:1', 'max:200'],
            'difficulty' => ['required', 'in:mudah,sedang,sulit'],
            'calories' => ['nullable', 'integer', 'min:0', 'max:5000'],
            'status' => ['required', 'in:published,draft,arsip'],
            'is_featured' => ['nullable', 'boolean'],
        ]) + ['is_featured' => $request->boolean('is_featured')];
    }

    private function uniqueSlug(string $title, ?int $ignore = null): string
    {
        $base = Str::slug($title) ?: 'resep';
        $slug = $base;
        $i = 2;
        while (Recipe::where('slug', $slug)->when($ignore, fn ($q) => $q->where('id', '!=', $ignore))->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    private function storeImage(Request $request): ?string
    {
        if (!$request->hasFile('image')) {
            return null;
        }
        $file = $request->file('image');
        $name = Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) . '-' . time()
            . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('uploads/recipes'), $name);

        return 'recipes/' . $name;
    }

    /** Langkah (per baris) & bahan (baris "nama|jumlah|satuan"). */
    private function syncChildren(Request $request, Recipe $recipe, bool $replace = false): void
    {
        $steps = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $request->input('steps', '')))));
        $ings = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $request->input('ingredients', '')))));

        if ($replace || $recipe->steps()->count() === 0) {
            if ($replace) {
                $recipe->steps()->delete();
                $recipe->ingredients()->delete();
            }
            foreach ($steps as $i => $text) {
                $recipe->steps()->create(['step_number' => $i + 1, 'instruction' => $text]);
            }
            foreach ($ings as $i => $line) {
                [$name, $qty, $unit] = array_pad(explode('|', $line, 3), 3, null);
                $recipe->ingredients()->create([
                    'name' => trim((string) $name),
                    'quantity' => $qty !== null ? trim($qty) : null,
                    'unit' => $unit !== null ? trim($unit) : null,
                    'sort_order' => $i,
                ]);
            }
        }
    }
}
