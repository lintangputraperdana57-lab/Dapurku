<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Comment;
use App\Models\Message;
use App\Models\Recipe;
use App\Models\Review;
use App\Models\User;
use App\Models\Visit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StatisticsController extends Controller
{
    public function index(Request $request)
    {
        $range = (int) $request->query('hari', 30);
        $range = in_array($range, [7, 30, 90], true) ? $range : 30;

        $since = now()->subDays($range - 1)->startOfDay();

        /* Kunjungan mentah di rentang ini — dihitung di PHP agar portabel
           di sqlite maupun mysql. */
        $visits = Visit::where('created_at', '>=', $since)
            ->get(['path', 'ip', 'created_at']);

        $byDay = [];
        for ($i = $range - 1; $i >= 0; $i--) {
            $d = now()->subDays($i);
            $byDay[$d->toDateString()] = ['label' => $d->translatedFormat($range > 30 ? 'd/m' : 'd M'), 'n' => 0];
        }
        foreach ($visits as $v) {
            $key = $v->created_at?->toDateString();
            if ($key !== null && isset($byDay[$key])) {
                $byDay[$key]['n']++;
            }
        }

        $paths = $visits->groupBy(fn ($v) => $v->path ?: '/')
            ->map(fn ($group, $path) => (object) ['path' => $path, 'n' => $group->count()])
            ->sortByDesc('n')
            ->take(10)
            ->values();

        $topRecipes = Recipe::orderByDesc('views')
            ->limit(8)
            ->get(['id', 'title', 'slug', 'views', 'status', 'category_id']);

        return view('admin.statistics', [
            'range' => $range,
            'byDay' => $byDay,
            'maxDay' => max(1, ...array_column($byDay, 'n')),
            'total' => $visits->count(),
            'today' => Visit::whereDate('created_at', now())->count(),
            'unique' => $visits->pluck('ip')->filter()->unique()->count(),
            'avg' => round($visits->count() / max(1, $range), 1),
            'paths' => $paths,
            'topRecipes' => $topRecipes,
            'content' => [
                'Resep' => Recipe::count(),
                'Terbit' => Recipe::where('status', 'published')->count(),
                'Draft/arsip' => Recipe::where('status', '!=', 'published')->count(),
                'Kategori' => Category::count(),
                'Pengguna' => User::count(),
                'Pengguna baru' => User::where('created_at', '>=', $since)->count(),
                'Ulasan' => Review::count(),
                'Komentar' => Comment::count(),
                'Pesan' => Message::count(),
                'Disimpan' => DB::table('favorites')->count(),
            ],
        ]);
    }
}
