<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function index(Request $request)
    {
        $filter = (string) $request->query('filter', '');

        $messages = Message::query()
            ->when($filter === 'unread', fn ($q) => $q->where('is_read', false))
            ->when($filter === 'replied', fn ($q) => $q->whereNotNull('reply'))
            ->orderByDesc('created_at')
            ->paginate(20)
            ->withQueryString();

        return view('admin.messages.index', [
            'messages' => $messages,
            'filter' => $filter,
            'counts' => [
                'all' => Message::count(),
                'unread' => Message::where('is_read', false)->count(),
                'replied' => Message::whereNotNull('reply')->count(),
            ],
        ]);
    }

    public function show(Message $pesan)
    {
        if (!$pesan->is_read) {
            $pesan->update(['is_read' => true]);
        }

        return view('admin.messages.show', ['message' => $pesan]);
    }

    public function reply(Request $request, Message $pesan)
    {
        $data = $request->validate([
            'reply' => ['required', 'string', 'max:4000'],
        ]);

        $pesan->update([
            'reply' => $data['reply'],
            'replied_at' => now(),
            'is_read' => true,
        ]);
        admin_log('pesan.balas', ['id' => $pesan->id, 'email' => $pesan->email]);

        return back()->with('success', 'Balasan tersimpan.');
    }

    /** Tandai dibaca / belum dibaca. */
    public function toggleRead(Message $pesan)
    {
        $pesan->update(['is_read' => !$pesan->is_read]);

        return back()->with('success', $pesan->is_read ? 'Ditandai sudah dibaca.' : 'Ditandai belum dibaca.');
    }

    public function destroy(Message $pesan)
    {
        $pesan->delete();
        admin_log('pesan.hapus', ['id' => $pesan->id]);

        return redirect()->route('admin.pesan.index')->with('success', 'Pesan dihapus.');
    }
}
