<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ingredient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class IngredientController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));

        $ings = Ingredient::query()
            ->when($q !== '', fn ($sq) => $sq->where(fn ($w) => $w
                ->where('name', 'like', "%{$q}%")
                ->orWhere('description', 'like', "%{$q}%")))
            ->orderBy('name')
            ->paginate(20)
            ->withQueryString();

        /* Jumlah resep yang memakai bahan ini (cocokkan lewat ingredient_id). */
        $used = DB::table('recipe_ingredients')
            ->select('ingredient_id', DB::raw('COUNT(*) as n'))
            ->whereIn('ingredient_id', $ings->pluck('id')->all() ?: [0])
            ->groupBy('ingredient_id')
            ->pluck('n', 'ingredient_id');

        return view('admin.ingredients.index', [
            'ings' => $ings,
            'q' => $q,
            'used' => $used,
            'total' => Ingredient::count(),
        ]);
    }

    public function create()
    {
        return view('admin.ingredients.form', ['ingredient' => new Ingredient()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['slug'] = $this->uniqueSlug($data['name']);

        $ing = Ingredient::create($data);
        admin_log('bahan.tambah', ['id' => $ing->id, 'name' => $ing->name]);

        return redirect()->route('admin.bahan.index')->with('success', 'Bahan ditambahkan.');
    }

    public function edit(Ingredient $bahan)
    {
        return view('admin.ingredients.form', ['ingredient' => $bahan]);
    }

    public function update(Request $request, Ingredient $bahan)
    {
        $data = $this->validated($request);
        if ($data['name'] !== $bahan->name) {
            $data['slug'] = $this->uniqueSlug($data['name'], $bahan->id);
        }

        $bahan->update($data);
        admin_log('bahan.ubah', ['id' => $bahan->id, 'name' => $bahan->name]);

        return redirect()->route('admin.bahan.index')->with('success', 'Bahan diperbarui.');
    }

    public function destroy(Ingredient $bahan)
    {
        $name = $bahan->name;
        $bahan->delete();
        admin_log('bahan.hapus', ['name' => $name]);

        return redirect()->route('admin.bahan.index')->with('success', "Bahan \"{$name}\" dihapus.");
    }

    /* ---------- bantuan ---------- */

    private function validated(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'unit' => ['required', 'string', 'max:20'],
            'description' => ['nullable', 'string', 'max:500'],
        ]);
    }

    private function uniqueSlug(string $name, ?int $ignore = null): string
    {
        $base = Str::slug($name) ?: 'bahan';
        $slug = $base;
        $i = 2;
        while (Ingredient::where('slug', $slug)->when($ignore, fn ($q) => $q->where('id', '!=', $ignore))->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }
}
