<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Report;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $status = (string) $request->query('status', 'open');

        $reports = Report::with('user')
            ->when(in_array($status, ['open', 'resolved', 'dismissed'], true), fn ($q) => $q->where('status', $status))
            ->latest('created_at')
            ->paginate(20)
            ->withQueryString();

        return view('admin.reports.index', [
            'reports' => $reports,
            'status' => $status,
            'counts' => [
                'all' => Report::count(),
                'open' => Report::where('status', 'open')->count(),
                'resolved' => Report::where('status', 'resolved')->count(),
                'dismissed' => Report::where('status', 'dismissed')->count(),
            ],
        ]);
    }

    public function update(Request $request, Report $laporan)
    {
        $data = $request->validate(['status' => ['required', 'in:open,resolved,dismissed']]);
        $laporan->update($data);
        admin_log('laporan.tinjau', ['id' => $laporan->id, 'status' => $data['status']]);

        return back()->with('success', 'Laporan ditandai ' . status_label($data['status']) . '.');
    }

    /** Sembunyikan konten yang dilaporkan lalu tutup laporannya. */
    public function takedown(Report $laporan)
    {
        $model = $laporan->targetModel();

        if ($model instanceof \App\Models\Review || $model instanceof \App\Models\Comment) {
            $model->update(['status' => 'rejected']);
        } elseif ($model instanceof \App\Models\Recipe) {
            $model->update(['status' => 'arsip']);
        }

        $laporan->update(['status' => 'resolved']);
        admin_log('laporan.takedown', [
            'id' => $laporan->id,
            'target_type' => $laporan->target_type,
            'target_id' => $laporan->target_id,
        ]);

        return back()->with('success', 'Konten disembunyikan dan laporan ditutup.');
    }

    public function destroy(Report $laporan)
    {
        $laporan->delete();
        admin_log('laporan.hapus', ['id' => $laporan->id]);

        return back()->with('success', 'Laporan dihapus.');
    }
}
