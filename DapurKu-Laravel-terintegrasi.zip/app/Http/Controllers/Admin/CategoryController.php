<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index()
    {
        return view('admin.categories.index', [
            'cats' => Category::withCount('recipes')
                ->orderBy('sort_order')
                ->orderBy('name')
                ->paginate(20),
        ]);
    }

    public function create()
    {
        return view('admin.categories.form', ['category' => new Category()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['slug'] = $this->uniqueSlug($data['name']);
        $data['image'] = $this->storeImage($request);

        $category = Category::create($data);
        admin_log('kategori.tambah', ['id' => $category->id, 'name' => $category->name]);

        return redirect()->route('admin.kategori.index')->with('success', 'Kategori ditambahkan.');
    }

    public function edit(Category $category)
    {
        return view('admin.categories.form', ['category' => $category]);
    }

    public function update(Request $request, Category $category)
    {
        $data = $this->validated($request);
        if ($data['name'] !== $category->name) {
            $data['slug'] = $this->uniqueSlug($data['name'], $category->id);
        }
        if ($uploaded = $this->storeImage($request)) {
            $data['image'] = $uploaded;
        }

        $category->update($data);
        admin_log('kategori.ubah', ['id' => $category->id, 'name' => $category->name]);

        return redirect()->route('admin.kategori.index')->with('success', 'Kategori diperbarui.');
    }

    public function destroy(Category $category)
    {
        $n = $category->recipes()->count();
        $name = $category->name;
        $category->delete();

        admin_log('kategori.hapus', ['name' => $name, 'recipes' => $n]);

        return redirect()->route('admin.kategori.index')
            ->with('success', $n > 0
                ? "Kategori \"{$name}\" dihapus. {$n} resep kini tanpa kategori."
                : "Kategori \"{$name}\" dihapus.");
    }

    /* ---------- bantuan ---------- */

    private function validated(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'description' => ['nullable', 'string', 'max:500'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:999'],
            'image' => ['nullable', 'image', 'max:2048'],
        ]) + ['sort_order' => (int) $request->input('sort_order', 0)];
    }

    private function uniqueSlug(string $name, ?int $ignore = null): string
    {
        $base = Str::slug($name) ?: 'kategori';
        $slug = $base;
        $i = 2;
        while (Category::where('slug', $slug)->when($ignore, fn ($q) => $q->where('id', '!=', $ignore))->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    private function storeImage(Request $request): ?string
    {
        if (!$request->hasFile('image')) {
            return null;
        }
        $file = $request->file('image');
        $name = Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) . '-' . time()
            . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('uploads/categories'), $name);

        return 'categories/' . $name;
    }
}
