<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Message;
use App\Models\Recipe;
use App\Models\Review;
use App\Models\User;
use App\Models\Visit;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $days = [];
        for ($i = 6; $i >= 0; $i--) {
            $d = now()->subDays($i);
            $days[] = [
                'label' => $d->translatedFormat('d M'),
                'n' => Visit::whereDate('created_at', $d)->count(),
            ];
        }

        return view('admin.dashboard', [
            'nRecipes' => Recipe::count(),
            'nDraft' => Recipe::where('status', '!=', 'published')->count(),
            'nViews' => (int) Recipe::sum('views'),
            'nUsers' => User::count(),
            'nFav' => DB::table('favorites')->count(),
            'nReviews' => Review::count(),
            'nOpen' => DB::table('reports')->where('status', 'open')->count(),
            'nMsg' => Message::count(),
            'days' => $days,
            'byCat' => Category::withCount(['recipes as n' => fn ($q) => $q->where('status', 'published')])
                ->orderByDesc('n')->limit(10)->get(),
            'diff' => Recipe::selectRaw('difficulty, COUNT(*) as n')->groupBy('difficulty')->pluck('n', 'difficulty'),
            'latestRev' => Review::with(['user', 'recipe'])->latest()->limit(5)->get(),
            'top' => Recipe::orderByDesc('views')->limit(8)->get(['id', 'title', 'slug', 'views', 'difficulty', 'status']),
            'latestUsers' => User::latest()->limit(5)->get(['name', 'email', 'role', 'created_at']),
            'latestMsg' => Message::latest()->limit(5)->get(),
        ]);
    }
}
