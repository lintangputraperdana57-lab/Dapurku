<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function index(Request $request)
    {
        $status = (string) $request->query('status', '');

        $comments = Comment::with(['user', 'recipe'])
            ->when(in_array($status, ['approved', 'pending', 'rejected'], true), fn ($q) => $q->where('status', $status))
            ->latest('created_at')
            ->paginate(20)
            ->withQueryString();

        return view('admin.comments.index', [
            'comments' => $comments,
            'status' => $status,
            'counts' => [
                'all' => Comment::count(),
                'approved' => Comment::where('status', 'approved')->count(),
                'pending' => Comment::where('status', 'pending')->count(),
                'rejected' => Comment::where('status', 'rejected')->count(),
            ],
        ]);
    }

    public function update(Request $request, Comment $komentar)
    {
        $data = $request->validate(['status' => ['required', 'in:approved,pending,rejected']]);
        $komentar->update($data);
        admin_log('komentar.moderasi', ['id' => $komentar->id, 'status' => $data['status']]);

        return back()->with('success', 'Status komentar diperbarui menjadi ' . status_label($data['status']) . '.');
    }

    public function destroy(Comment $komentar)
    {
        $komentar->delete();
        admin_log('komentar.hapus', ['id' => $komentar->id]);

        return back()->with('success', 'Komentar dihapus.');
    }
}
