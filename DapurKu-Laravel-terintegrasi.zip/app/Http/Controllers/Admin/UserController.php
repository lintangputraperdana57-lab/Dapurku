<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $role = (string) $request->query('role', '');

        $users = User::query()
            ->when($q !== '', fn ($sq) => $sq->where(fn ($w) => $w
                ->where('name', 'like', "%{$q}%")
                ->orWhere('email', 'like', "%{$q}%")))
            ->when(in_array($role, ['admin', 'moderator', 'user'], true), fn ($sq) => $sq->where('role', $role))
            ->withCount(['recipes', 'reviews'])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('admin.users.index', [
            'users' => $users,
            'q' => $q,
            'role' => $role,
            'counts' => [
                'all' => User::count(),
                'admin' => User::where('role', 'admin')->count(),
                'moderator' => User::where('role', 'moderator')->count(),
                'user' => User::where('role', 'user')->count(),
                'banned' => User::where('status', 'banned')->count(),
                'favorites' => DB::table('favorites')->count(),
            ],
        ]);
    }

    public function update(Request $request, User $pengguna)
    {
        $data = $request->validate([
            'role' => ['required', 'in:admin,moderator,user'],
            'status' => ['required', 'in:active,banned'],
        ]);

        if ($pengguna->is(auth()->user()) && $data['role'] !== 'admin') {
            return back()->with('error', 'Kamu tidak bisa menurunkan peran akunmu sendiri.');
        }

        $pengguna->update($data);
        admin_log('pengguna.ubah', [
            'id' => $pengguna->id,
            'role' => $data['role'],
            'status' => $data['status'],
        ]);

        return back()->with('success', "Akun {$pengguna->name} diperbarui.");
    }

    public function destroy(User $pengguna)
    {
        if ($pengguna->is(auth()->user())) {
            return back()->with('error', 'Kamu tidak bisa menghapus akunmu sendiri.');
        }
        if ($pengguna->role === 'admin' && User::where('role', 'admin')->count() <= 1) {
            return back()->with('error', 'Minimal harus ada satu admin.');
        }

        $name = $pengguna->name;
        $pengguna->delete();
        admin_log('pengguna.hapus', ['name' => $name]);

        return back()->with('success', "Akun \"{$name}\" dihapus.");
    }
}
