<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BannerController extends Controller
{
    public function index()
    {
        return view('admin.banners.index', [
            'banners' => Banner::orderBy('sort_order')->orderBy('id')->get(),
        ]);
    }

    public function create()
    {
        return view('admin.banners.form', ['banner' => new Banner()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['image'] = $this->storeImage($request);
        $banner = Banner::create($data);

        admin_log('banner.tambah', ['id' => $banner->id, 'title' => $banner->title]);

        return redirect()->route('admin.banner.index')->with('success', 'Banner ditambahkan.');
    }

    public function edit(Banner $banner)
    {
        return view('admin.banners.form', ['banner' => $banner]);
    }

    public function update(Request $request, Banner $banner)
    {
        $data = $this->validated($request);
        if ($uploaded = $this->storeImage($request)) {
            $data['image'] = $uploaded;
        }

        $banner->update($data);
        admin_log('banner.ubah', ['id' => $banner->id, 'title' => $banner->title]);

        return redirect()->route('admin.banner.index')->with('success', 'Banner diperbarui.');
    }

    /** Aktif / nonaktifkan banner langsung dari tabel. */
    public function toggle(Banner $banner)
    {
        $banner->update(['is_active' => !$banner->is_active]);
        admin_log('banner.toggle', ['id' => $banner->id, 'is_active' => $banner->is_active]);

        return back()->with('success', $banner->is_active ? 'Banner diaktifkan.' : 'Banner dinonaktifkan.');
    }

    public function destroy(Banner $banner)
    {
        $title = $banner->title;
        $banner->delete();
        admin_log('banner.hapus', ['title' => $title]);

        return redirect()->route('admin.banner.index')->with('success', 'Banner dihapus.');
    }

    /* ---------- bantuan ---------- */

    private function validated(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'subtitle' => ['nullable', 'string', 'max:200'],
            'link' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:999'],
            'image' => ['nullable', 'image', 'max:3072'],
        ]) + ['sort_order' => (int) $request->input('sort_order', 0)]
          + ['is_active' => $request->boolean('is_active')];
    }

    private function storeImage(Request $request): ?string
    {
        if (!$request->hasFile('image')) {
            return null;
        }
        $file = $request->file('image');
        $name = Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) . '-' . time()
            . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('uploads/banners'), $name);

        return 'banners/' . $name;
    }
}
