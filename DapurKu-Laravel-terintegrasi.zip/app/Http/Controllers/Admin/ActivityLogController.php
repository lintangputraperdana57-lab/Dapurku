<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $action = (string) $request->query('aksi', '');

        $logs = ActivityLog::with('user')
            ->when($q !== '', fn ($sq) => $sq->where('meta', 'like', "%{$q}%"))
            ->when($action !== '', fn ($sq) => $sq->where('action', 'like', $action . '%'))
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->paginate(30)
            ->withQueryString();

        return view('admin.logs.index', [
            'logs' => $logs,
            'q' => $q,
            'action' => $action,
            'groups' => ActivityLog::query()
                ->select('action')
                ->distinct()
                ->orderBy('action')
                ->pluck('action')
                ->map(fn ($a) => explode('.', (string) $a)[0])
                ->unique()
                ->values(),
            'total' => ActivityLog::count(),
        ]);
    }

    /** Hapus log lama (default: lebih dari 30 hari). */
    public function clear(Request $request)
    {
        $days = (int) $request->input('days', 30);
        $deleted = ActivityLog::where('created_at', '<', now()->subDays($days))->delete();

        admin_log('log.bersihkan', ['hari' => $days, 'terhapus' => $deleted]);

        return back()->with('success', "{$deleted} baris log lama dihapus.");
    }
}
