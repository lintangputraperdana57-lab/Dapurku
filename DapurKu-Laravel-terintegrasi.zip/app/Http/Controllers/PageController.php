<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function tentang()
    {
        return view('pages.tentang');
    }

    public function privasi()
    {
        return view('pages.privasi');
    }

    public function syarat()
    {
        return view('pages.syarat');
    }

    public function kontak()
    {
        return view('pages.kontak');
    }

    /**
     * Halaman "Perjalanan Dapur" — Radial Orbital Timeline (React + shadcn).
     * View-nya standalone (tidak memakai layouts/app) karena komponen
     * React butuh layar penuh gelap; lihat resources/views/timeline.blade.php
     * dan resources/js/pages/TimelinePage.tsx.
     */
    public function perjalanan()
    {
        return view('timeline');
    }

    public function storeContact(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'email' => ['required', 'email'],
            'subject' => ['nullable', 'string', 'max:120'],
            'body' => ['required', 'string', 'max:2000'],
        ]);

        Message::create($data);

        return back()->with('success', 'Pesan terkirim. Kami balas secepatnya.');
    }
}
