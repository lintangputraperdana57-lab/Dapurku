<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Http\Request;

class RatingController extends Controller
{
    /** Nilai cepat lewat bintang (JSON) — dipakai rating.js. */
    public function store(Request $request)
    {
        $data = $request->validate([
            'recipe_id' => ['required', 'integer'],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
        ]);

        Review::updateOrCreate(
            ['user_id' => auth()->id(), 'recipe_id' => (int) $data['recipe_id']],
            ['rating' => (int) $data['rating'], 'status' => 'approved'],
        );

        return response()->json(['ok' => true]);
    }
}
