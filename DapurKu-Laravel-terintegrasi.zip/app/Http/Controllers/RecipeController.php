<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Ingredient;
use App\Models\Recipe;
use Illuminate\Http\Request;

class RecipeController extends Controller
{
    public function index()
    {
        return $this->listPage('Semua resep', Recipe::with('category')->published()->latest());
    }

    public function search(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $query = Recipe::with('category')->published()
            ->where(fn ($w) => $w->where('title', 'like', "%{$q}%")
                ->orWhere('excerpt', 'like', "%{$q}%")
                ->orWhere('description', 'like', "%{$q}%"));

        return $this->listPage($q !== '' ? "Hasil untuk “{$q}”" : 'Cari resep', $query, ['q' => $q]);
    }

    public function category(string $slug)
    {
        $cat = Category::where('slug', $slug)->firstOrFail();
        $query = Recipe::with('category')->published()->where('category_id', $cat->id)->orderBy('title');

        return $this->listPage($cat->name, $query, ['desc' => $cat->description]);
    }

    public function region(string $slug)
    {
        abort_unless(isset(region_labels()[$slug]), 404);
        $query = Recipe::with('category')->published()->region($slug)->orderBy('title');

        return $this->listPage(region_labels()[$slug], $query);
    }

    public function popular()
    {
        return $this->listPage('Terpopuler', Recipe::with('category')->published()->orderByDesc('views'));
    }

    public function latest()
    {
        return $this->listPage('Terbaru', Recipe::with('category')->published()->latest());
    }

    public function topRated()
    {
        $query = Recipe::with('category')->published()
            ->withAvg(['allReviews as rating_avg' => fn ($q) => $q->where('status', 'approved')], 'rating')
            ->whereHas('allReviews', fn ($q) => $q->where('status', 'approved'))
            ->orderByDesc('rating_avg');

        return $this->listPage('Rating tertinggi', $query);
    }

    public function easy()
    {
        return $this->listPage('Resep mudah', Recipe::with('category')->published()->where('difficulty', 'mudah')->orderBy('title'));
    }

    public function daily()
    {
        $total = Recipe::published()->count();
        $offset = $total ? ((int) now()->format('z')) % $total : 0;
        $recipe = Recipe::published()->orderBy('id')->skip($offset)->first();

        return view('recipes.daily', ['recipe' => $recipe]);
    }

    public function roulette()
    {
        $recipe = Recipe::published()->inRandomOrder()->first();
        if (!$recipe) {
            return redirect()->route('recipes.index');
        }

        return redirect()->route('recipes.show', $recipe->slug)
            ->with('success', 'Roulette memilih: ' . $recipe->title);
    }

    public function allergy(Request $request)
    {
        $avoid = (array) $request->query('hindari', []);
        $query = Recipe::with('category')->published();
        if ($avoid) {
            $ids = \DB::table('recipe_allergens')->whereIn('allergen', $avoid)->pluck('recipe_id')->unique();
            $query->whereNotIn('id', $ids);
        }

        return view('recipes.allergy', [
            'recipes' => $query->orderBy('title')->limit(24)->get(),
            'avoid' => $avoid,
            'allergens' => \DB::table('recipe_allergens')->distinct()->orderBy('allergen')->pluck('allergen'),
        ]);
    }

    public function allCategories()
    {
        return view('recipes.categories', [
            'cats' => Category::withCount(['recipes as published_count' => fn ($q) => $q->where('status', 'published')])
                ->orderBy('sort_order')->get(),
        ]);
    }

    public function allRegions()
    {
        $rows = Recipe::published()->whereNotNull('region_slug')
            ->selectRaw('region_slug, COUNT(*) as n')->groupBy('region_slug')->pluck('n', 'region_slug');

        return view('recipes.regions', ['counts' => $rows]);
    }

    public function ingredients()
    {
        return view('recipes.ingredients', [
            'ingredients' => Ingredient::withCount('recipes')->orderBy('name')->get(),
        ]);
    }

    public function byIngredient(string $slug)
    {
        $ing = Ingredient::where('slug', $slug)->firstOrFail();
        $query = Recipe::with('category')->published()
            ->whereHas('ingredients', fn ($q) => $q->where('ingredient_id', $ing->id)
                ->orWhere('name', 'like', $ing->name . '%'))
            ->orderBy('title');

        return $this->listPage('Bahan: ' . $ing->name, $query);
    }

    public function show(string $slug)
    {
        $recipe = Recipe::with(['category', 'ingredients', 'steps', 'reviews.user', 'comments.user', 'nutrition'])
            ->where('slug', $slug)->firstOrFail();
        $recipe->increment('views');

        return view('recipes.show', [
            'recipe' => $recipe,
            'related' => Recipe::with('category')->published()
                ->where('category_id', $recipe->category_id)->where('id', '!=', $recipe->id)
                ->orderByDesc('views')->limit(3)->get(),
        ]);
    }

    /** Render halaman daftar resep dengan pagination gaya DapurKu. */
    private function listPage(string $heading, $query, array $extra = [])
    {
        return view('recipes.index', [
            'heading' => $heading,
            'recipes' => $query->paginate(9)->withQueryString(),
        ] + $extra);
    }
}
