<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    public function index()
    {
        $recipes = Recipe::with('category')
            ->whereHas('favorites', fn ($q) => $q->where('user_id', auth()->id()))
            ->latest()->get();

        return view('favorites.index', ['recipes' => $recipes]);
    }

    public function toggle(Request $request)
    {
        $rid = (int) $request->input('recipe_id');
        $uid = auth()->id();
        $row = \DB::table('favorites')->where('user_id', $uid)->where('recipe_id', $rid)->first();

        if ($row) {
            \DB::table('favorites')->where('user_id', $uid)->where('recipe_id', $rid)->delete();

            return response()->json(['favorited' => false]);
        }

        \DB::table('favorites')->insert(['user_id' => $uid, 'recipe_id' => $rid, 'created_at' => now()]);

        return response()->json(['favorited' => true]);
    }
}
