<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Situs & fitur tambahan: banner, laporan, pesan, setting, log,
        kunjungan, komunitas, gizi, alergen, riwayat masak. */
    public function up(): void
    {
        Schema::create('banners', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('subtitle')->nullable();
            $table->string('image')->nullable();
            $table->string('link')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
        });

        Schema::create('reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('target_type');
            $table->unsignedBigInteger('target_id');
            $table->text('reason')->nullable();
            $table->string('status')->default('open');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('messages', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->string('subject')->nullable();
            $table->text('body');
            $table->text('reply')->nullable();
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('settings', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->text('value')->nullable();
        });

        Schema::create('activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('action');
            $table->text('meta')->nullable();
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('visits', function (Blueprint $table) {
            $table->id();
            $table->string('path')->nullable();
            $table->string('ip')->nullable();
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('community_posts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('recipe_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title');
            $table->text('body');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('recipe_nutrition', function (Blueprint $table) {
            $table->foreignId('recipe_id')->primary()->constrained()->cascadeOnDelete();
            $table->float('protein')->default(0);
            $table->float('fat')->default(0);
            $table->float('carbs')->default(0);
            $table->float('fiber')->default(0);
        });

        Schema::create('recipe_allergens', function (Blueprint $table) {
            $table->foreignId('recipe_id')->constrained()->cascadeOnDelete();
            $table->string('allergen');
            $table->primary(['recipe_id', 'allergen']);
        });

        Schema::create('cook_history', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('recipe_id')->constrained()->cascadeOnDelete();
            $table->timestamp('cooked_at')->nullable();
            $table->text('notes')->nullable();
        });

        Schema::create('user_allergies', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('allergen');
            $table->primary(['user_id', 'allergen']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_allergies');
        Schema::dropIfExists('cook_history');
        Schema::dropIfExists('recipe_allergens');
        Schema::dropIfExists('recipe_nutrition');
        Schema::dropIfExists('community_posts');
        Schema::dropIfExists('visits');
        Schema::dropIfExists('activity_logs');
        Schema::dropIfExists('settings');
        Schema::dropIfExists('messages');
        Schema::dropIfExists('reports');
        Schema::dropIfExists('banners');
    }
};
