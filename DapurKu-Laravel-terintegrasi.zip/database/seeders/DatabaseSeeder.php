<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use PDO;

class DatabaseSeeder extends Seeder
{
    /**
     * Impor seluruh isi database aplikasi lama (database/legacy.sqlite)
     * ke skema Laravel. Kolom yang tidak ada di skema baru dilewati.
     */
    public function run(): void
    {
        $legacyPath = database_path('legacy.sqlite');
        if (!is_file($legacyPath)) {
            $this->command?->warn('legacy.sqlite tidak ditemukan — seeder dilewati.');

            return;
        }

        $legacy = new PDO('sqlite:' . $legacyPath);
        $legacy->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Urutan aman untuk foreign key: induk sebelum anak.
        $order = [
            'users', 'categories', 'recipes', 'ingredients',
            'recipe_ingredients', 'recipe_steps', 'recipe_nutrition', 'recipe_allergens',
            'reviews', 'comments', 'favorites', 'banners', 'messages', 'reports',
            'community_posts', 'notifications', 'settings', 'activity_logs', 'visits',
            'collections', 'collection_recipes', 'meal_plans',
            'shopping_lists', 'shopping_items', 'cook_history', 'user_allergies',
        ];

        $copied = [];
        foreach ($order as $table) {
            if (!Schema::hasTable($table)) {
                continue;
            }

            $rows = $legacy->query("SELECT * FROM {$table}")->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) {
                continue;
            }

            $newCols = Schema::getColumnListing($table);
            $batch = [];
            foreach ($rows as $row) {
                $filtered = [];
                foreach ($row as $key => $value) {
                    if (in_array($key, $newCols, true)) {
                        $filtered[$key] = $value;
                    }
                }
                $batch[] = $filtered;
            }

            DB::table($table)->insert($batch);
            $copied[] = "{$table} (" . count($batch) . ')';
        }

        $this->command?->info('Diimpor: ' . implode(', ', $copied));
    }
}
