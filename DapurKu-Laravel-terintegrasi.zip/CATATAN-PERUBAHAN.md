# DapurKu-Laravel — Panel Admin (menu sesuai gambar)

Ringkasan pekerjaan: menu sidebar admin dibuat **persis seperti screenshot** (Utama / Komunitas /
Situs / Akun) dan **semua menu baru sudah punya halaman yang berfungsi** — bukan tautan kosong.
Setiap halaman punya daftar, filter, aksi (setujui/tolak, balas, aktifkan, hapus), dan tercatat
otomatis ke log aktivitas.

Berkas hasil: `DapurKu-Laravel-admin-panel.zip` (struktur folder sama seperti aslinya, bisa langsung
ditimpa ke project lama). Tangkapan layar tiap halaman: folder `screenshots/`.

---

## 1. Struktur menu (sesuai gambar)

| Bagian | Menu | Route | Controller |
|---|---|---|---|
| Utama | Dasbor | `admin.dashboard` | `Admin\DashboardController` (sudah ada) |
| Utama | Resep | `admin.resep.*` | `Admin\RecipeController` (sudah ada) |
| Utama | **Kategori** | `admin.kategori.*` | `Admin\CategoryController` |
| Utama | **Bahan** | `admin.bahan.*` | `Admin\IngredientController` |
| Komunitas | **Pengguna** | `admin.pengguna.*` | `Admin\UserController` |
| Komunitas | **Ulasan** | `admin.ulasan.*` | `Admin\ReviewController` |
| Komunitas | **Komentar** | `admin.komentar.*` | `Admin\CommentController` |
| Komunitas | **Laporan** | `admin.laporan.*` | `Admin\ReportController` |
| Komunitas | **Pesan** | `admin.pesan.*` | `Admin\MessageController` |
| Situs | **Banner** | `admin.banner.*` | `Admin\BannerController` |
| Situs | **Statistik** | `admin.statistik` | `Admin\StatisticsController` |
| Situs | **Pengaturan** | `admin.pengaturan.*` | `Admin\SettingController` |
| Situs | **Log** | `admin.log.*` | `Admin\ActivityLogController` |
| Akun | Lihat situs | `home` | — (buka tab baru) |
| Akun | Keluar | `logout` | `AuthController@logout` |

Menu aktif otomatis ditandai (highlight oranye) di `resources/views/layouts/admin.blade.php`.

## 2. Isi tiap halaman

- **Kategori** — daftar kategori + jumlah resep, tambah/edit/hapus, gambar, urutan tampil, slug otomatis.
- **Bahan** — daftar bahan + satuan + berapa kali dipakai resep, pencarian, tambah/edit/hapus.
- **Pengguna** — KPI peran, cari/filter peran, ubah peran (admin/moderator/pengguna) & status (aktif/blokir)
  langsung dari tabel, hapus akun. Pengaman: tidak bisa menurunkan/menghapus akun sendiri, dan admin terakhir
  tidak bisa dihapus.
- **Ulasan** — tab Semua/Menunggu/Disetujui/Ditolak, rata-rata rating, ubah status moderasi, hapus.
- **Komentar** — sama seperti ulasan, plus penanda "balasan" untuk komentar bertingkat.
- **Laporan** — tab Terbuka/Selesai/Diabaikan, lihat jenis & ringkasan konten yang dilaporkan,
  tombol **Sembunyikan** (resep → arsip, ulasan/komentar → ditolak) yang sekaligus menutup laporan.
- **Pesan** — kotak masuk formulir kontak: status Baru/Dibaca/Dibalas, buka detail, tulis balasan
  (kolom `reply` + `replied_at`), tandai dibaca/belum, hapus, tautan "balas lewat email".
- **Banner** — kartu banner beranda: tambah/edit/hapus, unggah gambar, tautan, urutan, tombol aktif/nonaktif.
- **Statistik** — rentang 7/30/90 hari: total kunjungan, hari ini, pengunjung unik (IP), puncak harian,
  grafik batang harian, 10 halaman terpopuler, 8 resep terpopuler, ringkasan isi katalog.
- **Pengaturan** — nama situs, tagline, email, telepon/WA, Instagram, catatan footer, item per halaman,
  dan mode perawatan.
- **Log** — riwayat aksi admin (waktu, pelaku, aksi, detail JSON), filter aksi/pencarian, bersihkan log > 30 hari.

## 3. Berkas yang ditambahkan

```
app/Http/Controllers/Admin/  CategoryController, IngredientController, UserController,
                             ReviewController, CommentController, ReportController,
                             MessageController, BannerController, StatisticsController,
                             SettingController, ActivityLogController        (11 berkas baru)
app/Models/                  Report, ActivityLog, Setting                       (3 berkas baru)

resources/views/admin/categories/{index,form}.blade.php
resources/views/admin/ingredients/{index,form}.blade.php
resources/views/admin/banners/{index,form}.blade.php
resources/views/admin/users/index.blade.php
resources/views/admin/reviews/index.blade.php
resources/views/admin/comments/index.blade.php
resources/views/admin/reports/index.blade.php
resources/views/admin/messages/{index,show}.blade.php
resources/views/admin/statistics.blade.php
resources/views/admin/settings.blade.php
resources/views/admin/logs/index.blade.php            (15 berkas view baru)

database/migrations/2026_11_04_000500_add_admin_columns_to_messages.php
```

## 4. Berkas yang diubah

- `routes/web.php` — grup admin diperluas (49 rute admin), `Route::resource('resep')` diberi `->except('show')`
  karena method `show` memang tidak ada.
- `resources/views/layouts/admin.blade.php` — sidebar baru sesuai gambar (4 bagian, penanda aktif,
  badge jumlah untuk Laporan terbuka & Pesan belum dibaca, ikon SVG di kepala sidebar).
- `public/assets/css/admin.css` — komponen baru: tab filter, badge status, formulir (`.form-grid`, `.fld`,
  `.input`, `.checkbox`), pill, tabel bisa digeser, tampilan pesan, kolom aksi satu baris.
- `app/Models/Message.php` — tambah `is_read`, `replied_at`.
- `app/Models/Comment.php` — tambah relasi `recipe()`, `parent()`, `replies()` (sebelumnya admin error
  `Call to undefined relationship [recipe]` saat memuat komentar).
- `app/Helpers.php` — helper baru: `setting()`, `admin_log()`, `status_class()`, `status_label()`.
- `resources/views/partials/navbar.blade.php`, `partials/footer.blade.php`, `layouts/app.blade.php` —
  pengaturan benar-benar terpakai: nama situs di brand, tagline di footer, catatan footer, dan bilah
  pemberitahuan bila "mode perawatan" aktif.

## 5. Cara menjalankan

```bash
# di folder project
php artisan migrate      # wajib: menambah kolom is_read & replied_at pada tabel messages
php artisan serve
```

Database yang disertakan **masih data asli kamu** (52 resep, 14 kategori, 20 bahan, 2 banner, 2 akun) —
hanya migrasi baru yang sudah dijalankan. Tidak ada data uji yang tertinggal.

Masuk ke `/admin` dengan akun admin yang biasa dipakai (password tidak diubah).

## 6. Catatan teknis

- **Log aktivitas otomatis**: setiap aksi tulis (tambah/ubah/hapus/moderasi/balas/simpan pengaturan)
  memanggil `admin_log('grup.aksi', [...])`. Helper ini dibungkus `try/catch` sehingga kegagalan log
  tidak pernah menggagalkan aksi utama.
- **Badge sidebar**: angka pada Laporan & Pesan dihitung dari tabel `reports` (status `open`) dan
  `messages` (`is_read = false`), muncul hanya jika lebih dari nol. Bila query mahal, mudah dipindah ke
  view composer/cache.
- **Statistik** menghitung kunjungan di PHP dari rentang tanggal (portabel sqlite/mysql), bukan fungsi
  tanggal spesifik DB.
- **Unggahan gambar** kategori & banner disimpan di `public/uploads/categories` dan `public/uploads/banners`
  (folder dibuat otomatis saat unggah pertama).
- Semua halaman admin sudah diuji: 18 halaman merespons 200 dan seluruh aksi tulis merespons 302 tanpa
  error (uji end-to-end memakai akun sementara yang sudah dihapus).
