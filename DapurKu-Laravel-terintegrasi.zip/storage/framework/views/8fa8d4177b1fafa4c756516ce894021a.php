<?php $__env->startSection('title', 'Resep harian'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow"><?php echo dk_icon('sun', 14); ?> Baru tiap hari</p>
            <h2>Resep hari ini</h2>
            <p class="muted">Pilihan dapur untuk <?php echo e(now()->translatedFormat('l, d F Y')); ?>.</p>
        </div>
        <a class="btn btn-ghost solid" href="<?php echo e(route('recipes.roulette')); ?>">Acak lagi <?php echo dk_icon('dice', 15); ?></a>
    </div>
    <?php if($recipe): ?>
        <div class="grid-cards" style="grid-template-columns:minmax(0,420px)">
            <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php else: ?>
        <div class="empty"><p class="muted">Belum ada resep.</p></div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/daily.blade.php ENDPATH**/ ?>