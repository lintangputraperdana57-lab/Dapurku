<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $heroStats = $hero
        ? [
            ['clock', format_minutes($hero->cook_time)],
            ['users', ($hero->servings ?: 4) . ' porsi'],
            ['scale', difficulty_label($hero->difficulty)],
        ]
        : [];
    $regions = [
        ['sumatera', 'Sumatera', 'Rendang, pempek, mie Aceh'],
        ['jawa', 'Jawa', 'Soto, gudeg, rawon'],
        ['bali-nusa', 'Bali & Nusa', 'Betutu, sate lilit, plecing'],
        ['kalimantan', 'Kalimantan', 'Soto Banjar, ikan bakar'],
        ['sulawesi', 'Sulawesi', 'Coto, dabu-dabu, konro'],
        ['maluku-papua', 'Maluku & Papua', 'Papeda, ikan kuah kuning'],
    ];
?>

<?php if($banners->isNotEmpty()): ?>
    <?php $b = $banners->first(); ?>
    <section class="banner">
        <div class="banner-copy">
            <p class="kicker"><?php echo dk_icon('sparkle', 14); ?> Dapur rumahan</p>
            <h1><?php echo e($b->title); ?></h1>
            <p><?php echo e($b->subtitle); ?></p>
            <a class="btn btn-ghost" href="<?php echo e($b->link ? url($b->link) : route('recipes.index')); ?>">
                Lihat resep <?php echo dk_icon('arrow-right', 16); ?>

            </a>
        </div>
        <div class="banner-art" aria-hidden="true">
            <span></span><span></span><span></span>
        </div>
    </section>
<?php endif; ?>

<section class="hero">
    <div class="hero-copy">
        <p class="kicker"><?php echo dk_icon('flame', 14); ?> Masak hari ini</p>
        <h1>Resep yang terasa seperti <em>rumah</em>.</h1>
        <p class="lede">Lauk Nusantara, menu 30 menit, dan ide belanja dari bahan yang sudah ada di dapurmu — <?php echo e(format_number($counts['recipes'])); ?> resep siap dimasak.</p>

        <form class="search-hero" action="<?php echo e(route('recipes.search')); ?>" method="get" role="search">
            <span class="search-ico" aria-hidden="true"><?php echo dk_icon('search', 18); ?></span>
            <input data-live-search name="q" placeholder="Cari rendang, soto, atau “pakai telur”…" autocomplete="off" aria-label="Cari resep">
            <button class="btn btn-primary" type="submit">Cari</button>
        </form>
        <div data-search-out class="toolbar search-out"></div>

        <dl class="hero-stats">
            <div><dt><?php echo dk_icon('pot', 16); ?> Resep</dt><dd><?php echo e(format_number($counts['recipes'])); ?></dd></div>
            <div><dt><?php echo dk_icon('grid', 16); ?> Kategori</dt><dd><?php echo e(format_number($counts['cats'])); ?></dd></div>
            <div><dt><?php echo dk_icon('map', 16); ?> Daerah</dt><dd><?php echo e(count(region_labels())); ?></dd></div>
        </dl>
    </div>

    <div class="hero-plate">
        <?php if($hero && $hero->image): ?>
            <img src="<?php echo e(recipe_image($hero->image)); ?>" alt="<?php echo e($hero->title); ?>">
        <?php else: ?>
            <div class="placeholder-art"></div>
        <?php endif; ?>
        <?php if($hero): ?>
            <figcaption>
                <span class="hero-plate-kicker"><?php echo dk_icon('star', 13); ?> Unggulan dapur</span>
                <a href="<?php echo e(route('recipes.show', $hero->slug)); ?>"><strong><?php echo e($hero->title); ?></strong></a>
                <span class="muted"><?php echo e(excerpt_text($hero->excerpt ?? $hero->description ?? '', 78)); ?></span>
                <span class="hero-plate-meta">
                    <?php $__currentLoopData = $heroStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo dk_icon($s[0], 14); ?> <?php echo e($s[1]); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </span>
            </figcaption>
        <?php endif; ?>
    </div>
</section>

<?php echo $__env->make('partials.conveyor', [
    'items' => $conveyor,
    'eyebrow' => 'Kaiten · Sabuk dapur',
    'heading' => 'Sabuk resep yang terus berputar, langsung di halaman.',
    'caption' => 'Arahkan kursor untuk menghentikan sabuk, sentil untuk memutar, pilih piring untuk melihat resep.',
    'action' => new \Illuminate\Support\HtmlString('<a class="btn btn-primary" href="' . route('recipes.popular') . '">' . dk_icon('flame', 16) . ' Semua terpopuler</a>'),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="section">
    <div class="section-head">
        <h2><?php echo dk_icon('grid', 20); ?> Kategori dapur</h2>
        <a class="section-link" href="<?php echo e(route('recipes.allCategories')); ?>">Semua <?php echo dk_icon('arrow-right', 15); ?></a>
    </div>
    <div class="grid-4">
        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="cat-chip" href="<?php echo e(route('recipes.category', $c->slug)); ?>">
                <span class="cat-chip-ico"><?php echo dk_icon($c->icon ?: 'chef', 18); ?></span>
                <strong><?php echo e($c->name); ?></strong>
                <span class="muted"><?php echo e(excerpt_text($c->description ?? '', 48)); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2><?php echo dk_icon('map', 20); ?> Dari Sabang sampai Merauke</h2>
        <a class="section-link" href="<?php echo e(route('recipes.allRegions')); ?>">Semua daerah <?php echo dk_icon('arrow-right', 15); ?></a>
    </div>
    <div class="grid-4 region-grid">
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="cat-chip region-chip" href="<?php echo e(route('recipes.region', $rg[0])); ?>">
                <strong><?php echo e($rg[1]); ?></strong>
                <span class="muted"><?php echo e($rg[2]); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="section">
    <div class="quick-actions">
        <a class="qa qa-primary" href="<?php echo e(route('recipes.daily')); ?>">
            <span class="qa-ico"><?php echo dk_icon('sun', 22); ?></span>
            <span><strong>Resep hari ini</strong><em>Pilihan redaksi dapur</em></span>
        </a>
        <a class="qa" href="<?php echo e(route('recipes.roulette')); ?>">
            <span class="qa-ico"><?php echo dk_icon('dice', 22); ?></span>
            <span><strong>Roulette menu</strong><em>Bingung? Biar diacak</em></span>
        </a>
        <a class="qa" href="<?php echo e(route('recipes.allergy')); ?>">
            <span class="qa-ico"><?php echo dk_icon('shield', 22); ?></span>
            <span><strong>Filter alergi</strong><em>Masak dengan aman</em></span>
        </a>
        <a class="qa" href="<?php echo e(route('recipes.topRated')); ?>">
            <span class="qa-ico"><?php echo dk_icon('star', 22); ?></span>
            <span><strong>Rating tertinggi</strong><em>Favorit pembaca</em></span>
        </a>
    </div>
</section>

<?php echo $__env->make('partials.wheel', ['items' => $wheel], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="section">
    <div class="section-head">
        <h2><?php echo dk_icon('star', 20); ?> Unggulan dapur</h2>
        <a class="section-link" href="<?php echo e(route('recipes.popular')); ?>">Terpopuler <?php echo dk_icon('arrow-right', 15); ?></a>
    </div>
    <div class="grid-cards">
        <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2><?php echo dk_icon('flame', 20); ?> Baru dari kompor</h2>
        <a class="section-link" href="<?php echo e(route('recipes.latest')); ?>">Terbaru <?php echo dk_icon('arrow-right', 15); ?></a>
    </div>
    <div class="grid-cards">
        <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/home.blade.php ENDPATH**/ ?>