<?php $__env->startSection('title', 'Laporan'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Laporan</h1>
    <p class="muted">Aduan pengunjung atas resep, ulasan, komentar, atau akun.</p>
  </div>
  <span class="pill"><?php echo e($counts['open']); ?> terbuka</span>
</header>

<nav class="tabs">
  <?php $__currentLoopData = ['open' => 'Terbuka', 'resolved' => 'Selesai', 'dismissed' => 'Diabaikan', '' => 'Semua']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="tab <?php echo e($status === $key ? 'is-on' : ''); ?>" href="<?php echo e(route('admin.laporan.index', array_filter(['status' => $key]))); ?>">
      <?php echo e($label); ?> <b><?php echo e($counts[$key ?: 'all']); ?></b>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pelapor</th><th>Jenis</th><th>Konten</th><th>Alasan</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <strong><?php echo e($rp->user?->name ?? 'Tamu'); ?></strong>
              <?php if($rp->user): ?> <div class="muted small"><?php echo e($rp->user->email); ?></div> <?php endif; ?>
            </td>
            <td><span class="pill pill-quiet"><?php echo e($rp->targetLabel()); ?></span></td>
            <td class="cell-body"><?php echo e($rp->targetSummary()); ?></td>
            <td class="cell-body muted"><?php echo e($rp->reason ?: '—'); ?></td>
            <td><span class="<?php echo e(status_class($rp->status)); ?>"><?php echo e($rp->statusLabel()); ?></span></td>
            <td class="muted nowrap"><?php echo e($rp->created_at?->translatedFormat('d M Y') ?? '—'); ?></td>
            <td>
              <div class="row-actions">
                <form method="post" action="<?php echo e(route('admin.laporan.update', $rp)); ?>" class="inline-form">
                  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                  <select class="input input-sm" name="status">
                    <?php $__currentLoopData = ['open' => 'Terbuka', 'resolved' => 'Selesai', 'dismissed' => 'Diabaikan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($k); ?>" <?php if($rp->status === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                <?php if($rp->status === 'open'): ?>
                  <form method="post" action="<?php echo e(route('admin.laporan.takedown', $rp)); ?>" onsubmit="return confirm('Sembunyikan konten yang dilaporkan?')" style="display:inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-ghost" type="submit">Sembunyikan</button>
                  </form>
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('admin.laporan.destroy', $rp)); ?>" onsubmit="return confirm('Hapus laporan ini?')" style="display:inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" class="muted">Tidak ada laporan pada filter ini.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $reports], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>