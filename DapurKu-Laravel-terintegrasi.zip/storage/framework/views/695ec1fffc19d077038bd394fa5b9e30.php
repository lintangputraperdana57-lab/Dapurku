<?php
    /** @var \App\Models\Recipe $recipe */
    $ratio = $recipe->avgRating();
    $isFav = $recipe->isFavoritedBy(auth()->id());
?>
<article class="card">
    <a class="card-media-link" href="<?php echo e(route('recipes.show', $recipe->slug)); ?>" tabindex="-1" aria-hidden="true">
        <div class="card-media">
            <?php if($recipe->image): ?>
                <img src="<?php echo e(recipe_image($recipe->image)); ?>" alt="" loading="lazy" decoding="async">
            <?php else: ?>
                <div class="placeholder-art"></div>
            <?php endif; ?>
            <span class="badge"><?php echo e($recipe->category?->name ?? difficulty_label($recipe->difficulty)); ?></span>
            <?php if($ratio > 0): ?>
                <span class="badge badge-rating"><?php echo dk_icon('star', 12); ?> <?php echo e(number_format($ratio, 1, ',', '.')); ?></span>
            <?php endif; ?>
        </div>
    </a>

    <button type="button"
            class="fav-btn<?php echo e($isFav ? ' is-on' : ''); ?>"
            data-favorite="<?php echo e($recipe->id); ?>"
            aria-pressed="<?php echo e($isFav ? 'true' : 'false'); ?>"
            aria-label="<?php echo e($isFav ? 'Hapus dari favorit' : 'Simpan ke favorit'); ?>"
            title="Favorit">
        <?php echo dk_icon('heart', 17); ?>

    </button>

    <div class="card-body">
        <h3><a href="<?php echo e(route('recipes.show', $recipe->slug)); ?>"><?php echo e($recipe->title); ?></a></h3>
        <p class="muted card-excerpt"><?php echo e(excerpt_text($recipe->excerpt ?? $recipe->description, 88)); ?></p>
        <div class="meta">
            <span class="meta-pill"><?php echo dk_icon('clock', 14); ?> <?php echo e(format_minutes($recipe->cook_time)); ?></span>
            <span class="meta-pill"><?php echo dk_icon(dk_difficulty_icon($recipe->difficulty), 14); ?> <?php echo e(difficulty_label($recipe->difficulty)); ?></span>
            <span class="meta-pill"><?php echo dk_icon('eye', 14); ?> <?php echo e(format_number($recipe->views)); ?></span>
        </div>
    </div>
</article>
<?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/partials/recipe-card.blade.php ENDPATH**/ ?>