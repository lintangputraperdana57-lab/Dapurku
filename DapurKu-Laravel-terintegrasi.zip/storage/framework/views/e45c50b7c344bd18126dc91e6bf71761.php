<?php $__env->startSection('title', $recipe->title); ?>
<?php $__env->startSection('content'); ?>
<?php
    $avg = $recipe->avgRating();
    $isFav = $recipe->isFavoritedBy(auth()->id());
?>
<?php echo $__env->make('partials.breadcrumbs', ['crumbs' => [
    ['label' => 'Beranda', 'url' => route('home')],
    ['label' => 'Resep', 'url' => route('recipes.index')],
    ['label' => $recipe->title],
]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<article class="recipe-hero">
    <div class="recipe-cover">
        <?php if($recipe->image): ?>
            <img src="<?php echo e(recipe_image($recipe->image)); ?>" alt="">
        <?php else: ?>
            <div class="placeholder-art" style="min-height:320px"></div>
        <?php endif; ?>
    </div>
    <div>
        <p class="kicker">
            <?php echo e($recipe->category?->name ?? ''); ?>

            <?php if($recipe->region_slug): ?> · <?php echo e(region_labels()[$recipe->region_slug] ?? $recipe->region_slug); ?> <?php endif; ?>
        </p>
        <h1><?php echo e($recipe->title); ?></h1>
        <p class="lede"><?php echo e($recipe->excerpt); ?></p>
        <p class="stars">★ <?php echo e(number_format($avg, 1, ',', '.')); ?> · <?php echo e(format_number($recipe->views)); ?> kali dilihat</p>
        <p class="meta">
            <span>Masak <?php echo e(format_minutes($recipe->cook_time)); ?></span>
            <span>Persiapan <?php echo e(format_minutes($recipe->prep_time)); ?></span>
            <span><?php echo e(difficulty_label($recipe->difficulty)); ?></span>
            <span><?php echo e((int) $recipe->servings); ?> porsi</span>
            <span>🔥 <?php echo e((int) $recipe->calories); ?> kkal / porsi</span>
        </p>
        <?php if($recipe->allergens->count()): ?>
            <p class="meta">Alergen:
                <?php $__currentLoopData = $recipe->allergens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="chip"><?php echo e($a->allergen); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        <?php endif; ?>
        <div class="toolbar">
            <button class="icon-btn<?php echo e($isFav ? ' is-on' : ''); ?>" data-fav="<?php echo e($recipe->id); ?>"><?php echo e($isFav ? '♥ Favorit' : '♡ Simpan'); ?></button>
            <a class="icon-btn" href="<?php echo e(route('recipes.show', $recipe->slug)); ?>?cetak=1" onclick="window.print();return false;">Cetak</a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('admin.resep.edit', $recipe)); ?>">Edit</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="calc-box">
            <strong>Kalkulator porsi</strong>
            <p class="muted">Ubah jumlah porsi, bahan ikut terhitung.</p>
            <p>Porsi
                <input data-servings data-base="<?php echo e((int) $recipe->servings); ?>" type="number" min="1" value="<?php echo e((int) $recipe->servings); ?>" style="width:80px;display:inline-block">
            </p>
            <p>Kalori total: <b data-cal-total data-cal="<?php echo e((int) $recipe->calories); ?>"><?php echo e((int) $recipe->calories * (int) $recipe->servings); ?></b> kkal</p>
        </div>
        <div class="timer-box">
            <strong>Timer masak</strong>
            <p>
                <input id="timerMin" type="number" min="1" value="<?php echo e(max(1, (int) $recipe->cook_time)); ?>" style="width:70px"> menit
                <button class="btn btn-sm btn-primary" type="button" id="timerStart">Mulai</button>
                <button class="btn btn-sm btn-ghost solid" type="button" id="timerStop">Stop</button>
            </p>
            <p class="timer-display" id="timerDisp">00:00</p>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <div data-recipe="<?php echo e($recipe->id); ?>" class="stars">
                Nilai:
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <span data-rate="<?php echo e($i); ?>" style="cursor:pointer"><?php echo e($i <= round($avg) ? '★' : '☆'); ?></span>
                <?php endfor; ?>
            </div>
        <?php else: ?>
            <p class="muted"><a href="<?php echo e(route('login')); ?>">Masuk</a> untuk memberi nilai &amp; ulasan.</p>
        <?php endif; ?>
    </div>
</article>

<section class="section">
    <p><?php echo nl2br(e($recipe->description ?? '')); ?></p>
    <div class="layout-2">
        <div>
            <h2>Bahan</h2>
            <ul class="ings">
                <?php $__empty_1 = true; $__currentLoopData = $recipe->ingredients->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <span><?php echo e($ing->name); ?></span>
                        <span><b data-qty="<?php echo e($ing->quantity); ?>"><?php echo e($ing->quantity); ?></b> <?php echo e($ing->unit); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="muted">Bahan belum diisi.</li>
                <?php endif; ?>
            </ul>
        </div>
        <div>
            <h2>Langkah (centang saat selesai)</h2>
            <div class="steps" data-check-steps="<?php echo e($recipe->id); ?>">
                <?php $__empty_1 = true; $__currentLoopData = $recipe->steps->sortBy('step_number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <label class="step step-check">
                        <input type="checkbox" data-step="<?php echo e((int) $st->step_number); ?>">
                        <?php echo e($st->instruction); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="muted">Langkah belum diisi.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php if($recipe->nutrition): ?>
    <section class="section">
        <h2>Nutrisi per porsi</h2>
        <div class="stat-row">
            <div class="stat"><span>Kalori</span><b><?php echo e((int) $recipe->calories); ?></b> kkal</div>
            <div class="stat"><span>Protein</span><b><?php echo e($recipe->nutrition->protein); ?></b> g</div>
            <div class="stat"><span>Lemak</span><b><?php echo e($recipe->nutrition->fat); ?></b> g</div>
            <div class="stat"><span>Karbo</span><b><?php echo e($recipe->nutrition->carbs); ?></b> g</div>
            <div class="stat"><span>Serat</span><b><?php echo e($recipe->nutrition->fiber); ?></b> g</div>
        </div>
        <p class="muted">Perkiraan dapur rumahan, bukan hasil lab.</p>
    </section>
<?php endif; ?>

<section class="section">
    <h2>Ulasan &amp; rating</h2>
    <?php $__currentLoopData = $recipe->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment"><strong><?php echo e($rv->user?->name ?? 'Anonim'); ?></strong> · <?php echo e(str_repeat('★', (int) $rv->rating)); ?><p><?php echo e($rv->body); ?></p></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(auth()->guard()->check()): ?>
        <form class="form" method="post" action="<?php echo e(route('reviews.store', $recipe->slug)); ?>">
            <?php echo csrf_field(); ?>
            <label>Rating <select name="rating"><?php for($i = 5; $i >= 1; $i--): ?><option value="<?php echo e($i); ?>"><?php echo e($i); ?></option><?php endfor; ?></select></label>
            <textarea name="body" maxlength="1000" placeholder="Ceritakan rasanya..."></textarea>
            <button class="btn btn-primary">Kirim ulasan</button>
        </form>
    <?php endif; ?>
</section>

<section class="section">
    <h2>Obrolan dapur</h2>
    <?php $__currentLoopData = $recipe->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment"><strong><?php echo e($cm->user?->name ?? 'Anonim'); ?></strong><p><?php echo e($cm->body); ?></p></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(auth()->guard()->check()): ?>
        <form class="form" method="post" action="<?php echo e(route('comments.store', $recipe->slug)); ?>">
            <?php echo csrf_field(); ?>
            <textarea name="body" required placeholder="Tanya tips masak..."></textarea>
            <button class="btn btn-leaf">Kirim</button>
        </form>
    <?php endif; ?>
</section>

<?php if(count($related)): ?>
    <section class="section">
        <h2>Resep serupa</h2>
        <div class="grid-cards">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.recipe-card', ['recipe' => $rel], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/show.blade.php ENDPATH**/ ?>