<?php $__env->startSection('title', 'Kategori'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Katalog</p>
    <h1>Kategori</h1>
    <p class="muted">Kelompokkan resep agar mudah dijelajah pengunjung.</p>
  </div>
  <a class="btn btn-primary" href="<?php echo e(route('admin.kategori.create')); ?>">+ Tambah kategori</a>
</header>

<div class="tabs">
  <span class="tab is-on">Semua <b><?php echo e($cats->total()); ?></b></span>
</div>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Urutan</th><th>Nama</th><th>Slug</th><th>Resep</th><th>Deskripsi</th><th></th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->sort_order); ?></td>
            <td>
              <div class="cell-main">
                <?php if($c->image): ?>
                  <img class="thumb" src="<?php echo e(recipe_image($c->image)); ?>" alt="">
                <?php endif; ?>
                <div>
                  <strong><?php echo e($c->name); ?></strong>
                  <div class="muted small"><a href="<?php echo e(route('recipes.category', $c->slug)); ?>" target="_blank" rel="noopener">Lihat di situs ↗</a></div>
                </div>
              </div>
            </td>
            <td><code><?php echo e($c->slug); ?></code></td>
            <td><?php echo e($c->recipes_count); ?></td>
            <td class="muted"><?php echo e(excerpt_text($c->description, 70) ?: '—'); ?></td>
            <td class="row-actions">
              <a class="btn btn-sm btn-leaf" href="<?php echo e(route('admin.kategori.edit', $c)); ?>">Edit</a>
              <form method="post" action="<?php echo e(route('admin.kategori.destroy', $c)); ?>" onsubmit="return confirm('Hapus kategori <?php echo e($c->name); ?>?')" style="display:inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="muted">Belum ada kategori.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $cats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>