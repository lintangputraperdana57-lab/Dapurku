<?php $__env->startSection('title', 'Ulasan'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Ulasan</h1>
    <p class="muted">Moderasi ulasan resep: setujui, tahan, atau tolak.</p>
  </div>
  <span class="pill">Rata-rata <?php echo e($counts['avg'] ?: '—'); ?> ★</span>
</header>

<nav class="tabs">
  <?php
    $tabs = ['' => 'Semua', 'pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'];
    $base = request()->only(['rating']);
  ?>
  <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="tab <?php echo e($status === $key ? 'is-on' : ''); ?>" href="<?php echo e(route('admin.ulasan.index', array_filter($base + ['status' => $key], fn ($v) => $v !== '' && $v !== null))); ?>">
      <?php echo e($label); ?> <b><?php echo e($counts[$key ?: 'all']); ?></b>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pengguna</th><th>Resep</th><th>Rating</th><th>Ulasan</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><strong><?php echo e($rv->user?->name ?? 'Anonim'); ?></strong></td>
            <td>
              <?php if($rv->recipe): ?>
                <a href="<?php echo e(route('recipes.show', $rv->recipe->slug)); ?>" target="_blank" rel="noopener"><?php echo e($rv->recipe->title); ?></a>
              <?php else: ?>
                <span class="muted">—</span>
              <?php endif; ?>
            </td>
            <td><span class="stars"><?php echo e(str_repeat('★', (int) $rv->rating)); ?><?php echo e(str_repeat('☆', 5 - (int) $rv->rating)); ?></span></td>
            <td class="cell-body"><?php echo e($rv->body ?: '—'); ?></td>
            <td><span class="<?php echo e(status_class($rv->status)); ?>"><?php echo e(status_label($rv->status)); ?></span></td>
            <td class="muted nowrap"><?php echo e($rv->created_at?->translatedFormat('d M Y') ?? '—'); ?></td>
            <td>
              <div class="row-actions">
                <form method="post" action="<?php echo e(route('admin.ulasan.update', $rv)); ?>" class="inline-form">
                  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                  <select class="input input-sm" name="status">
                    <?php $__currentLoopData = ['approved' => 'Setujui', 'pending' => 'Tahan', 'rejected' => 'Tolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($k); ?>" <?php if($rv->status === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                <form method="post" action="<?php echo e(route('admin.ulasan.destroy', $rv)); ?>" onsubmit="return confirm('Hapus ulasan ini?')" style="display:inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" class="muted">Belum ada ulasan pada filter ini.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $reviews], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>