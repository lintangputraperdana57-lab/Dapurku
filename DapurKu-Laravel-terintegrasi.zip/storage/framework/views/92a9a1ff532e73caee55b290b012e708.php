<?php
    /** @var array $items  data piring (dari HomeController) */
    $items = $items ?? [];
    $legend = $legend ?? [
        1 => 'Mudah · ≤ 30 menit',
        2 => 'Cepat saji',
        3 => 'Sedang',
        4 => 'Butuh sabar',
        5 => 'Sulit · andalan chef',
    ];
    $eyebrow = $eyebrow ?? 'Kaiten · Sabuk dapur';
    $heading = $heading ?? 'Sabuk resep yang terus berputar, langsung di halaman.';
    $caption = $caption ?? 'Arahkan kursor untuk menghentikan sabuk, sentil untuk memutar, pilih piring untuk melihat resep.';
    $uid = 'cb' . substr(md5(json_encode(array_column($items, 'id'))), 0, 6);
?>
<?php if(count($items)): ?>
<section class="conveyor" data-conveyor id="<?php echo e($uid); ?>"
         data-items='<?php echo json_encode($items, 15, 512) ?>'
         data-speed="26" data-autoplay="true" data-interval="3200"
         data-label-open="Lihat resep" data-label-close="Tutup"
         data-label-previous="Piring sebelumnya" data-label-next="Piring berikut"
         data-label-pause="Hentikan sabuk" data-label-play="Jalankan sabuk"
         aria-labelledby="<?php echo e($uid); ?>-heading">

    <div class="cb-layout" data-conveyor-layout data-wide="true">
        <div class="cb-side">
            <div>
                <p class="cb-eyebrow"><?php echo e($eyebrow); ?></p>
                <h2 class="cb-heading" id="<?php echo e($uid); ?>-heading"><?php echo e($heading); ?></h2>
                <ul class="cb-legend" aria-hidden="true">
                    <?php $__currentLoopData = $legend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tier => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-tier="<?php echo e($tier); ?>"><span class="cb-dot"></span><?php echo e($label); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="cb-caption" data-conveyor-caption data-caption="<?php echo e($caption); ?>" aria-live="polite">
                <p class="cb-caption-idle"><?php echo e($caption); ?></p>
            </div>

            <?php if(isset($action)): ?>
                <div class="cb-action"><?php echo e($action); ?></div>
            <?php endif; ?>
        </div>

        <div class="cb-main">
            <div class="cb-stage" data-conveyor-stage role="group" aria-roledescription="sabuk konveyor" aria-label="<?php echo e($heading); ?>">
                <div class="cb-counter" data-conveyor-counter aria-hidden="true"></div>
                <div class="cb-belt" data-conveyor-belt aria-hidden="true">
                    <svg data-conveyor-svg xmlns="http://www.w3.org/2000/svg"></svg>
                </div>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="cb-plate" data-dish="<?php echo e($i); ?>" data-tier="<?php echo e($it['tier']); ?>" tabindex="<?php echo e($i === 0 ? 0 : -1); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if(count($items) > 1): ?>
                <div class="cb-controls">
                    <button type="button" class="cb-control" data-control="previous" aria-label="Piring sebelumnya"></button>
                    <button type="button" class="cb-control" data-control="pause" aria-label="Hentikan sabuk" aria-pressed="false"></button>
                    <button type="button" class="cb-control" data-control="next" aria-label="Piring berikut"></button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /home/user/DapurKu-Laravel/resources/views/partials/conveyor.blade.php ENDPATH**/ ?>