<?php $__env->startSection('title', 'Indeks bahan'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Indeks bahan</h2>
            <p class="muted">Pilih satu bahan untuk melihat resep yang memakainya.</p>
        </div>
    </div>
    <div class="chip-row" style="display:flex;flex-wrap:wrap;gap:10px">
        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="btn btn-ghost solid" href="<?php echo e(route('ingredients.show', $ing->slug)); ?>">
                <?php echo dk_icon('leaf', 15); ?> <?php echo e($ing->name); ?> <span class="muted">(<?php echo e($ing->recipes_count); ?>)</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/ingredients.blade.php ENDPATH**/ ?>