<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="<?php echo e($pageDesc ?? 'DapurKu-Pro — katalog resep masakan rumahan Indonesia: lauk Nusantara, menu 30 menit, rencana makan, dan daftar belanja.'); ?>">
    <meta name="theme-color" content="#c45c26">
    <meta name="csrf" content="<?php echo e(csrf_token()); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> · DapurKu-Pro</title>

    <link rel="icon" href="<?php echo e(asset('assets/icons/logo.svg')); ?>">
    <script>window.DK_BASE = '';</script>
    <script>
        window.DK_ROUTES = {
            search: <?php echo json_encode(route('api.search'), 15, 512) ?>,
            favorites: <?php echo json_encode(route('favorites.toggle'), 15, 512) ?>,
            ratings: <?php echo json_encode(route('ratings.store'), 15, 512) ?>,
        };
    </script>
    <script>if(localStorage.getItem('dk-dark')==='1')document.documentElement.classList.add('dark');</script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Source+Sans+3:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/conveyor.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/works-wheel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dark-mode.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<main class="container">
    <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/liquid-navbar.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/conveyor-belt.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/works-wheel.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/search.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/favorite.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/rating.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/cook-tools.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/user/DapurKu-Laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>