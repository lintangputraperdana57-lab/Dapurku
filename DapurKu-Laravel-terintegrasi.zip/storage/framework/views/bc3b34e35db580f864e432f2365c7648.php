<?php $__env->startSection('title', 'Tentang'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:760px;margin:0 auto">
    <div class="panel">
        <p class="cb-eyebrow">Tentang kami</p>
        <h2>DapurKu-Pro</h2>
        <p>Katalog resep masakan rumahan Indonesia. Dari rendang Padang sampai papeda Papua — resep pilihan
           dengan takaran jelas, langkah bernomor, timer masak, kalkulator porsi, dan filter alergi.</p>
        <p>Versi Laravel ini memuat seluruh katalog, komunitas, favorit, ulasan, dan panel admin dari aplikasi
           DapurKu-Pro, dengan desain baru: sabuk konveyor <em>kaiten</em> dan galeri roda berputar.</p>
        <div style="display:flex;gap:10px;margin-top:14px">
            <a class="btn btn-primary" href="<?php echo e(route('recipes.index')); ?>">Jelajahi resep</a>
            <a class="btn btn-ghost solid" href="<?php echo e(route('pages.kontak')); ?>">Hubungi kami</a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/pages/tentang.blade.php ENDPATH**/ ?>