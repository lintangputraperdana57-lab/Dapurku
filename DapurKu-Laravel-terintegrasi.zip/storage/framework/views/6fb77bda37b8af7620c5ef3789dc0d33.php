<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:460px;margin:0 auto">
    <div class="panel">
        <h2 style="text-align:center">Buat akun</h2>
        <p class="muted" style="text-align:center">Gratis — langsung bisa menyimpan favorit.</p>
        <form method="post" action="<?php echo e(route('register')); ?>" class="form" style="margin-top:14px">
            <?php echo csrf_field(); ?>
            <label>Nama
                <input class="input" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
            </label>
            <label>Email
                <input class="input" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
            </label>
            <label>Kata sandi
                <input class="input" type="password" name="password" required minlength="6">
            </label>
            <label>Ulangi kata sandi
                <input class="input" type="password" name="password_confirmation" required minlength="6">
            </label>
            <button class="btn btn-primary" type="submit">Daftar</button>
        </form>
        <p class="muted" style="text-align:center;margin-top:12px">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/auth/register.blade.php ENDPATH**/ ?>