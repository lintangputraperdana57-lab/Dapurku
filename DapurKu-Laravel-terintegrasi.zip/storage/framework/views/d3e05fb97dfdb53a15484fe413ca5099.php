<?php $__env->startSection('title', 'Komentar'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Komentar</h1>
    <p class="muted">Komentar pada halaman resep — termasuk balasan bertingkat.</p>
  </div>
</header>

<nav class="tabs">
  <?php $__currentLoopData = ['' => 'Semua', 'pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="tab <?php echo e($status === $key ? 'is-on' : ''); ?>" href="<?php echo e(route('admin.komentar.index', array_filter(['status' => $key]))); ?>">
      <?php echo e($label); ?> <b><?php echo e($counts[$key ?: 'all']); ?></b>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pengguna</th><th>Resep</th><th>Komentar</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><strong><?php echo e($cm->user?->name ?? 'Anonim'); ?></strong></td>
            <td>
              <?php if($cm->recipe): ?>
                <a href="<?php echo e(route('recipes.show', $cm->recipe->slug)); ?>" target="_blank" rel="noopener"><?php echo e($cm->recipe->title); ?></a>
              <?php else: ?>
                <span class="muted">—</span>
              <?php endif; ?>
            </td>
            <td class="cell-body">
              <?php if($cm->parent_id): ?> <span class="pill pill-quiet">balasan</span> <?php endif; ?>
              <?php echo e($cm->body); ?>

            </td>
            <td><span class="<?php echo e(status_class($cm->status)); ?>"><?php echo e(status_label($cm->status)); ?></span></td>
            <td class="muted nowrap"><?php echo e($cm->created_at?->translatedFormat('d M Y H:i') ?? '—'); ?></td>
            <td>
              <div class="row-actions">
                <form method="post" action="<?php echo e(route('admin.komentar.update', $cm)); ?>" class="inline-form">
                  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                  <select class="input input-sm" name="status">
                    <?php $__currentLoopData = ['approved' => 'Setujui', 'pending' => 'Tahan', 'rejected' => 'Tolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($k); ?>" <?php if($cm->status === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                <form method="post" action="<?php echo e(route('admin.komentar.destroy', $cm)); ?>" onsubmit="return confirm('Hapus komentar ini?')" style="display:inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="muted">Belum ada komentar pada filter ini.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $comments], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>