<?php $__env->startSection('title', 'Dasbor'); ?>
<?php
    $maxDay = max(1, ...array_column($days, 'n'));
    $maxTop = max(1, ...$top->pluck('views')->all());
    $maxCat = max(1, ...$byCat->pluck('n')->all());
    $colors = ['mudah' => '#2f6b3a', 'sedang' => '#d4a017', 'sulit' => '#c45c26'];
    $totalD = max(1, $diff->sum());
    $off = 0;
?>
<?php $__env->startSection('content'); ?>
<div class="dash-hero">
  <div>
    <p class="kicker">Ringkasan dapur</p>
    <h1>Halo, <?php echo e(auth()->user()->name); ?></h1>
    <p class="muted">Pantau katalog, lalu lintas, dan percakapan pengunjung dari satu layar.</p>
  </div>
  <div class="dash-actions">
    <a class="btn btn-primary" href="<?php echo e(route('admin.resep.create')); ?>">+ Tambah resep</a>
    <a class="btn btn-ghost" href="<?php echo e(route('home')); ?>">Lihat situs</a>
  </div>
</div>

<div class="kpi-grid">
  <article class="kpi"><span>Resep terbit</span><b><?php echo e($nRecipes - $nDraft); ?></b><small><?php echo e($nRecipes); ?> total · <?php echo e($nDraft); ?> draft/arsip</small></article>
  <article class="kpi kpi-clay"><span>Dilihat</span><b><?php echo e(format_number($nViews)); ?></b><small>akumulasi halaman resep</small></article>
  <article class="kpi kpi-leaf"><span>Pengguna</span><b><?php echo e($nUsers); ?></b><small><?php echo e($nFav); ?> resep disimpan</small></article>
  <article class="kpi"><span>Ulasan</span><b><?php echo e($nReviews); ?></b><small><?php echo e($nOpen); ?> laporan terbuka</small></article>
  <article class="kpi"><span>Pesan</span><b><?php echo e($nMsg); ?></b><small>formulir kontak</small></article>
</div>

<div class="dash-grid">
  <section class="panel span-2">
    <header class="panel-h">
      <h2>Kunjungan 7 hari</h2>
      <span class="muted">Termasuk halaman publik &amp; admin</span>
    </header>
    <div class="line-chart" role="img" aria-label="Grafik kunjungan">
      <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="lc-col">
          <span class="lc-val"><?php echo e($d['n']); ?></span>
          <i style="height:<?php echo e(max(8, (int) round(($d['n'] / $maxDay) * 140))); ?>px"></i>
          <small><?php echo e($d['label']); ?></small>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Resep per kategori</h2></header>
    <ul class="bar-list">
      <?php $__currentLoopData = $byCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <span><?php echo e($c->name); ?></span>
          <div class="bar"><i style="width:<?php echo e((int) round(($c->n / $maxCat) * 100)); ?>%"></i></div>
          <b><?php echo e($c->n); ?></b>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </section>

  <section class="panel span-2">
    <header class="panel-h">
      <h2>Paling ramai</h2>
      <a href="<?php echo e(route('admin.resep.index')); ?>">Kelola</a>
    </header>
    <div class="bar-list v-bars">
      <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="v-row">
          <a href="<?php echo e(route('recipes.show', $r->slug)); ?>"><?php echo e($r->title); ?></a>
          <div class="bar"><i style="width:<?php echo e((int) round(($r->views / $maxTop) * 100)); ?>%"></i></div>
          <span><?php echo e(format_number($r->views)); ?></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Tingkat kesulitan</h2></header>
    <svg viewBox="0 0 36 36" class="donut">
      <?php $__currentLoopData = $diff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $pct = ($n / $totalD) * 100; ?>
        <circle cx="18" cy="18" r="14" fill="none" stroke="<?php echo e($colors[$key] ?? '#8f3d14'); ?>" stroke-width="5"
          stroke-dasharray="<?php echo e(round($pct, 2)); ?> <?php echo e(round(100 - $pct, 2)); ?>"
          stroke-dashoffset="<?php echo e(round(-$off, 2)); ?>" transform="rotate(-90 18 18)"></circle>
        <?php $off += $pct; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </svg>
    <ul class="legend">
      <?php $__currentLoopData = $diff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><i style="background:<?php echo e($colors[$key] ?? '#999'); ?>"></i><?php echo e(difficulty_label($key)); ?> (<?php echo e($n); ?>)</li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </section>
</div>

<div class="dash-grid">
  <section class="panel">
    <header class="panel-h"><h2>Ulasan terbaru</h2></header>
    <?php $__empty_1 = true; $__currentLoopData = $latestRev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="feed-item">
        <strong><?php echo e($rv->user?->name ?? 'Anonim'); ?></strong> · <?php echo e(str_repeat('★', $rv->rating)); ?>

        <div class="muted"><?php echo e($rv->recipe?->title); ?></div>
        <p><?php echo e(excerpt_text($rv->body ?? '', 90)); ?></p>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="muted">Belum ada ulasan.</p>
    <?php endif; ?>
  </section>
  <section class="panel">
    <header class="panel-h"><h2>Pengguna baru</h2></header>
    <?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="feed-item"><strong><?php echo e($usr->name); ?></strong><div class="muted"><?php echo e($usr->email); ?> · <?php echo e($usr->role); ?></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
  <section class="panel">
    <header class="panel-h"><h2>Pesan kontak</h2></header>
    <?php $__empty_1 = true; $__currentLoopData = $latestMsg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="feed-item">
        <strong><?php echo e($m->subject ?: '(tanpa subjek)'); ?></strong>
        <div class="muted"><?php echo e($m->name); ?> · <?php echo e($m->created_at?->translatedFormat('d M Y') ?? '—'); ?></div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="muted">Kotak masuk kosong.</p>
    <?php endif; ?>
  </section>
</div>

<section class="panel">
  <header class="panel-h"><h2>Aksi cepat</h2></header>
  <div class="quick-grid">
    <a href="<?php echo e(route('admin.resep.create')); ?>">Tulis resep baru</a>
    <a href="<?php echo e(route('admin.resep.index')); ?>">Kelola resep</a>
    <a href="<?php echo e(route('recipes.index')); ?>">Lihat katalog</a>
    <a href="<?php echo e(route('community.index')); ?>">Buka komunitas</a>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>