<?php $__env->startSection('title', 'Jelajah daerah'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Jelajah resep daerah</h2>
        </div>
    </div>
    <div class="cat-grid">
        <?php $__currentLoopData = region_labels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="cat" href="<?php echo e(route('recipes.region', $slug)); ?>">
                <span class="ico"><?php echo dk_icon('map', 22); ?></span>
                <b><?php echo e($label); ?></b>
                <span class="muted"><?php echo e(format_number($counts[$slug] ?? 0)); ?> resep</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/regions.blade.php ENDPATH**/ ?>