<?php $__env->startSection('title', 'Favorit saya'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Dapurku</p>
            <h2>Favorit saya</h2>
            <p class="muted"><?php echo e(count($recipes)); ?> resep tersimpan.</p>
        </div>
    </div>
    <?php if(count($recipes)): ?>
        <div class="grid-cards">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="empty">
            <p class="muted">Belum ada favorit. Tekan ikon hati pada resep mana pun.</p>
            <a class="btn btn-primary" href="<?php echo e(route('recipes.index')); ?>">Jelajahi resep</a>
        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/favorites/index.blade.php ENDPATH**/ ?>