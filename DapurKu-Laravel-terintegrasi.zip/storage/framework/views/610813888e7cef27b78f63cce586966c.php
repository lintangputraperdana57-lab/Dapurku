<?php $__env->startSection('title', 'Kebijakan privasi'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:760px;margin:0 auto">
    <div class="panel">
        <h2>Kebijakan privasi</h2>
        <p>Kami hanya menyimpan data yang kamu berikan: nama, email, serta aktivitas favorit dan ulasan.
           Data tidak dijual maupun dibagikan ke pihak ketiga. Progres langkah memasak disimpan lokal di
           perambanmu (localStorage) dan tidak dikirim ke server.</p>
        <p>Kamu dapat menghapus akun beserta datanya kapan pun melalui tim kami di halaman kontak.</p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/pages/privasi.blade.php ENDPATH**/ ?>