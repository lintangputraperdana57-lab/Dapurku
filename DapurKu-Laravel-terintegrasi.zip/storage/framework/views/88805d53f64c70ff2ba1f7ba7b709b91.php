<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <a class="brand" href="<?php echo e(route('home')); ?>">
                <span class="brand-mark"><?php echo dk_icon('pot', 20); ?></span>
                <span class="brand-name"><b><?php echo e(setting('site_name', 'DapurKu')); ?></b><span>Pro</span></span>
            </a>
            <p class="muted"><?php echo e(setting('tagline', 'Resep rumahan Indonesia — dari dapur keluarga, untuk meja makanmu.')); ?></p>
        </div>
        <div>
            <strong>Jelajah</strong>
            <p>
                <a href="<?php echo e(route('recipes.index')); ?>">Semua resep</a><br>
                <a href="<?php echo e(route('recipes.allCategories')); ?>">Kategori</a><br>
                <a href="<?php echo e(route('recipes.allRegions')); ?>">Daerah</a><br>
                <a href="<?php echo e(route('recipes.daily')); ?>">Resep harian</a><br>
                <a href="<?php echo e(route('pages.kontak')); ?>">Kontak</a>
            </p>
        </div>
        <div>
            <strong>Dapurku</strong>
            <p>
                <a href="<?php echo e(route('favorites.index')); ?>">Favorit</a><br>
                <a href="<?php echo e(route('community.index')); ?>">Komunitas</a><br>
                <a href="<?php echo e(route('recipes.roulette')); ?>">Roulette menu</a>
            </p>
        </div>
        <div>
            <strong>Legal</strong>
            <p>
                <a href="<?php echo e(route('pages.privasi')); ?>">Privasi</a><br>
                <a href="<?php echo e(route('pages.syarat')); ?>">Syarat</a><br>
                <a href="<?php echo e(route('pages.tentang')); ?>">Tentang</a>
            </p>
        </div>
    </div>
    <div class="container footer-base">
        <span class="muted">© <?php echo e(date('Y')); ?> DapurKu-Pro · versi Laravel</span>
        <span class="muted"><?php echo e(setting('footer_note', 'Dibuat dengan 🍲 di Indonesia')); ?></span>
    </div>
</footer>
<?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>