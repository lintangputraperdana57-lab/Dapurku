<?php $__env->startSection('title', 'Bahan'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Katalog</p>
    <h1>Bahan</h1>
    <p class="muted">Daftar bahan baku yang dipakai resep — dipakai juga oleh filter bahan di situs.</p>
  </div>
  <a class="btn btn-primary" href="<?php echo e(route('admin.bahan.create')); ?>">+ Tambah bahan</a>
</header>

<form class="filter-bar" method="get" action="<?php echo e(route('admin.bahan.index')); ?>">
  <input class="input" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari bahan…">
  <button class="btn btn-sm btn-ghost" type="submit">Cari</button>
  <?php if($q !== ''): ?>
    <a class="btn btn-sm btn-ghost" href="<?php echo e(route('admin.bahan.index')); ?>">Reset</a>
  <?php endif; ?>
  <span class="muted small"><?php echo e($total); ?> bahan terdaftar</span>
</form>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Nama</th><th>Slug</th><th>Satuan</th><th>Dipakai</th><th>Deskripsi</th><th></th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><strong><?php echo e($i->name); ?></strong></td>
            <td><code><?php echo e($i->slug); ?></code></td>
            <td><?php echo e($i->unit); ?></td>
            <td><?php echo e($used[$i->id] ?? 0); ?>×</td>
            <td class="muted"><?php echo e(excerpt_text($i->description, 70) ?: '—'); ?></td>
            <td class="row-actions">
              <a class="btn btn-sm btn-ghost" href="<?php echo e(route('ingredients.show', $i->slug)); ?>" target="_blank" rel="noopener">Lihat</a>
              <a class="btn btn-sm btn-leaf" href="<?php echo e(route('admin.bahan.edit', $i)); ?>">Edit</a>
              <form method="post" action="<?php echo e(route('admin.bahan.destroy', $i)); ?>" onsubmit="return confirm('Hapus bahan <?php echo e($i->name); ?>?')" style="display:inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="muted">Tidak ada bahan yang cocok.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $ings], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/ingredients/index.blade.php ENDPATH**/ ?>