<?php $__env->startSection('title', $recipe->exists ? 'Edit resep' : 'Tambah resep'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <h1><?php echo e($recipe->exists ? 'Edit resep: ' . $recipe->title : 'Tambah resep'); ?></h1>
  <a class="btn btn-ghost" href="<?php echo e(route('admin.resep.index')); ?>">← Kembali</a>
</header>

<form method="post" action="<?php echo e($recipe->exists ? route('admin.resep.update', $recipe) : route('admin.resep.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php if($recipe->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <div class="dash-grid">
    <section class="panel span-2">
      <header class="panel-h"><h2>Info dasar</h2></header>
      <div class="form-grid">
        <label class="fld">Judul
          <input class="input" name="title" required maxlength="120" value="<?php echo e(old('title', $recipe->title)); ?>">
        </label>
        <label class="fld">Kategori
          <select class="input" name="category_id">
            <option value="">— pilih —</option>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>" <?php if(old('category_id', $recipe->category_id) == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <label class="fld">Daerah
          <select class="input" name="region_slug">
            <option value="">— pilih —</option>
            <?php $__currentLoopData = region_labels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($slug); ?>" <?php if(old('region_slug', $recipe->region_slug) === $slug): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <label class="fld">Status
          <select class="input" name="status">
            <?php $__currentLoopData = ['published' => 'Terbit', 'draft' => 'Draft', 'arsip' => 'Arsip']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($k); ?>" <?php if(old('status', $recipe->status ?? 'published') === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <label class="fld">Ringkasan
          <input class="input" name="excerpt" maxlength="400" value="<?php echo e(old('excerpt', $recipe->excerpt)); ?>">
        </label>
        <label class="fld">Deskripsi
          <textarea class="input" name="description" rows="3"><?php echo e(old('description', $recipe->description)); ?></textarea>
        </label>
      </div>
      <label class="checkbox"><input type="checkbox" name="is_featured" value="1" <?php if(old('is_featured', $recipe->is_featured)): echo 'checked'; endif; ?>> Tampilkan sebagai unggulan</label>
    </section>

    <section class="panel">
      <header class="panel-h"><h2>Waktu &amp; gizi</h2></header>
      <div class="form-grid">
        <label class="fld">Waktu masak (menit) *
          <input class="input" type="number" name="cook_time" min="1" max="1440" required value="<?php echo e(old('cook_time', $recipe->cook_time ?? 30)); ?>">
        </label>
        <label class="fld">Persiapan (menit)
          <input class="input" type="number" name="prep_time" min="0" max="1440" value="<?php echo e(old('prep_time', $recipe->prep_time)); ?>">
        </label>
        <label class="fld">Porsi
          <input class="input" type="number" name="servings" min="1" max="200" value="<?php echo e(old('servings', $recipe->servings ?? 4)); ?>">
        </label>
        <label class="fld">Kalori per porsi
          <input class="input" type="number" name="calories" min="0" max="5000" value="<?php echo e(old('calories', $recipe->calories)); ?>">
        </label>
        <label class="fld">Kesulitan
          <select class="input" name="difficulty">
            <?php $__currentLoopData = ['mudah' => 'Mudah', 'sedang' => 'Sedang', 'sulit' => 'Sulit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($k); ?>" <?php if(old('difficulty', $recipe->difficulty ?? 'mudah') === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <label class="fld">Foto
          <input class="input" type="file" name="image" accept="image/*">
        </label>
      </div>
      <?php if($recipe->image): ?>
        <p class="muted" style="margin-top:8px">Foto saat ini: <code><?php echo e($recipe->image); ?></code></p>
      <?php endif; ?>
    </section>

    <section class="panel span-2">
      <header class="panel-h"><h2>Bahan &amp; langkah</h2></header>
      <div class="form-grid">
        <label class="fld">Bahan (satu per baris, format <code>nama|jumlah|satuan</code>)
          <textarea class="input" name="ingredients" rows="10"><?php echo e(old('ingredients', $ingsText)); ?></textarea>
        </label>
        <label class="fld">Langkah (satu per baris)
          <textarea class="input" name="steps" rows="10"><?php echo e(old('steps', $stepsText)); ?></textarea>
        </label>
      </div>
      <p class="muted">Perubahan bahan &amp; langkah disimpan saat formulir dikirim.</p>
    </section>
  </div>

  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-primary" type="submit"><?php echo e($recipe->exists ? 'Simpan perubahan' : 'Tambah resep'); ?></button>
    <a class="btn btn-ghost" href="<?php echo e(route('admin.resep.index')); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/admin/recipes/form.blade.php ENDPATH**/ ?>