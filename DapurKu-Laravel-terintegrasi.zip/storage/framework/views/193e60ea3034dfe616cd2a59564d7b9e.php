<!DOCTYPE html>
<html lang="id" data-base="<?php echo e(url('/')); ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf" content="<?php echo e(csrf_token()); ?>">
<title>Admin · <?php echo $__env->yieldContent('title', 'Dasbor'); ?></title>
<script>window.DK_BASE = '';</script>
<script>if(localStorage.getItem('dk-dark')==='1')document.documentElement.classList.add('dark');</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Source+Sans+3:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dark-mode.css')); ?>">
</head>
<body>
<div class="admin-shell">
<aside class="admin-side">
  <div class="brand-mini"><span>🍲</span><strong>DapurKu Admin</strong></div>
  <?php $cur = \Illuminate\Support\Facades\Route::currentRouteName(); ?>
  <div class="nav-sec">Utama</div>
  <a class="<?php echo e(str_starts_with($cur, 'admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">Dasbor</a>
  <a class="<?php echo e(str_starts_with($cur, 'admin.resep') ? 'active' : ''); ?>" href="<?php echo e(route('admin.resep.index')); ?>">Resep</a>
  <div class="nav-sec">Situs</div>
  <a href="<?php echo e(route('home')); ?>">Lihat situs</a>
  <a href="<?php echo e(route('community.index')); ?>">Komunitas</a>
  <div class="nav-sec">Akun</div>
  <a><?php echo e(auth()->user()->name); ?></a>
  <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="side-link">Keluar</button></form>
</aside>
<main class="admin-main">
    <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
</div>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/admin.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/user/DapurKu-Laravel/resources/views/layouts/admin.blade.php ENDPATH**/ ?>