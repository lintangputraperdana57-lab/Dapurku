<?php $__env->startSection('title', 'Pengguna'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Pengguna</h1>
    <p class="muted">Atur peran dan status akun warga DapurKu.</p>
  </div>
  <div class="dash-actions">
    <span class="pill"><?php echo e($counts['all']); ?> akun</span>
    <span class="pill"><?php echo e($counts['banned']); ?> diblokir</span>
  </div>
</header>

<div class="kpi-grid kpi-grid-4">
  <article class="kpi"><span>Admin</span><b><?php echo e($counts['admin']); ?></b><small>akses penuh panel</small></article>
  <article class="kpi"><span>Moderator</span><b><?php echo e($counts['moderator']); ?></b><small>boleh masuk panel</small></article>
  <article class="kpi kpi-leaf"><span>Pengguna</span><b><?php echo e($counts['user']); ?></b><small>akun biasa</small></article>
  <article class="kpi kpi-clay"><span>Resep disimpan</span><b><?php echo e($counts['favorites']); ?></b><small>total favorit</small></article>
</div>

<form class="filter-bar" method="get" action="<?php echo e(route('admin.pengguna.index')); ?>">
  <input class="input" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama atau email…">
  <select class="input" name="role">
    <option value="">Semua peran</option>
    <?php $__currentLoopData = ['admin' => 'Admin', 'moderator' => 'Moderator', 'user' => 'Pengguna']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($k); ?>" <?php if($role === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <button class="btn btn-sm btn-ghost" type="submit">Terapkan</button>
  <?php if($q !== '' || $role !== ''): ?>
    <a class="btn btn-sm btn-ghost" href="<?php echo e(route('admin.pengguna.index')); ?>">Reset</a>
  <?php endif; ?>
</form>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Nama</th><th>Email</th><th>Resep</th><th>Ulasan</th><th>Peran &amp; status</th><th>Bergabung</th><th></th></tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <strong><?php echo e($u->name); ?></strong>
              <?php if($u->is(auth()->user())): ?> <span class="pill pill-quiet">kamu</span> <?php endif; ?>
            </td>
            <td class="muted"><?php echo e($u->email); ?></td>
            <td><?php echo e($u->recipes_count); ?></td>
            <td><?php echo e($u->reviews_count); ?></td>
            <td>
              <form method="post" action="<?php echo e(route('admin.pengguna.update', $u)); ?>" class="inline-form">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <select class="input input-sm" name="role">
                  <?php $__currentLoopData = ['admin' => 'Admin', 'moderator' => 'Moderator', 'user' => 'Pengguna']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k); ?>" <?php if($u->role === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select class="input input-sm" name="status">
                  <option value="active" <?php if($u->status === 'active'): echo 'selected'; endif; ?>>Aktif</option>
                  <option value="banned" <?php if($u->status === 'banned'): echo 'selected'; endif; ?>>Blokir</option>
                </select>
                <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
              </form>
            </td>
            <td class="muted nowrap"><?php echo e($u->created_at?->translatedFormat('d M Y') ?? '—'); ?></td>
            <td class="row-actions">
              <form method="post" action="<?php echo e(route('admin.pengguna.destroy', $u)); ?>" onsubmit="return confirm('Hapus akun <?php echo e($u->name); ?>?')" style="display:inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php echo $__env->make('partials.pager', ['paginator' => $users], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>