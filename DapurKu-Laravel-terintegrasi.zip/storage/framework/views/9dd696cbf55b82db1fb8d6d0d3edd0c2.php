<?php $crumbs = $crumbs ?? []; ?>
<?php if($crumbs): ?>
<p class="muted" style="margin:16px 0">
    <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($i > 0): ?> / <?php endif; ?>
        <?php if(!empty($c['url'])): ?>
            <a href="<?php echo e($c['url']); ?>"><?php echo e($c['label']); ?></a>
        <?php else: ?>
            <span><?php echo e($c['label']); ?></span>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<?php endif; ?>
<?php /**PATH /home/user/DapurKu-Laravel/resources/views/partials/breadcrumbs.blade.php ENDPATH**/ ?>