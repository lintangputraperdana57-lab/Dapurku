<?php
    /** @var array $items  butir roda kreasi */
    $items = $items ?? [];
?>
<?php if(count($items) >= 3): ?>
<section class="section" aria-labelledby="ww-heading">
    <div class="ww-head">
        <p class="cb-eyebrow">Galeri berputar</p>
        <h2 id="ww-heading" style="display:flex;justify-content:center;align-items:center;gap:10px">
            <span class="section-head-ico"><?php echo dk_icon('wheel', 20); ?></span>
            Kreasi anggota, berputar di satu roda.
        </h2>
        <p class="ww-caption">Roda berputar sendiri — arahkan kursor untuk memperlambat, seret untuk memutar, klik sebuah piring untuk membuka resepnya.</p>
    </div>

    <div class="ww" data-works-wheel data-speed="4.2" data-items='<?php echo json_encode($items, 15, 512) ?>'>
        <div class="ww-ring" data-ww-ring role="group" aria-label="Roda kreasi komunitas">
            <span class="ww-track" aria-hidden="true"></span>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="ww-item" data-ww-item href="<?php echo e($it['href']); ?>" aria-label="<?php echo e($it['title'] . ($it['meta'] ? ' — ' . $it['meta'] : '')); ?>">
                    <span class="ww-item-disc"><img src="<?php echo e($it['image']); ?>" alt="" loading="lazy" decoding="async"></span>
                    <span class="ww-item-label"><?php echo dk_icon('chef', 13); ?> <?php echo e($it['title']); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="ww-hub">
                <div class="ww-hub-inner">
                    <p class="ww-hub-sub">Dapur komunitas</p>
                    <p class="ww-hub-label">Kreasi ’26</p>
                    <p class="ww-hub-count"><?php echo dk_icon('sparkle', 13); ?> <?php echo e(count($items)); ?> karya</p>
                    <a class="ww-hub-action" href="<?php echo e(route('community.index')); ?>">Lihat semua <?php echo dk_icon('arrow-right', 14); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /home/user/DapurKu-Laravel/resources/views/partials/wheel.blade.php ENDPATH**/ ?>