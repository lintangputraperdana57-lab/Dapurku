<?php $__env->startSection('title', 'Kelola resep'); ?>
<?php $__env->startSection('content'); ?>
<header class="page-head">
  <h1>Resep</h1>
  <a class="btn btn-primary" href="<?php echo e(route('admin.resep.create')); ?>">+ Tambah resep</a>
</header>

<section class="panel">
  <table class="admin-table">
    <thead><tr><th>#</th><th>Judul</th><th>Kategori</th><th>Status</th><th>Dilihat</th><th></th></tr></thead>
    <tbody>
      <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($r->id); ?></td>
          <td><a href="<?php echo e(route('recipes.show', $r->slug)); ?>"><?php echo e($r->title); ?></a></td>
          <td><?php echo e($r->category?->name ?? '—'); ?></td>
          <td><span class="badge" style="position:static"><?php echo e($r->status); ?></span></td>
          <td><?php echo e(format_number($r->views)); ?></td>
          <td class="row-actions">
            <a class="btn btn-sm btn-ghost" href="<?php echo e(route('recipes.show', $r->slug)); ?>">Lihat</a>
            <a class="btn btn-sm btn-leaf" href="<?php echo e(route('admin.resep.edit', $r)); ?>">Edit</a>
            <form method="post" action="<?php echo e(route('admin.resep.destroy', $r)); ?>" onsubmit="return confirm('Hapus resep ini?')" style="display:inline">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo $__env->make('partials.pager', ['paginator' => $recipes], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/admin/recipes/index.blade.php ENDPATH**/ ?>