<?php /** @var \Illuminate\Pagination\LengthAwarePaginator $paginator */ ?>
<?php if($paginator->lastPage() > 1): ?>
<nav class="pager">
    <?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($page == $paginator->currentPage()): ?>
            <span><?php echo e($page); ?></span>
        <?php else: ?>
            <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php endif; ?>
<?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/partials/pager.blade.php ENDPATH**/ ?>