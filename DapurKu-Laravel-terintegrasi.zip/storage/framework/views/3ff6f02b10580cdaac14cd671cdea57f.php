<?php $__env->startSection('title', 'Filter alergi'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Makan aman</p>
            <h2>Filter alergi</h2>
            <p class="muted">Centang pemicu yang ingin dihindari — resep yang mengandungnya disingkirkan.</p>
        </div>
    </div>

    <form class="panel" method="get" action="<?php echo e(route('recipes.allergy')); ?>" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;margin-bottom:18px">
        <div style="display:flex;flex-wrap:wrap;gap:10px">
            <?php $__currentLoopData = $allergens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="checkbox"><input type="checkbox" name="hindari[]" value="<?php echo e($a); ?>" <?php if(in_array($a, $avoid)): echo 'checked'; endif; ?>> <?php echo e(ucfirst($a)); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="btn btn-primary" type="submit"><?php echo dk_icon('filter', 15); ?> Terapkan</button>
        <a class="btn btn-ghost solid" href="<?php echo e(route('recipes.allergy')); ?>">Reset</a>
    </form>

    <?php if(count($recipes)): ?>
        <div class="grid-cards">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="empty"><p class="muted">Tidak ada resep yang cocok dengan filter ini.</p></div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/allergy.blade.php ENDPATH**/ ?>