<?php
    $sideCats = \App\Models\Category::orderBy('sort_order')->orderBy('name')->get();
    $sidePop = \App\Models\Recipe::published()->orderByDesc('views')->limit(5)->get(['title', 'slug']);
    $sideRegions = [
        ['sumatera', 'Sumatera'], ['jawa', 'Jawa'], ['bali-nusa', 'Bali & Nusa'],
        ['kalimantan', 'Kalimantan'], ['sulawesi', 'Sulawesi'], ['maluku-papua', 'Maluku & Papua'],
    ];
?>
<aside>
    <div class="side-card">
        <h3>Kategori</h3>
        <?php $__currentLoopData = $sideCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><a href="<?php echo e(route('recipes.category', $c->slug)); ?>"><?php echo e($c->name); ?></a></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="side-card" style="margin-top:12px">
        <h3>Daerah</h3>
        <?php $__currentLoopData = $sideRegions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><a href="<?php echo e(route('recipes.region', $rg[0])); ?>"><?php echo e($rg[1]); ?></a></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="side-card" style="margin-top:12px">
        <h3>Sedang ramai</h3>
        <?php $__currentLoopData = $sidePop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><a href="<?php echo e(route('recipes.show', $p->slug)); ?>"><?php echo e($p->title); ?></a></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</aside>
<?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>