<?php $__env->startSection('title', 'Masuk'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:460px;margin:0 auto">
    <div class="panel">
        <h2 style="text-align:center">Masuk ke DapurKu</h2>
        <p class="muted" style="text-align:center">Simpan favorit, beri ulasan, dan kirim cerita ke komunitas.</p>
        <form method="post" action="<?php echo e(route('login')); ?>" class="form" style="margin-top:14px">
            <?php echo csrf_field(); ?>
            <label>Email
                <input class="input" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
            </label>
            <label>Kata sandi
                <input class="input" type="password" name="password" required>
            </label>
            <label class="checkbox"><input type="checkbox" name="remember" value="1"> Ingat saya</label>
            <button class="btn btn-primary" type="submit">Masuk</button>
        </form>
        <p class="muted" style="text-align:center;margin-top:12px">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar</a></p>
        <p class="muted" style="text-align:center;font-size:13px">Demo: <code>admin@dapurku.pro / admin123</code> · <code>sari@dapurku.pro / user123</code></p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>