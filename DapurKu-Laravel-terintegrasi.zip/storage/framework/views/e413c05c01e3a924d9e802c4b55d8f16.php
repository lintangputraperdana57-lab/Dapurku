<?php $__env->startSection('title', 'Semua kategori'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Semua kategori</h2>
        </div>
    </div>
    <div class="cat-grid">
        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="cat" href="<?php echo e(route('recipes.category', $cat->slug)); ?>">
                <span class="ico"><?php echo dk_icon($cat->icon ?: 'pot', 22); ?></span>
                <b><?php echo e($cat->name); ?></b>
                <span class="muted"><?php echo e(format_number($cat->published_count)); ?> resep<?php echo e($cat->description ? ' · ' . $cat->description : ''); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/categories.blade.php ENDPATH**/ ?>