<?php $__env->startSection('title', 'Komunitas'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Dapur bersama</p>
            <h2>Komunitas DapurKu</h2>
            <p class="muted">Cerita, tips, dan hasil masakan dari anggota.</p>
        </div>
    </div>

    <div class="detail-grid">
        <div class="detail-main">
            <ul class="posts">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="panel post">
                        <div class="rev-head">
                            <b><?php echo e($post->user?->name ?? 'Anonim'); ?></b>
                            <?php if($post->recipe): ?>
                                <a href="<?php echo e(route('recipes.show', $post->recipe->slug)); ?>"><?php echo dk_icon('pot', 13); ?> <?php echo e($post->recipe->title); ?></a>
                            <?php endif; ?>
                            <span class="muted"><?php echo e($post->created_at->translatedFormat('d M Y H:i')); ?></span>
                        </div>
                        <h3><?php echo e($post->title); ?></h3>
                        <p><?php echo e($post->body); ?></p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="empty"><p class="muted">Belum ada cerita. Tulis yang pertama!</p></li>
                <?php endif; ?>
            </ul>
        </div>
        <aside class="detail-side">
            <div class="panel">
                <h3><?php echo dk_icon('send', 17); ?> Tulis cerita</h3>
                <?php if(auth()->guard()->check()): ?>
                    <form method="post" action="<?php echo e(route('community.store')); ?>" class="form">
                        <?php echo csrf_field(); ?>
                        <label>Judul
                            <input class="input" name="title" maxlength="120" required value="<?php echo e(old('title')); ?>">
                        </label>
                        <label>Cerita
                            <textarea class="input" name="body" rows="5" maxlength="2000" required><?php echo e(old('body')); ?></textarea>
                        </label>
                        <button class="btn btn-primary btn-sm" type="submit">Kirim</button>
                    </form>
                <?php else: ?>
                    <p class="muted"><a href="<?php echo e(route('login')); ?>">Masuk</a> untuk ikut berbagi cerita.</p>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/community/index.blade.php ENDPATH**/ ?>