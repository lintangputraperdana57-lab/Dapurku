<?php $__env->startSection('title', 'Syarat & ketentuan'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:760px;margin:0 auto">
    <div class="panel">
        <h2>Syarat &amp; ketentuan</h2>
        <p>Dengan menggunakan DapurKu-Pro kamu setuju untuk berbagi konten yang sopan dan relevan dengan memasak.
           Resep yang dibagikan anggota menjadi tanggung jawab penulisnya; tim kami dapat menghapus konten yang
           melanggar.</p>
        <p>Hasil masakan bisa berbeda tergantung bahan dan peralatan. Selalu pastikan makanan matang sempurna,
           terutama untuk anak-anak, ibu hamil, dan anggota keluarga dengan alergi.</p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/pages/syarat.blade.php ENDPATH**/ ?>