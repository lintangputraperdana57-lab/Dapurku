<!DOCTYPE html>
<html lang="id" data-base="<?php echo e(url('/')); ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf" content="<?php echo e(csrf_token()); ?>">
<title>Admin · <?php echo $__env->yieldContent('title', 'Dasbor'); ?></title>
<script>window.DK_BASE = '';</script>
<script>if(localStorage.getItem('dk-dark')==='1')document.documentElement.classList.add('dark');</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Source+Sans+3:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dark-mode.css')); ?>">
</head>
<body>
<?php
    $cur = \Illuminate\Support\Facades\Route::currentRouteName();
    /** Tandai menu aktif berdasarkan awalan nama rute. */
    $act = fn (array $prefixes): string => collect($prefixes)->contains(fn ($p) => str_starts_with((string) $cur, $p)) ? 'active' : '';
    $unreadMsg = \App\Models\Message::where('is_read', false)->count();
    $openReports = \App\Models\Report::where('status', 'open')->count();
?>
<div class="admin-shell">
<aside class="admin-side">
  <div class="brand-mini"><span><?php echo dk_icon('pot', 18); ?></span><strong>DapurKu Admin</strong></div>

  <div class="nav-sec">Utama</div>
  <a class="<?php echo e($act(['admin.dashboard'])); ?>" href="<?php echo e(route('admin.dashboard')); ?>">Dasbor</a>
  <a class="<?php echo e($act(['admin.resep'])); ?>" href="<?php echo e(route('admin.resep.index')); ?>">Resep</a>
  <a class="<?php echo e($act(['admin.kategori'])); ?>" href="<?php echo e(route('admin.kategori.index')); ?>">Kategori</a>
  <a class="<?php echo e($act(['admin.bahan'])); ?>" href="<?php echo e(route('admin.bahan.index')); ?>">Bahan</a>

  <div class="nav-sec">Komunitas</div>
  <a class="<?php echo e($act(['admin.pengguna'])); ?>" href="<?php echo e(route('admin.pengguna.index')); ?>">Pengguna</a>
  <a class="<?php echo e($act(['admin.ulasan'])); ?>" href="<?php echo e(route('admin.ulasan.index')); ?>">Ulasan</a>
  <a class="<?php echo e($act(['admin.komentar'])); ?>" href="<?php echo e(route('admin.komentar.index')); ?>">Komentar</a>
  <a class="<?php echo e($act(['admin.laporan'])); ?>" href="<?php echo e(route('admin.laporan.index')); ?>">
    Laporan <?php if($openReports > 0): ?><span class="side-count"><?php echo e($openReports); ?></span><?php endif; ?>
  </a>
  <a class="<?php echo e($act(['admin.pesan'])); ?>" href="<?php echo e(route('admin.pesan.index')); ?>">
    Pesan <?php if($unreadMsg > 0): ?><span class="side-count"><?php echo e($unreadMsg); ?></span><?php endif; ?>
  </a>

  <div class="nav-sec">Situs</div>
  <a class="<?php echo e($act(['admin.banner'])); ?>" href="<?php echo e(route('admin.banner.index')); ?>">Banner</a>
  <a class="<?php echo e($act(['admin.statistik'])); ?>" href="<?php echo e(route('admin.statistik')); ?>">Statistik</a>
  <a class="<?php echo e($act(['admin.pengaturan'])); ?>" href="<?php echo e(route('admin.pengaturan.index')); ?>">Pengaturan</a>
  <a class="<?php echo e($act(['admin.log'])); ?>" href="<?php echo e(route('admin.log.index')); ?>">Log</a>

  <div class="nav-sec">Akun</div>
  <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener">Lihat situs</a>
  <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="side-link">Keluar</button></form>
</aside>
<main class="admin-main">
    <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
</div>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/admin.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\DapurKu-Laravel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>