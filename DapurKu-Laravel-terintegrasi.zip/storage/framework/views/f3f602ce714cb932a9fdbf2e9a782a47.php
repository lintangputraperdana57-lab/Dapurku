<?php $__env->startSection('title', $heading); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.breadcrumbs', ['crumbs' => [
    ['label' => 'Beranda', 'url' => route('home')],
    ['label' => $heading],
]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="layout-2">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div>
        <div class="section-head">
            <h1><?php echo e($heading); ?></h1>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('admin.resep.create')); ?>">Tambah resep</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if(isset($desc)): ?><p class="muted"><?php echo e($desc); ?></p><?php endif; ?>
        <form class="toolbar" action="<?php echo e(route('recipes.search')); ?>" method="get" style="margin-bottom:14px">
            <input class="input" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari resep…" aria-label="Cari resep">
            <button class="btn btn-ghost solid" type="submit"><?php echo dk_icon('search', 15); ?> Cari</button>
        </form>
        <?php if(count($recipes)): ?>
            <div class="grid-cards">
                <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.recipe-card', ['recipe' => $recipe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('partials.pager', ['paginator' => $recipes], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <p class="empty">Belum ada resep.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/recipes/index.blade.php ENDPATH**/ ?>