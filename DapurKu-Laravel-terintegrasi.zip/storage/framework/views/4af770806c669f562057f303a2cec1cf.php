<?php $__env->startSection('title', 'Kontak'); ?>
<?php $__env->startSection('content'); ?>
<section class="section rv" style="max-width:640px;margin:0 auto">
    <div class="panel">
        <h2>Hubungi kami</h2>
        <p class="muted">Ada usulan resep, koreksi, atau kerja sama? Kirim pesan di bawah.</p>
        <form method="post" action="<?php echo e(route('pages.kontak')); ?>" class="form" style="margin-top:12px">
            <?php echo csrf_field(); ?>
            <label>Nama
                <input class="input" name="name" required value="<?php echo e(old('name')); ?>">
            </label>
            <label>Email
                <input class="input" type="email" name="email" required value="<?php echo e(old('email')); ?>">
            </label>
            <label>Subjek
                <input class="input" name="subject" maxlength="120" value="<?php echo e(old('subject')); ?>">
            </label>
            <label>Pesan
                <textarea class="input" name="body" rows="5" required><?php echo e(old('body')); ?></textarea>
            </label>
            <button class="btn btn-primary" type="submit"><?php echo dk_icon('send', 15); ?> Kirim pesan</button>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/DapurKu-Laravel/resources/views/pages/kontak.blade.php ENDPATH**/ ?>