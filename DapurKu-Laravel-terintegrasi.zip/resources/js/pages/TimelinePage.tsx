"use client";

import { ArrowLeft, MousePointerClick, RotateCw } from "lucide-react";
import { RadialOrbitalTimelineDemo } from "@/components/timeline-demo";

/**
 * Halaman React untuk rute /perjalanan-dapur.
 *
 * RadialOrbitalTimeline sendiri berukuran h-screen (layar penuh),
 * jadi header & petunjuk dibuat sebagai overlay absolut di atasnya
 * agar tetap imersif. Wrapper `scale-*` menangani layar kecil:
 * radius orbit bawaan komponen adalah 200px (diameter 400px),
 * yang akan terpotong di layar < 400px tanpa penskalaan ini.
 */
export default function TimelinePage() {
  return (
    <div className="relative bg-black min-h-screen overflow-hidden">
      {/* Header overlay */}
      <header className="absolute top-0 inset-x-0 z-50 flex items-start justify-between gap-4 p-4 sm:p-6 pointer-events-none">
        <div className="pointer-events-auto">
          <a
            href="/"
            className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-black/60 px-3 py-1.5 text-xs font-semibold tracking-wider text-white/80 backdrop-blur-md transition-colors hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft size={14} />
            Kembali ke beranda
          </a>
          <h1 className="mt-3 text-lg sm:text-2xl font-bold tracking-tight text-white">
            Perjalanan Dapur
          </h1>
          <p className="mt-1 max-w-xs text-xs sm:text-sm text-white/60">
            Alur masak rendang dalam satu orbit — klik node untuk melihat
            detail tiap tahap.
          </p>
        </div>
      </header>

      {/* Timeline dengan penskalaan responsif */}
      <div className="origin-center scale-[0.55] sm:scale-75 md:scale-90 xl:scale-100">
        <RadialOrbitalTimelineDemo />
      </div>

      {/* Petunjuk kaki halaman */}
      <footer className="absolute bottom-0 inset-x-0 z-50 flex flex-wrap items-center justify-center gap-x-5 gap-y-1 p-4 text-[11px] text-white/50 pointer-events-none">
        <span className="inline-flex items-center gap-1.5">
          <MousePointerClick size={12} />
          Klik node untuk detail
        </span>
        <span className="inline-flex items-center gap-1.5">
          <RotateCw size={12} />
          Klik latar untuk memutar ulang
        </span>
      </footer>
    </div>
  );
}
