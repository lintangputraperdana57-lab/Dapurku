"use client";

import {
  ShoppingBasket,
  ChefHat,
  Flame,
  CookingPot,
  Scale,
  UtensilsCrossed,
} from "lucide-react";
import RadialOrbitalTimeline from "@/components/ui/radial-orbital-timeline";

/**
 * Demo data yang disesuaikan untuk DapurKu.
 * Versi asli dari task memakai timeline proyek software
 * (Planning → Design → Development → Testing → Release);
 * di sini diganti menjadi alur masak rendang agar nyambung
 * dengan konteks aplikasi resep. Struktur datanya sama persis:
 * id, title, date, content, category, icon, relatedIds, status, energy.
 */
const timelineData = [
  {
    id: 1,
    title: "Persiapan",
    date: "10 mnt",
    content:
      "Cuci dan potong daging sapi, siapkan santan, dan timbang semua bumbu. Persiapan yang rapi membuat proses masak jauh lebih tenang.",
    category: "Persiapan",
    icon: ShoppingBasket,
    relatedIds: [2],
    status: "completed" as const,
    energy: 100,
  },
  {
    id: 2,
    title: "Bumbu Halus",
    date: "15 mnt",
    content:
      "Haluskan cabai merah, bawang merah, bawang putih, kemiri, kunyit, dan jahe hingga benar-benar halus agar bumbu meresap ke serat daging.",
    category: "Bumbu",
    icon: ChefHat,
    relatedIds: [1, 3],
    status: "completed" as const,
    energy: 90,
  },
  {
    id: 3,
    title: "Tumis Bumbu",
    date: "20 mnt",
    content:
      "Tumis bumbu halus bersama serai, lengkuas, daun jeruk, dan daun kunyit hingga harum dan minyaknya keluar. Ini kunci aroma rendang.",
    category: "Tumis",
    icon: Flame,
    relatedIds: [2, 4],
    status: "completed" as const,
    energy: 75,
  },
  {
    id: 4,
    title: "Masak Santan",
    date: "60 mnt",
    content:
      "Masukkan daging dan santan, masak dengan api kecil sambil sesekali diaduk hingga santan menyusut dan bumbu meresap sempurna.",
    category: "Masak",
    icon: CookingPot,
    relatedIds: [3, 5],
    status: "in-progress" as const,
    energy: 55,
  },
  {
    id: 5,
    title: "Koreksi Rasa",
    date: "5 mnt",
    content:
      "Cicipi dan sesuaikan garam, gula merah, dan asam kandis. Rasa rendang yang pas adalah gurih, pedas, dan sedikit manis di akhir.",
    category: "Rasa",
    icon: Scale,
    relatedIds: [4, 6],
    status: "pending" as const,
    energy: 30,
  },
  {
    id: 6,
    title: "Plating",
    date: "5 mnt",
    content:
      "Tata rendang di piring saji bersama nasi hangat dan taburan bawang goreng. Sajikan selagi panas untuk pengalaman terbaik.",
    category: "Saji",
    icon: UtensilsCrossed,
    relatedIds: [5],
    status: "pending" as const,
    energy: 10,
  },
];

export function RadialOrbitalTimelineDemo() {
  return (
    <>
      <RadialOrbitalTimeline timelineData={timelineData} />
    </>
  );
}

export default {
  RadialOrbitalTimelineDemo,
};
