import { createRoot } from "react-dom/client";
import TimelinePage from "./pages/TimelinePage";

// Entry React untuk halaman yang memuat @vite(['resources/css/app.css', 'resources/js/app.tsx']).
// Saat ini dipakai oleh view timeline.blade.php (rute /perjalanan-dapur).
const el = document.getElementById("react-timeline");

if (el) {
  createRoot(el).render(<TimelinePage />);
}
