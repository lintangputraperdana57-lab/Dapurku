@extends('layouts.app')
@section('title', 'Favorit saya')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Dapurku</p>
            <h2>Favorit saya</h2>
            <p class="muted">{{ count($recipes) }} resep tersimpan.</p>
        </div>
    </div>
    @if (count($recipes))
        <div class="grid-cards">
            @foreach ($recipes as $recipe)
                @include('partials.recipe-card', ['recipe' => $recipe])
            @endforeach
        </div>
    @else
        <div class="empty">
            <p class="muted">Belum ada favorit. Tekan ikon hati pada resep mana pun.</p>
            <a class="btn btn-primary" href="{{ route('recipes.index') }}">Jelajahi resep</a>
        </div>
    @endif
</section>
@endsection
