@extends('layouts.app')
@section('title', 'Jelajah daerah')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Jelajah resep daerah</h2>
        </div>
    </div>
    <div class="cat-grid">
        @foreach (region_labels() as $slug => $label)
            <a class="cat" href="{{ route('recipes.region', $slug) }}">
                <span class="ico">{!! dk_icon('map', 22) !!}</span>
                <b>{{ $label }}</b>
                <span class="muted">{{ format_number($counts[$slug] ?? 0) }} resep</span>
            </a>
        @endforeach
    </div>
</section>
@endsection
