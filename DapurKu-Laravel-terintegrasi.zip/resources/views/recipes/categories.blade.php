@extends('layouts.app')
@section('title', 'Semua kategori')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Semua kategori</h2>
        </div>
    </div>
    <div class="cat-grid">
        @foreach ($cats as $cat)
            <a class="cat" href="{{ route('recipes.category', $cat->slug) }}">
                <span class="ico">{!! dk_icon($cat->icon ?: 'pot', 22) !!}</span>
                <b>{{ $cat->name }}</b>
                <span class="muted">{{ format_number($cat->published_count) }} resep{{ $cat->description ? ' · ' . $cat->description : '' }}</span>
            </a>
        @endforeach
    </div>
</section>
@endsection
