@extends('layouts.app')
@section('title', 'Indeks bahan')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Katalog</p>
            <h2>Indeks bahan</h2>
            <p class="muted">Pilih satu bahan untuk melihat resep yang memakainya.</p>
        </div>
    </div>
    <div class="chip-row" style="display:flex;flex-wrap:wrap;gap:10px">
        @foreach ($ingredients as $ing)
            <a class="btn btn-ghost solid" href="{{ route('ingredients.show', $ing->slug) }}">
                {!! dk_icon('leaf', 15) !!} {{ $ing->name }} <span class="muted">({{ $ing->recipes_count }})</span>
            </a>
        @endforeach
    </div>
</section>
@endsection
