@extends('layouts.app')
@section('title', 'Filter alergi')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Makan aman</p>
            <h2>Filter alergi</h2>
            <p class="muted">Centang pemicu yang ingin dihindari — resep yang mengandungnya disingkirkan.</p>
        </div>
    </div>

    <form class="panel" method="get" action="{{ route('recipes.allergy') }}" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;margin-bottom:18px">
        <div style="display:flex;flex-wrap:wrap;gap:10px">
            @foreach ($allergens as $a)
                <label class="checkbox"><input type="checkbox" name="hindari[]" value="{{ $a }}" @checked(in_array($a, $avoid))> {{ ucfirst($a) }}</label>
            @endforeach
        </div>
        <button class="btn btn-primary" type="submit">{!! dk_icon('filter', 15) !!} Terapkan</button>
        <a class="btn btn-ghost solid" href="{{ route('recipes.allergy') }}">Reset</a>
    </form>

    @if (count($recipes))
        <div class="grid-cards">
            @foreach ($recipes as $recipe)
                @include('partials.recipe-card', ['recipe' => $recipe])
            @endforeach
        </div>
    @else
        <div class="empty"><p class="muted">Tidak ada resep yang cocok dengan filter ini.</p></div>
    @endif
</section>
@endsection
