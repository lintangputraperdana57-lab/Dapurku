@extends('layouts.app')
@section('title', $heading)
@section('content')
@include('partials.breadcrumbs', ['crumbs' => [
    ['label' => 'Beranda', 'url' => route('home')],
    ['label' => $heading],
]])
<div class="layout-2">
    @include('partials.sidebar')
    <div>
        <div class="section-head">
            <h1>{{ $heading }}</h1>
            @auth
                @if (auth()->user()->isAdmin())
                    <a class="btn btn-primary" href="{{ route('admin.resep.create') }}">Tambah resep</a>
                @endif
            @endauth
        </div>
        @isset($desc)<p class="muted">{{ $desc }}</p>@endisset
        <form class="toolbar" action="{{ route('recipes.search') }}" method="get" style="margin-bottom:14px">
            <input class="input" name="q" value="{{ request('q') }}" placeholder="Cari resep…" aria-label="Cari resep">
            <button class="btn btn-ghost solid" type="submit">{!! dk_icon('search', 15) !!} Cari</button>
        </form>
        @if (count($recipes))
            <div class="grid-cards">
                @foreach ($recipes as $recipe)
                    @include('partials.recipe-card', ['recipe' => $recipe])
                @endforeach
            </div>
            @include('partials.pager', ['paginator' => $recipes])
        @else
            <p class="empty">Belum ada resep.</p>
        @endif
    </div>
</div>
@endsection
