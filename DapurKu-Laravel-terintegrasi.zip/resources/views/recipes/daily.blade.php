@extends('layouts.app')
@section('title', 'Resep harian')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">{!! dk_icon('sun', 14) !!} Baru tiap hari</p>
            <h2>Resep hari ini</h2>
            <p class="muted">Pilihan dapur untuk {{ now()->translatedFormat('l, d F Y') }}.</p>
        </div>
        <a class="btn btn-ghost solid" href="{{ route('recipes.roulette') }}">Acak lagi {!! dk_icon('dice', 15) !!}</a>
    </div>
    @if ($recipe)
        <div class="grid-cards" style="grid-template-columns:minmax(0,420px)">
            @include('partials.recipe-card', ['recipe' => $recipe])
        </div>
    @else
        <div class="empty"><p class="muted">Belum ada resep.</p></div>
    @endif
</section>
@endsection
