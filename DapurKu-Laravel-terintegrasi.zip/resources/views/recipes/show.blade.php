@extends('layouts.app')
@section('title', $recipe->title)
@section('content')
@php
    $avg = $recipe->avgRating();
    $isFav = $recipe->isFavoritedBy(auth()->id());
@endphp
@include('partials.breadcrumbs', ['crumbs' => [
    ['label' => 'Beranda', 'url' => route('home')],
    ['label' => 'Resep', 'url' => route('recipes.index')],
    ['label' => $recipe->title],
]])

<article class="recipe-hero">
    <div class="recipe-cover">
        @if ($recipe->image)
            <img src="{{ recipe_image($recipe->image) }}" alt="">
        @else
            <div class="placeholder-art" style="min-height:320px"></div>
        @endif
    </div>
    <div>
        <p class="kicker">
            {{ $recipe->category?->name ?? '' }}
            @if ($recipe->region_slug) · {{ region_labels()[$recipe->region_slug] ?? $recipe->region_slug }} @endif
        </p>
        <h1>{{ $recipe->title }}</h1>
        <p class="lede">{{ $recipe->excerpt }}</p>
        <p class="stars">★ {{ number_format($avg, 1, ',', '.') }} · {{ format_number($recipe->views) }} kali dilihat</p>
        <p class="meta">
            <span>Masak {{ format_minutes($recipe->cook_time) }}</span>
            <span>Persiapan {{ format_minutes($recipe->prep_time) }}</span>
            <span>{{ difficulty_label($recipe->difficulty) }}</span>
            <span>{{ (int) $recipe->servings }} porsi</span>
            <span>🔥 {{ (int) $recipe->calories }} kkal / porsi</span>
        </p>
        @if ($recipe->allergens->count())
            <p class="meta">Alergen:
                @foreach ($recipe->allergens as $a)<span class="chip">{{ $a->allergen }}</span>@endforeach
            </p>
        @endif
        <div class="toolbar">
            <button class="icon-btn{{ $isFav ? ' is-on' : '' }}" data-fav="{{ $recipe->id }}">{{ $isFav ? '♥ Favorit' : '♡ Simpan' }}</button>
            <a class="icon-btn" href="{{ route('recipes.show', $recipe->slug) }}?cetak=1" onclick="window.print();return false;">Cetak</a>
            @auth
                @if (auth()->user()->isAdmin())
                    <a class="btn btn-primary" href="{{ route('admin.resep.edit', $recipe) }}">Edit</a>
                @endif
            @endauth
        </div>
        <div class="calc-box">
            <strong>Kalkulator porsi</strong>
            <p class="muted">Ubah jumlah porsi, bahan ikut terhitung.</p>
            <p>Porsi
                <input data-servings data-base="{{ (int) $recipe->servings }}" type="number" min="1" value="{{ (int) $recipe->servings }}" style="width:80px;display:inline-block">
            </p>
            <p>Kalori total: <b data-cal-total data-cal="{{ (int) $recipe->calories }}">{{ (int) $recipe->calories * (int) $recipe->servings }}</b> kkal</p>
        </div>
        <div class="timer-box">
            <strong>Timer masak</strong>
            <p>
                <input id="timerMin" type="number" min="1" value="{{ max(1, (int) $recipe->cook_time) }}" style="width:70px"> menit
                <button class="btn btn-sm btn-primary" type="button" id="timerStart">Mulai</button>
                <button class="btn btn-sm btn-ghost solid" type="button" id="timerStop">Stop</button>
            </p>
            <p class="timer-display" id="timerDisp">00:00</p>
        </div>
        @auth
            <div data-recipe="{{ $recipe->id }}" class="stars">
                Nilai:
                @for ($i = 1; $i <= 5; $i++)
                    <span data-rate="{{ $i }}" style="cursor:pointer">{{ $i <= round($avg) ? '★' : '☆' }}</span>
                @endfor
            </div>
        @else
            <p class="muted"><a href="{{ route('login') }}">Masuk</a> untuk memberi nilai &amp; ulasan.</p>
        @endauth
    </div>
</article>

<section class="section">
    <p>{!! nl2br(e($recipe->description ?? '')) !!}</p>
    <div class="layout-2">
        <div>
            <h2>Bahan</h2>
            <ul class="ings">
                @forelse ($recipe->ingredients->sortBy('sort_order') as $ing)
                    <li>
                        <span>{{ $ing->name }}</span>
                        <span><b data-qty="{{ $ing->quantity }}">{{ $ing->quantity }}</b> {{ $ing->unit }}</span>
                    </li>
                @empty
                    <li class="muted">Bahan belum diisi.</li>
                @endforelse
            </ul>
        </div>
        <div>
            <h2>Langkah (centang saat selesai)</h2>
            <div class="steps" data-check-steps="{{ $recipe->id }}">
                @forelse ($recipe->steps->sortBy('step_number') as $st)
                    <label class="step step-check">
                        <input type="checkbox" data-step="{{ (int) $st->step_number }}">
                        {{ $st->instruction }}
                    </label>
                @empty
                    <p class="muted">Langkah belum diisi.</p>
                @endforelse
            </div>
        </div>
    </div>
</section>

@if ($recipe->nutrition)
    <section class="section">
        <h2>Nutrisi per porsi</h2>
        <div class="stat-row">
            <div class="stat"><span>Kalori</span><b>{{ (int) $recipe->calories }}</b> kkal</div>
            <div class="stat"><span>Protein</span><b>{{ $recipe->nutrition->protein }}</b> g</div>
            <div class="stat"><span>Lemak</span><b>{{ $recipe->nutrition->fat }}</b> g</div>
            <div class="stat"><span>Karbo</span><b>{{ $recipe->nutrition->carbs }}</b> g</div>
            <div class="stat"><span>Serat</span><b>{{ $recipe->nutrition->fiber }}</b> g</div>
        </div>
        <p class="muted">Perkiraan dapur rumahan, bukan hasil lab.</p>
    </section>
@endif

<section class="section">
    <h2>Ulasan &amp; rating</h2>
    @foreach ($recipe->reviews as $rv)
        <div class="comment"><strong>{{ $rv->user?->name ?? 'Anonim' }}</strong> · {{ str_repeat('★', (int) $rv->rating) }}<p>{{ $rv->body }}</p></div>
    @endforeach
    @auth
        <form class="form" method="post" action="{{ route('reviews.store', $recipe->slug) }}">
            @csrf
            <label>Rating <select name="rating">@for ($i = 5; $i >= 1; $i--)<option value="{{ $i }}">{{ $i }}</option>@endfor</select></label>
            <textarea name="body" maxlength="1000" placeholder="Ceritakan rasanya..."></textarea>
            <button class="btn btn-primary">Kirim ulasan</button>
        </form>
    @endauth
</section>

<section class="section">
    <h2>Obrolan dapur</h2>
    @foreach ($recipe->comments as $cm)
        <div class="comment"><strong>{{ $cm->user?->name ?? 'Anonim' }}</strong><p>{{ $cm->body }}</p></div>
    @endforeach
    @auth
        <form class="form" method="post" action="{{ route('comments.store', $recipe->slug) }}">
            @csrf
            <textarea name="body" required placeholder="Tanya tips masak..."></textarea>
            <button class="btn btn-leaf">Kirim</button>
        </form>
    @endauth
</section>

@if (count($related))
    <section class="section">
        <h2>Resep serupa</h2>
        <div class="grid-cards">
            @foreach ($related as $rel)
                @include('partials.recipe-card', ['recipe' => $rel])
            @endforeach
        </div>
    </section>
@endif
@endsection
