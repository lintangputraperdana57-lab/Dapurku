@php /** @var \Illuminate\Pagination\LengthAwarePaginator $paginator */ @endphp
@if ($paginator->lastPage() > 1)
<nav class="pager">
    @foreach ($paginator->getUrlRange(1, $paginator->lastPage()) as $page => $url)
        @if ($page == $paginator->currentPage())
            <span>{{ $page }}</span>
        @else
            <a href="{{ $url }}">{{ $page }}</a>
        @endif
    @endforeach
</nav>
@endif
