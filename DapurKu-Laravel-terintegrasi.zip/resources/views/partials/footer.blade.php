<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <a class="brand" href="{{ route('home') }}">
                <span class="brand-mark">{!! dk_icon('pot', 20) !!}</span>
                <span class="brand-name"><b>{{ setting('site_name', 'DapurKu') }}</b><span>Pro</span></span>
            </a>
            <p class="muted">{{ setting('tagline', 'Resep rumahan Indonesia — dari dapur keluarga, untuk meja makanmu.') }}</p>
        </div>
        <div>
            <strong>Jelajah</strong>
            <p>
                <a href="{{ route('recipes.index') }}">Semua resep</a><br>
                <a href="{{ route('recipes.allCategories') }}">Kategori</a><br>
                <a href="{{ route('recipes.allRegions') }}">Daerah</a><br>
                <a href="{{ route('recipes.daily') }}">Resep harian</a><br>
                <a href="{{ route('pages.kontak') }}">Kontak</a>
            </p>
        </div>
        <div>
            <strong>Dapurku</strong>
            <p>
                <a href="{{ route('favorites.index') }}">Favorit</a><br>
                <a href="{{ route('community.index') }}">Komunitas</a><br>
                <a href="{{ route('recipes.roulette') }}">Roulette menu</a>
            </p>
        </div>
        <div>
            <strong>Legal</strong>
            <p>
                <a href="{{ route('pages.privasi') }}">Privasi</a><br>
                <a href="{{ route('pages.syarat') }}">Syarat</a><br>
                <a href="{{ route('pages.tentang') }}">Tentang</a>
            </p>
        </div>
    </div>
    <div class="container footer-base">
        <span class="muted">© {{ date('Y') }} DapurKu-Pro · versi Laravel</span>
        <span class="muted">{{ setting('footer_note', 'Dibuat dengan 🍲 di Indonesia') }}</span>
    </div>
</footer>
