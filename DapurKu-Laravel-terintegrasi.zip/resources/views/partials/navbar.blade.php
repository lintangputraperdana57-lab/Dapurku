@php
    $nv_current = \Illuminate\Support\Facades\Route::currentRouteName() ?? '';
    $nv_items = [
        ['route' => 'home', 'icon' => 'home', 'fx' => 'glow', 'label' => 'Beranda',
         'match' => ['home']],
        ['route' => 'recipes.index', 'icon' => 'pot', 'fx' => 'pop', 'label' => 'Resep',
         'match' => ['recipes.index', 'recipes.search', 'recipes.show', 'recipes.daily', 'recipes.roulette', 'recipes.allergy', 'recipes.topRated', 'recipes.easy']],
        ['route' => 'recipes.allCategories', 'icon' => 'grid', 'fx' => 'spin', 'label' => 'Kategori',
         'match' => ['recipes.allCategories', 'recipes.category']],
        ['route' => 'recipes.allRegions', 'icon' => 'map', 'fx' => 'wave', 'label' => 'Daerah',
         'match' => ['recipes.allRegions', 'recipes.region']],
        ['route' => 'recipes.popular', 'icon' => 'flame', 'fx' => 'plane', 'label' => 'Terpopuler',
         'match' => ['recipes.popular']],
        ['route' => 'ingredients.index', 'icon' => 'leaf', 'fx' => 'drop', 'label' => 'Bahan',
         'match' => ['ingredients.index', 'ingredients.show']],
    ];
    $nv_more = [
        ['route' => 'recipes.daily', 'icon' => 'sun', 'label' => 'Resep hari ini'],
        ['route' => 'recipes.roulette', 'icon' => 'dice', 'label' => 'Roulette menu'],
        ['route' => 'recipes.allergy', 'icon' => 'shield', 'label' => 'Filter alergi'],
        ['route' => 'recipes.topRated', 'icon' => 'star', 'label' => 'Rating tertinggi'],
        ['route' => 'recipes.easy', 'icon' => 'sparkle', 'label' => 'Resep mudah'],
        ['route' => 'community.index', 'icon' => 'users', 'label' => 'Komunitas'],
        ['route' => 'pages.perjalanan', 'icon' => 'compass', 'label' => 'Perjalanan dapur'],
        ['route' => 'pages.tentang', 'icon' => 'info', 'label' => 'Tentang'],
        ['route' => 'pages.kontak', 'icon' => 'mail', 'label' => 'Kontak'],
    ];
    $nv_user = auth()->user();
    $nv_initial = $nv_user ? mb_strtoupper(mb_substr(trim($nv_user->name), 0, 1)) : 'D';
@endphp
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="{{ route('home') }}" aria-label="DapurKu-Pro — beranda">
            <span class="brand-mark">{!! dk_icon('pot', 21) !!}</span>
            <span class="brand-name"><b>{{ setting('site_name', 'DapurKu') }}</b><span>Pro · Resep Nusantara</span></span>
        </a>

        <div class="nav-spacer"></div>

        <div class="nv-pill-wrap">
            <nav class="nimbus-nav" data-liquid-nav data-tone="light" data-sound="off" data-refract="off" aria-label="Navigasi utama">
                <svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
                    <filter id="nimbus-refract" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
                        <feTurbulence type="fractalNoise" baseFrequency="0.006 0.02" numOctaves="2" seed="7" result="noise"/>
                        <feGaussianBlur in="noise" stdDeviation="2" result="soft"/>
                        <feDisplacementMap in="SourceGraphic" in2="soft" scale="60" xChannelSelector="R" yChannelSelector="G"/>
                    </filter>
                </svg>
                <span class="nimbus-glass" aria-hidden="true"></span>
                <canvas class="nimbus-water" aria-hidden="true"></canvas>
                <span class="nimbus-drop" aria-hidden="true"></span>

                @foreach ($nv_items as $it)
                    <a class="nimbus-item" href="{{ route($it['route']) }}" data-fx="{{ $it['fx'] }}"
                       @if (in_array($nv_current, $it['match'], true)) data-page="1" aria-current="page" @endif>
                        <span class="nv-ico">{!! dk_icon($it['icon'], 18) !!}</span>
                        <span class="nimbus-label">{{ $it['label'] }}</span>
                    </a>
                @endforeach
            </nav>
        </div>

        <div class="nav-spacer"></div>

        <div class="nav-tools">
            <button class="nav-icon-btn menu-toggle" type="button" data-menu-toggle aria-expanded="false" aria-label="Buka menu" aria-haspopup="dialog">
                {!! dk_icon('menu', 18) !!}
            </button>

            <button class="nav-icon-btn theme-switch" type="button" id="dkDarkBtn" aria-label="Ganti mode terang/gelap" title="Mode tampilan">
                <span data-theme-sun>{!! dk_icon('sun', 18) !!}</span>
                <span data-theme-moon>{!! dk_icon('moon', 18) !!}</span>
            </button>

            <div class="nav-more">
                <button class="nav-icon-btn" type="button" data-nav-more aria-expanded="false" aria-controls="navMoreMenu" aria-label="Jelajah lainnya" aria-haspopup="menu">
                    {!! dk_icon('grid', 18) !!}
                </button>
                <div class="nav-menu" id="navMoreMenu" data-nav-menu role="menu" aria-label="Jelajah lainnya">
                    <div class="nav-menu-section">
                        <span class="nav-menu-label">Jelajah</span>
                        @foreach ($nv_more as $it)
                            <a class="nav-menu-item" role="menuitem" href="{{ route($it['route']) }}">{!! dk_icon($it['icon'], 17) !!} {{ $it['label'] }}</a>
                        @endforeach
                    </div>
                    <a class="nav-menu-cta" href="{{ route('recipes.roulette') }}">{!! dk_icon('dice', 17) !!} Acak menu hari ini</a>
                </div>
            </div>

            @if ($nv_user)
                <div class="nav-account">
                    <button class="nav-acct-btn" type="button" data-nav-account aria-expanded="false" aria-controls="navAccountMenu">
                        <span class="nav-avatar">
                            @if ($nv_user->avatar)
                                <img src="{{ recipe_image($nv_user->avatar) }}" alt="">
                            @else
                                {{ $nv_initial }}
                            @endif
                        </span>
                        <span class="nav-acct-name">{{ $nv_user->name }}</span>
                        <span class="nav-acct-chev">{!! dk_icon('chevron-down', 15) !!}</span>
                    </button>
                    <div class="nav-menu" id="navAccountMenu" data-nav-menu role="menu" aria-label="Akun">
                        <div class="nav-menu-head">
                            <span class="nav-avatar">
                                @if ($nv_user->avatar)
                                    <img src="{{ recipe_image($nv_user->avatar) }}" alt="">
                                @else
                                    {{ $nv_initial }}
                                @endif
                            </span>
                            <span style="min-width:0">
                                <strong>{{ $nv_user->name }}</strong>
                                <span>{{ $nv_user->email }}</span>
                            </span>
                        </div>
                        <div class="nav-menu-section">
                            <span class="nav-menu-label">Dapurku</span>
                            <a class="nav-menu-item" role="menuitem" href="{{ route('favorites.index') }}">{!! dk_icon('heart', 17) !!} Favorit</a>
                            <a class="nav-menu-item" role="menuitem" href="{{ route('community.index') }}">{!! dk_icon('users', 17) !!} Komunitas</a>
                        </div>
                        <div class="nav-menu-section">
                            <form method="post" action="{{ route('logout') }}">
                                @csrf
                                <button class="nav-menu-item is-danger" type="submit" role="menuitem">{!! dk_icon('logout', 17) !!} Keluar</button>
                            </form>
                        </div>
                    </div>
                </div>
            @else
                <a class="btn btn-ghost solid" href="{{ route('login') }}">Masuk</a>
                <a class="btn btn-primary" href="{{ route('register') }}">Daftar</a>
            @endif
        </div>
    </div>
</header>

<div class="nav-drawer" data-nav-drawer aria-hidden="true">
    <div class="nav-drawer-scrim" data-nav-drawer-close></div>
    <div class="nav-drawer-panel" role="dialog" aria-modal="true" aria-label="Menu navigasi">
        <div class="nav-drawer-grip"></div>
        <div class="nav-drawer-head">
            <a class="brand" href="{{ route('home') }}">
                <span class="brand-mark">{!! dk_icon('pot', 19) !!}</span>
                <span class="brand-name"><b>DapurKu</b><span>Pro</span></span>
            </a>
            <button class="nav-icon-btn" type="button" data-nav-drawer-close aria-label="Tutup menu">{!! dk_icon('close', 18) !!}</button>
        </div>
        <form class="nav-drawer-search" action="{{ route('recipes.search') }}" method="get">
            {!! dk_icon('search', 17) !!}
            <input name="q" placeholder="Cari rendang, soto, atau “pakai telur”…" aria-label="Cari resep" autocomplete="off">
            <button class="btn btn-primary btn-sm" type="submit">Cari</button>
        </form>
        <div class="nav-drawer-grid">
            @foreach (array_merge($nv_items, $nv_more) as $it)
                <a class="nav-menu-item" href="{{ route($it['route']) }}">{!! dk_icon($it['icon'], 17) !!} {{ $it['label'] }}</a>
            @endforeach
        </div>
        @if ($nv_user)
            <div class="nav-menu-section" style="margin-top:10px">
                <span class="nav-menu-label">Dapurku</span>
                <div class="nav-drawer-grid">
                    <a class="nav-menu-item" href="{{ route('favorites.index') }}">{!! dk_icon('heart', 17) !!} Favorit</a>
                    <a class="nav-menu-item" href="{{ route('community.index') }}">{!! dk_icon('users', 17) !!} Komunitas</a>
                </div>
            </div>
        @else
            <div style="display:flex;gap:8px;margin-top:12px">
                <a class="btn btn-ghost solid" style="flex:1" href="{{ route('login') }}">Masuk</a>
                <a class="btn btn-primary" style="flex:1" href="{{ route('register') }}">Daftar</a>
            </div>
        @endif
    </div>
</div>
