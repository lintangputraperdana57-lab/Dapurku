@php $crumbs = $crumbs ?? []; @endphp
@if ($crumbs)
<p class="muted" style="margin:16px 0">
    @foreach ($crumbs as $i => $c)
        @if ($i > 0) / @endif
        @if (!empty($c['url']))
            <a href="{{ $c['url'] }}">{{ $c['label'] }}</a>
        @else
            <span>{{ $c['label'] }}</span>
        @endif
    @endforeach
</p>
@endif
