@php
    /** @var array $items  data piring (dari HomeController) */
    $items = $items ?? [];
    $legend = $legend ?? [
        1 => 'Mudah · ≤ 30 menit',
        2 => 'Cepat saji',
        3 => 'Sedang',
        4 => 'Butuh sabar',
        5 => 'Sulit · andalan chef',
    ];
    $eyebrow = $eyebrow ?? 'Kaiten · Sabuk dapur';
    $heading = $heading ?? 'Sabuk resep yang terus berputar, langsung di halaman.';
    $caption = $caption ?? 'Arahkan kursor untuk menghentikan sabuk, sentil untuk memutar, pilih piring untuk melihat resep.';
    $uid = 'cb' . substr(md5(json_encode(array_column($items, 'id'))), 0, 6);
@endphp
@if (count($items))
<section class="conveyor" data-conveyor id="{{ $uid }}"
         data-items='@json($items)'
         data-speed="26" data-autoplay="true" data-interval="3200"
         data-label-open="Lihat resep" data-label-close="Tutup"
         data-label-previous="Piring sebelumnya" data-label-next="Piring berikut"
         data-label-pause="Hentikan sabuk" data-label-play="Jalankan sabuk"
         aria-labelledby="{{ $uid }}-heading">

    <div class="cb-layout" data-conveyor-layout data-wide="true">
        <div class="cb-side">
            <div>
                <p class="cb-eyebrow">{{ $eyebrow }}</p>
                <h2 class="cb-heading" id="{{ $uid }}-heading">{{ $heading }}</h2>
                <ul class="cb-legend" aria-hidden="true">
                    @foreach ($legend as $tier => $label)
                        <li data-tier="{{ $tier }}"><span class="cb-dot"></span>{{ $label }}</li>
                    @endforeach
                </ul>
            </div>

            <div class="cb-caption" data-conveyor-caption data-caption="{{ $caption }}" aria-live="polite">
                <p class="cb-caption-idle">{{ $caption }}</p>
            </div>

            @isset($action)
                <div class="cb-action">{{ $action }}</div>
            @endisset
        </div>

        <div class="cb-main">
            <div class="cb-stage" data-conveyor-stage role="group" aria-roledescription="sabuk konveyor" aria-label="{{ $heading }}">
                <div class="cb-counter" data-conveyor-counter aria-hidden="true"></div>
                <div class="cb-belt" data-conveyor-belt aria-hidden="true">
                    <svg data-conveyor-svg xmlns="http://www.w3.org/2000/svg"></svg>
                </div>
                @foreach ($items as $i => $it)
                    <button type="button" class="cb-plate" data-dish="{{ $i }}" data-tier="{{ $it['tier'] }}" tabindex="{{ $i === 0 ? 0 : -1 }}"></button>
                @endforeach
            </div>

            @if (count($items) > 1)
                <div class="cb-controls">
                    <button type="button" class="cb-control" data-control="previous" aria-label="Piring sebelumnya"></button>
                    <button type="button" class="cb-control" data-control="pause" aria-label="Hentikan sabuk" aria-pressed="false"></button>
                    <button type="button" class="cb-control" data-control="next" aria-label="Piring berikut"></button>
                </div>
            @endif
        </div>
    </div>
</section>
@endif
