@php
    /** @var \App\Models\Recipe $recipe */
    $ratio = $recipe->avgRating();
    $isFav = $recipe->isFavoritedBy(auth()->id());
@endphp
<article class="card">
    <a class="card-media-link" href="{{ route('recipes.show', $recipe->slug) }}" tabindex="-1" aria-hidden="true">
        <div class="card-media">
            @if ($recipe->image)
                <img src="{{ recipe_image($recipe->image) }}" alt="" loading="lazy" decoding="async">
            @else
                <div class="placeholder-art"></div>
            @endif
            <span class="badge">{{ $recipe->category?->name ?? difficulty_label($recipe->difficulty) }}</span>
            @if ($ratio > 0)
                <span class="badge badge-rating">{!! dk_icon('star', 12) !!} {{ number_format($ratio, 1, ',', '.') }}</span>
            @endif
        </div>
    </a>

    <button type="button"
            class="fav-btn{{ $isFav ? ' is-on' : '' }}"
            data-favorite="{{ $recipe->id }}"
            aria-pressed="{{ $isFav ? 'true' : 'false' }}"
            aria-label="{{ $isFav ? 'Hapus dari favorit' : 'Simpan ke favorit' }}"
            title="Favorit">
        {!! dk_icon('heart', 17) !!}
    </button>

    <div class="card-body">
        <h3><a href="{{ route('recipes.show', $recipe->slug) }}">{{ $recipe->title }}</a></h3>
        <p class="muted card-excerpt">{{ excerpt_text($recipe->excerpt ?? $recipe->description, 88) }}</p>
        <div class="meta">
            <span class="meta-pill">{!! dk_icon('clock', 14) !!} {{ format_minutes($recipe->cook_time) }}</span>
            <span class="meta-pill">{!! dk_icon(dk_difficulty_icon($recipe->difficulty), 14) !!} {{ difficulty_label($recipe->difficulty) }}</span>
            <span class="meta-pill">{!! dk_icon('eye', 14) !!} {{ format_number($recipe->views) }}</span>
        </div>
    </div>
</article>
