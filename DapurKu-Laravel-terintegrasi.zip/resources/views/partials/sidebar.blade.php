@php
    $sideCats = \App\Models\Category::orderBy('sort_order')->orderBy('name')->get();
    $sidePop = \App\Models\Recipe::published()->orderByDesc('views')->limit(5)->get(['title', 'slug']);
    $sideRegions = [
        ['sumatera', 'Sumatera'], ['jawa', 'Jawa'], ['bali-nusa', 'Bali & Nusa'],
        ['kalimantan', 'Kalimantan'], ['sulawesi', 'Sulawesi'], ['maluku-papua', 'Maluku & Papua'],
    ];
@endphp
<aside>
    <div class="side-card">
        <h3>Kategori</h3>
        @foreach ($sideCats as $c)
            <p><a href="{{ route('recipes.category', $c->slug) }}">{{ $c->name }}</a></p>
        @endforeach
    </div>
    <div class="side-card" style="margin-top:12px">
        <h3>Daerah</h3>
        @foreach ($sideRegions as $rg)
            <p><a href="{{ route('recipes.region', $rg[0]) }}">{{ $rg[1] }}</a></p>
        @endforeach
    </div>
    <div class="side-card" style="margin-top:12px">
        <h3>Sedang ramai</h3>
        @foreach ($sidePop as $p)
            <p><a href="{{ route('recipes.show', $p->slug) }}">{{ $p->title }}</a></p>
        @endforeach
    </div>
</aside>
