@php
    /** @var array $items  butir roda kreasi */
    $items = $items ?? [];
@endphp
@if (count($items) >= 3)
<section class="section" aria-labelledby="ww-heading">
    <div class="ww-head">
        <p class="cb-eyebrow">Galeri berputar</p>
        <h2 id="ww-heading" style="display:flex;justify-content:center;align-items:center;gap:10px">
            <span class="section-head-ico">{!! dk_icon('wheel', 20) !!}</span>
            Kreasi anggota, berputar di satu roda.
        </h2>
        <p class="ww-caption">Roda berputar sendiri — arahkan kursor untuk memperlambat, seret untuk memutar, klik sebuah piring untuk membuka resepnya.</p>
    </div>

    <div class="ww" data-works-wheel data-speed="4.2" data-items='@json($items)'>
        <div class="ww-ring" data-ww-ring role="group" aria-label="Roda kreasi komunitas">
            <span class="ww-track" aria-hidden="true"></span>
            @foreach ($items as $it)
                <a class="ww-item" data-ww-item href="{{ $it['href'] }}" aria-label="{{ $it['title'] . ($it['meta'] ? ' — ' . $it['meta'] : '') }}">
                    <span class="ww-item-disc"><img src="{{ $it['image'] }}" alt="" loading="lazy" decoding="async"></span>
                    <span class="ww-item-label">{!! dk_icon('chef', 13) !!} {{ $it['title'] }}</span>
                </a>
            @endforeach
            <div class="ww-hub">
                <div class="ww-hub-inner">
                    <p class="ww-hub-sub">Dapur komunitas</p>
                    <p class="ww-hub-label">Kreasi ’26</p>
                    <p class="ww-hub-count">{!! dk_icon('sparkle', 13) !!} {{ count($items) }} karya</p>
                    <a class="ww-hub-action" href="{{ route('community.index') }}">Lihat semua {!! dk_icon('arrow-right', 14) !!}</a>
                </div>
            </div>
        </div>
    </div>
</section>
@endif
