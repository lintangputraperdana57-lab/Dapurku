@extends('layouts.admin')
@section('title', 'Bahan')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Katalog</p>
    <h1>Bahan</h1>
    <p class="muted">Daftar bahan baku yang dipakai resep — dipakai juga oleh filter bahan di situs.</p>
  </div>
  <a class="btn btn-primary" href="{{ route('admin.bahan.create') }}">+ Tambah bahan</a>
</header>

<form class="filter-bar" method="get" action="{{ route('admin.bahan.index') }}">
  <input class="input" type="search" name="q" value="{{ $q }}" placeholder="Cari bahan…">
  <button class="btn btn-sm btn-ghost" type="submit">Cari</button>
  @if ($q !== '')
    <a class="btn btn-sm btn-ghost" href="{{ route('admin.bahan.index') }}">Reset</a>
  @endif
  <span class="muted small">{{ $total }} bahan terdaftar</span>
</form>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Nama</th><th>Slug</th><th>Satuan</th><th>Dipakai</th><th>Deskripsi</th><th></th></tr>
      </thead>
      <tbody>
        @forelse ($ings as $i)
          <tr>
            <td><strong>{{ $i->name }}</strong></td>
            <td><code>{{ $i->slug }}</code></td>
            <td>{{ $i->unit }}</td>
            <td>{{ $used[$i->id] ?? 0 }}×</td>
            <td class="muted">{{ excerpt_text($i->description, 70) ?: '—' }}</td>
            <td class="row-actions">
              <a class="btn btn-sm btn-ghost" href="{{ route('ingredients.show', $i->slug) }}" target="_blank" rel="noopener">Lihat</a>
              <a class="btn btn-sm btn-leaf" href="{{ route('admin.bahan.edit', $i) }}">Edit</a>
              <form method="post" action="{{ route('admin.bahan.destroy', $i) }}" onsubmit="return confirm('Hapus bahan {{ $i->name }}?')" style="display:inline">
                @csrf @method('DELETE')
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        @empty
          <tr><td colspan="6" class="muted">Tidak ada bahan yang cocok.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $ings])
</section>
@endsection
