@extends('layouts.admin')
@section('title', $ingredient->exists ? 'Edit bahan' : 'Tambah bahan')
@section('content')
<header class="page-head">
  <h1>{{ $ingredient->exists ? 'Edit bahan: ' . $ingredient->name : 'Tambah bahan' }}</h1>
  <a class="btn btn-ghost" href="{{ route('admin.bahan.index') }}">← Kembali</a>
</header>

<form method="post"
      action="{{ $ingredient->exists ? route('admin.bahan.update', $ingredient) : route('admin.bahan.store') }}">
  @csrf
  @if ($ingredient->exists) @method('PUT') @endif

  <section class="panel">
    <header class="panel-h"><h2>Detail bahan</h2></header>
    <div class="form-grid">
      <label class="fld">Nama *
        <input class="input" name="name" required maxlength="80" value="{{ old('name', $ingredient->name) }}">
      </label>
      <label class="fld">Satuan *
        <input class="input" name="unit" required maxlength="20" list="satuan-umum" value="{{ old('unit', $ingredient->unit ?? 'buah') }}">
        <datalist id="satuan-umum">
          @foreach (['buah', 'gram', 'kg', 'ml', 'liter', 'sdm', 'sdt', 'siung', 'batang', 'lembar', 'butir', 'bungkus', 'ikat', 'potong'] as $satuan)
            <option value="{{ $satuan }}"></option>
          @endforeach
        </datalist>
      </label>
      <label class="fld fld-wide">Deskripsi
        <textarea class="input" name="description" rows="3" maxlength="500">{{ old('description', $ingredient->description) }}</textarea>
      </label>
    </div>
  </section>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">{{ $ingredient->exists ? 'Simpan perubahan' : 'Tambah bahan' }}</button>
    <a class="btn btn-ghost" href="{{ route('admin.bahan.index') }}">Batal</a>
  </div>
</form>
@endsection
