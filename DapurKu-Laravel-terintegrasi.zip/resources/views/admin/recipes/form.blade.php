@extends('layouts.admin')
@section('title', $recipe->exists ? 'Edit resep' : 'Tambah resep')
@section('content')
<header class="page-head">
  <h1>{{ $recipe->exists ? 'Edit resep: ' . $recipe->title : 'Tambah resep' }}</h1>
  <a class="btn btn-ghost" href="{{ route('admin.resep.index') }}">← Kembali</a>
</header>

<form method="post" action="{{ $recipe->exists ? route('admin.resep.update', $recipe) : route('admin.resep.store') }}" enctype="multipart/form-data">
  @csrf
  @if ($recipe->exists) @method('PUT') @endif

  <div class="dash-grid">
    <section class="panel span-2">
      <header class="panel-h"><h2>Info dasar</h2></header>
      <div class="form-grid">
        <label class="fld">Judul
          <input class="input" name="title" required maxlength="120" value="{{ old('title', $recipe->title) }}">
        </label>
        <label class="fld">Kategori
          <select class="input" name="category_id">
            <option value="">— pilih —</option>
            @foreach ($cats as $c)
              <option value="{{ $c->id }}" @selected(old('category_id', $recipe->category_id) == $c->id)>{{ $c->name }}</option>
            @endforeach
          </select>
        </label>
        <label class="fld">Daerah
          <select class="input" name="region_slug">
            <option value="">— pilih —</option>
            @foreach (region_labels() as $slug => $label)
              <option value="{{ $slug }}" @selected(old('region_slug', $recipe->region_slug) === $slug)>{{ $label }}</option>
            @endforeach
          </select>
        </label>
        <label class="fld">Status
          <select class="input" name="status">
            @foreach (['published' => 'Terbit', 'draft' => 'Draft', 'arsip' => 'Arsip'] as $k => $v)
              <option value="{{ $k }}" @selected(old('status', $recipe->status ?? 'published') === $k)>{{ $v }}</option>
            @endforeach
          </select>
        </label>
        <label class="fld">Ringkasan
          <input class="input" name="excerpt" maxlength="400" value="{{ old('excerpt', $recipe->excerpt) }}">
        </label>
        <label class="fld">Deskripsi
          <textarea class="input" name="description" rows="3">{{ old('description', $recipe->description) }}</textarea>
        </label>
      </div>
      <label class="checkbox"><input type="checkbox" name="is_featured" value="1" @checked(old('is_featured', $recipe->is_featured))> Tampilkan sebagai unggulan</label>
    </section>

    <section class="panel">
      <header class="panel-h"><h2>Waktu &amp; gizi</h2></header>
      <div class="form-grid">
        <label class="fld">Waktu masak (menit) *
          <input class="input" type="number" name="cook_time" min="1" max="1440" required value="{{ old('cook_time', $recipe->cook_time ?? 30) }}">
        </label>
        <label class="fld">Persiapan (menit)
          <input class="input" type="number" name="prep_time" min="0" max="1440" value="{{ old('prep_time', $recipe->prep_time) }}">
        </label>
        <label class="fld">Porsi
          <input class="input" type="number" name="servings" min="1" max="200" value="{{ old('servings', $recipe->servings ?? 4) }}">
        </label>
        <label class="fld">Kalori per porsi
          <input class="input" type="number" name="calories" min="0" max="5000" value="{{ old('calories', $recipe->calories) }}">
        </label>
        <label class="fld">Kesulitan
          <select class="input" name="difficulty">
            @foreach (['mudah' => 'Mudah', 'sedang' => 'Sedang', 'sulit' => 'Sulit'] as $k => $v)
              <option value="{{ $k }}" @selected(old('difficulty', $recipe->difficulty ?? 'mudah') === $k)>{{ $v }}</option>
            @endforeach
          </select>
        </label>
        <label class="fld">Foto
          <input class="input" type="file" name="image" accept="image/*">
        </label>
      </div>
      @if ($recipe->image)
        <p class="muted" style="margin-top:8px">Foto saat ini: <code>{{ $recipe->image }}</code></p>
      @endif
    </section>

    <section class="panel span-2">
      <header class="panel-h"><h2>Bahan &amp; langkah</h2></header>
      <div class="form-grid">
        <label class="fld">Bahan (satu per baris, format <code>nama|jumlah|satuan</code>)
          <textarea class="input" name="ingredients" rows="10">{{ old('ingredients', $ingsText) }}</textarea>
        </label>
        <label class="fld">Langkah (satu per baris)
          <textarea class="input" name="steps" rows="10">{{ old('steps', $stepsText) }}</textarea>
        </label>
      </div>
      <p class="muted">Perubahan bahan &amp; langkah disimpan saat formulir dikirim.</p>
    </section>
  </div>

  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-primary" type="submit">{{ $recipe->exists ? 'Simpan perubahan' : 'Tambah resep' }}</button>
    <a class="btn btn-ghost" href="{{ route('admin.resep.index') }}">Batal</a>
  </div>
</form>
@endsection
