@extends('layouts.admin')
@section('title', 'Kelola resep')
@section('content')
<header class="page-head">
  <h1>Resep</h1>
  <a class="btn btn-primary" href="{{ route('admin.resep.create') }}">+ Tambah resep</a>
</header>

<section class="panel">
  <table class="admin-table">
    <thead><tr><th>#</th><th>Judul</th><th>Kategori</th><th>Status</th><th>Dilihat</th><th></th></tr></thead>
    <tbody>
      @foreach ($recipes as $r)
        <tr>
          <td>{{ $r->id }}</td>
          <td><a href="{{ route('recipes.show', $r->slug) }}">{{ $r->title }}</a></td>
          <td>{{ $r->category?->name ?? '—' }}</td>
          <td><span class="badge" style="position:static">{{ $r->status }}</span></td>
          <td>{{ format_number($r->views) }}</td>
          <td class="row-actions">
            <a class="btn btn-sm btn-ghost" href="{{ route('recipes.show', $r->slug) }}">Lihat</a>
            <a class="btn btn-sm btn-leaf" href="{{ route('admin.resep.edit', $r) }}">Edit</a>
            <form method="post" action="{{ route('admin.resep.destroy', $r) }}" onsubmit="return confirm('Hapus resep ini?')" style="display:inline">
              @csrf @method('DELETE')
              <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
  @include('partials.pager', ['paginator' => $recipes])
</section>
@endsection
