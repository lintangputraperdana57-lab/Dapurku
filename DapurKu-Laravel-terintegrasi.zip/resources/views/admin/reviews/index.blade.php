@extends('layouts.admin')
@section('title', 'Ulasan')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Ulasan</h1>
    <p class="muted">Moderasi ulasan resep: setujui, tahan, atau tolak.</p>
  </div>
  <span class="pill">Rata-rata {{ $counts['avg'] ?: '—' }} ★</span>
</header>

<nav class="tabs">
  @php
    $tabs = ['' => 'Semua', 'pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'];
    $base = request()->only(['rating']);
  @endphp
  @foreach ($tabs as $key => $label)
    <a class="tab {{ $status === $key ? 'is-on' : '' }}" href="{{ route('admin.ulasan.index', array_filter($base + ['status' => $key], fn ($v) => $v !== '' && $v !== null)) }}">
      {{ $label }} <b>{{ $counts[$key ?: 'all'] }}</b>
    </a>
  @endforeach
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pengguna</th><th>Resep</th><th>Rating</th><th>Ulasan</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        @forelse ($reviews as $rv)
          <tr>
            <td><strong>{{ $rv->user?->name ?? 'Anonim' }}</strong></td>
            <td>
              @if ($rv->recipe)
                <a href="{{ route('recipes.show', $rv->recipe->slug) }}" target="_blank" rel="noopener">{{ $rv->recipe->title }}</a>
              @else
                <span class="muted">—</span>
              @endif
            </td>
            <td><span class="stars">{{ str_repeat('★', (int) $rv->rating) }}{{ str_repeat('☆', 5 - (int) $rv->rating) }}</span></td>
            <td class="cell-body">{{ $rv->body ?: '—' }}</td>
            <td><span class="{{ status_class($rv->status) }}">{{ status_label($rv->status) }}</span></td>
            <td class="muted nowrap">{{ $rv->created_at?->translatedFormat('d M Y') ?? '—' }}</td>
            <td>
              <div class="row-actions">
                <form method="post" action="{{ route('admin.ulasan.update', $rv) }}" class="inline-form">
                  @csrf @method('PATCH')
                  <select class="input input-sm" name="status">
                    @foreach (['approved' => 'Setujui', 'pending' => 'Tahan', 'rejected' => 'Tolak'] as $k => $v)
                      <option value="{{ $k }}" @selected($rv->status === $k)>{{ $v }}</option>
                    @endforeach
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                <form method="post" action="{{ route('admin.ulasan.destroy', $rv) }}" onsubmit="return confirm('Hapus ulasan ini?')" style="display:inline">
                  @csrf @method('DELETE')
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        @empty
          <tr><td colspan="7" class="muted">Belum ada ulasan pada filter ini.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $reviews])
</section>
@endsection
