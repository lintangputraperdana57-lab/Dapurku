@extends('layouts.admin')
@section('title', $banner->exists ? 'Edit banner' : 'Tambah banner')
@section('content')
<header class="page-head">
  <h1>{{ $banner->exists ? 'Edit banner: ' . $banner->title : 'Tambah banner' }}</h1>
  <a class="btn btn-ghost" href="{{ route('admin.banner.index') }}">← Kembali</a>
</header>

<form method="post" enctype="multipart/form-data"
      action="{{ $banner->exists ? route('admin.banner.update', $banner) : route('admin.banner.store') }}">
  @csrf
  @if ($banner->exists) @method('PUT') @endif

  <section class="panel">
    <header class="panel-h"><h2>Detail banner</h2></header>
    <div class="form-grid">
      <label class="fld">Judul *
        <input class="input" name="title" required maxlength="120" value="{{ old('title', $banner->title) }}">
      </label>
      <label class="fld">Subjudul
        <input class="input" name="subtitle" maxlength="200" value="{{ old('subtitle', $banner->subtitle) }}">
      </label>
      <label class="fld">Tautan
        <input class="input" name="link" maxlength="255" placeholder="/resep/terpopuler" value="{{ old('link', $banner->link) }}">
      </label>
      <label class="fld">Urutan tampil
        <input class="input" type="number" name="sort_order" min="0" max="999" value="{{ old('sort_order', $banner->sort_order ?? 0) }}">
      </label>
      <label class="fld fld-wide">Gambar
        <input class="input" type="file" name="image" accept="image/*">
      </label>
    </div>
    <label class="checkbox">
      <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $banner->is_active ?? true))>
      Tampilkan banner di beranda
    </label>
    @if ($banner->image)
      <p class="muted small" style="margin-top:10px">
        Gambar saat ini: <code>{{ $banner->image }}</code>
        <img class="thumb" src="{{ recipe_image($banner->image) }}" alt="" style="margin-left:8px">
      </p>
    @endif
  </section>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">{{ $banner->exists ? 'Simpan perubahan' : 'Tambah banner' }}</button>
    <a class="btn btn-ghost" href="{{ route('admin.banner.index') }}">Batal</a>
  </div>
</form>
@endsection
