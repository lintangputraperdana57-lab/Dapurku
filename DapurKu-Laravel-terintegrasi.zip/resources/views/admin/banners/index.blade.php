@extends('layouts.admin')
@section('title', 'Banner')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Situs</p>
    <h1>Banner</h1>
    <p class="muted">Sorotan di halaman beranda. Urutan kecil tampil lebih dulu.</p>
  </div>
  <a class="btn btn-primary" href="{{ route('admin.banner.create') }}">+ Tambah banner</a>
</header>

@forelse ($banners as $b)
  <article class="banner-card">
    <div class="banner-card-main">
      @if ($b->image)
        <img class="thumb thumb-lg" src="{{ recipe_image($b->image) }}" alt="">
      @endif
      <div>
        <h3>{{ $b->title }}</h3>
        <p class="muted">{{ $b->subtitle ?: '—' }}</p>
        <p class="muted small">
          Urutan {{ $b->sort_order }} ·
          Tautan: <code>{{ $b->link ?: '—' }}</code> ·
          <span class="{{ status_class($b->is_active ? 'active' : 'dismissed') }}">{{ $b->is_active ? 'Aktif' : 'Nonaktif' }}</span>
        </p>
      </div>
    </div>
    <div class="row-actions">
      <form method="post" action="{{ route('admin.banner.toggle', $b) }}" style="display:inline">
        @csrf @method('PATCH')
        <button class="btn btn-sm btn-ghost" type="submit">{{ $b->is_active ? 'Nonaktifkan' : 'Aktifkan' }}</button>
      </form>
      <a class="btn btn-sm btn-leaf" href="{{ route('admin.banner.edit', $b) }}">Edit</a>
      <form method="post" action="{{ route('admin.banner.destroy', $b) }}" onsubmit="return confirm('Hapus banner ini?')" style="display:inline">
        @csrf @method('DELETE')
        <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
      </form>
    </div>
  </article>
@empty
  <section class="panel">
    <p class="muted">Belum ada banner. <a href="{{ route('admin.banner.create') }}">Tambah banner pertama</a>.</p>
  </section>
@endforelse
@endsection
