@extends('layouts.admin')
@section('title', $category->exists ? 'Edit kategori' : 'Tambah kategori')
@section('content')
<header class="page-head">
  <h1>{{ $category->exists ? 'Edit kategori: ' . $category->name : 'Tambah kategori' }}</h1>
  <a class="btn btn-ghost" href="{{ route('admin.kategori.index') }}">← Kembali</a>
</header>

<form method="post" enctype="multipart/form-data"
      action="{{ $category->exists ? route('admin.kategori.update', $category) : route('admin.kategori.store') }}">
  @csrf
  @if ($category->exists) @method('PUT') @endif

  <section class="panel">
    <header class="panel-h"><h2>Detail kategori</h2></header>
    <div class="form-grid">
      <label class="fld">Nama *
        <input class="input" name="name" required maxlength="80" value="{{ old('name', $category->name) }}">
      </label>
      <label class="fld">Urutan tampil
        <input class="input" type="number" name="sort_order" min="0" max="999" value="{{ old('sort_order', $category->sort_order ?? 0) }}">
      </label>
      <label class="fld">Gambar
        <input class="input" type="file" name="image" accept="image/*">
      </label>
      <label class="fld fld-wide">Deskripsi
        <textarea class="input" name="description" rows="3" maxlength="500">{{ old('description', $category->description) }}</textarea>
      </label>
    </div>
    @if ($category->image)
      <p class="muted small" style="margin-top:10px">
        Gambar saat ini: <code>{{ $category->image }}</code>
        <img class="thumb" src="{{ recipe_image($category->image) }}" alt="" style="margin-left:8px">
      </p>
    @endif
    <p class="muted small">Slug dibuat otomatis dari nama kategori.</p>
  </section>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">{{ $category->exists ? 'Simpan perubahan' : 'Tambah kategori' }}</button>
    <a class="btn btn-ghost" href="{{ route('admin.kategori.index') }}">Batal</a>
  </div>
</form>
@endsection
