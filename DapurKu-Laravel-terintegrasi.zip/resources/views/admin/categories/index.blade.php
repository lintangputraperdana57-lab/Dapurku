@extends('layouts.admin')
@section('title', 'Kategori')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Katalog</p>
    <h1>Kategori</h1>
    <p class="muted">Kelompokkan resep agar mudah dijelajah pengunjung.</p>
  </div>
  <a class="btn btn-primary" href="{{ route('admin.kategori.create') }}">+ Tambah kategori</a>
</header>

<div class="tabs">
  <span class="tab is-on">Semua <b>{{ $cats->total() }}</b></span>
</div>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Urutan</th><th>Nama</th><th>Slug</th><th>Resep</th><th>Deskripsi</th><th></th></tr>
      </thead>
      <tbody>
        @forelse ($cats as $c)
          <tr>
            <td>{{ $c->sort_order }}</td>
            <td>
              <div class="cell-main">
                @if ($c->image)
                  <img class="thumb" src="{{ recipe_image($c->image) }}" alt="">
                @endif
                <div>
                  <strong>{{ $c->name }}</strong>
                  <div class="muted small"><a href="{{ route('recipes.category', $c->slug) }}" target="_blank" rel="noopener">Lihat di situs ↗</a></div>
                </div>
              </div>
            </td>
            <td><code>{{ $c->slug }}</code></td>
            <td>{{ $c->recipes_count }}</td>
            <td class="muted">{{ excerpt_text($c->description, 70) ?: '—' }}</td>
            <td class="row-actions">
              <a class="btn btn-sm btn-leaf" href="{{ route('admin.kategori.edit', $c) }}">Edit</a>
              <form method="post" action="{{ route('admin.kategori.destroy', $c) }}" onsubmit="return confirm('Hapus kategori {{ $c->name }}?')" style="display:inline">
                @csrf @method('DELETE')
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        @empty
          <tr><td colspan="6" class="muted">Belum ada kategori.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $cats])
</section>
@endsection
