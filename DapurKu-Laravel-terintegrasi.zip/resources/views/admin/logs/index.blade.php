@extends('layouts.admin')
@section('title', 'Log')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Situs</p>
    <h1>Log aktivitas</h1>
    <p class="muted">Jejak tindakan admin: resep, moderasi, pengaturan, dan lainnya.</p>
  </div>
  <form method="post" action="{{ route('admin.log.clear') }}" onsubmit="return confirm('Hapus log lebih lama dari 30 hari?')">
    @csrf
    <input type="hidden" name="days" value="30">
    <button class="btn btn-ghost" type="submit">Bersihkan &gt; 30 hari</button>
  </form>
</header>

<form class="filter-bar" method="get" action="{{ route('admin.log.index') }}">
  <input class="input" type="search" name="q" value="{{ $q }}" placeholder="Cari di detail log…">
  <select class="input" name="aksi">
    <option value="">Semua aksi</option>
    @foreach ($groups as $g)
      <option value="{{ $g }}" @selected($action === $g)>{{ ucfirst($g) }}</option>
    @endforeach
  </select>
  <button class="btn btn-sm btn-ghost" type="submit">Terapkan</button>
  @if ($q !== '' || $action !== '')
    <a class="btn btn-sm btn-ghost" href="{{ route('admin.log.index') }}">Reset</a>
  @endif
  <span class="muted small">{{ format_number($total) }} baris tersimpan</span>
</form>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Waktu</th><th>Pelaku</th><th>Aksi</th><th>Detail</th></tr></thead>
      <tbody>
        @forelse ($logs as $log)
          <tr>
            <td class="muted nowrap">{{ $log->created_at?->translatedFormat('d M Y H:i') ?? '—' }}</td>
            <td>
              <strong>{{ $log->user?->name ?? 'Sistem' }}</strong>
              @if ($log->user) <div class="muted small">{{ $log->user->email }}</div> @endif
            </td>
            <td><code>{{ $log->action }}</code></td>
            <td class="muted cell-body">
              @if (is_array($log->meta))
                @foreach ($log->meta as $k => $v)
                  <span class="pill pill-quiet">{{ $k }}: {{ is_scalar($v) ? $v : json_encode($v) }}</span>
                @endforeach
              @else
                —
              @endif
            </td>
          </tr>
        @empty
          <tr><td colspan="4" class="muted">Belum ada log. Log akan terisi otomatis saat admin melakukan tindakan.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $logs])
</section>
@endsection
