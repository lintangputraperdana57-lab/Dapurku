@extends('layouts.admin')
@section('title', 'Dasbor')
@php
    $maxDay = max(1, ...array_column($days, 'n'));
    $maxTop = max(1, ...$top->pluck('views')->all());
    $maxCat = max(1, ...$byCat->pluck('n')->all());
    $colors = ['mudah' => '#2f6b3a', 'sedang' => '#d4a017', 'sulit' => '#c45c26'];
    $totalD = max(1, $diff->sum());
    $off = 0;
@endphp
@section('content')
<div class="dash-hero">
  <div>
    <p class="kicker">Ringkasan dapur</p>
    <h1>Halo, {{ auth()->user()->name }}</h1>
    <p class="muted">Pantau katalog, lalu lintas, dan percakapan pengunjung dari satu layar.</p>
  </div>
  <div class="dash-actions">
    <a class="btn btn-primary" href="{{ route('admin.resep.create') }}">+ Tambah resep</a>
    <a class="btn btn-ghost" href="{{ route('home') }}">Lihat situs</a>
  </div>
</div>

<div class="kpi-grid">
  <article class="kpi"><span>Resep terbit</span><b>{{ $nRecipes - $nDraft }}</b><small>{{ $nRecipes }} total · {{ $nDraft }} draft/arsip</small></article>
  <article class="kpi kpi-clay"><span>Dilihat</span><b>{{ format_number($nViews) }}</b><small>akumulasi halaman resep</small></article>
  <article class="kpi kpi-leaf"><span>Pengguna</span><b>{{ $nUsers }}</b><small>{{ $nFav }} resep disimpan</small></article>
  <article class="kpi"><span>Ulasan</span><b>{{ $nReviews }}</b><small>{{ $nOpen }} laporan terbuka</small></article>
  <article class="kpi"><span>Pesan</span><b>{{ $nMsg }}</b><small>formulir kontak</small></article>
</div>

<div class="dash-grid">
  <section class="panel span-2">
    <header class="panel-h">
      <h2>Kunjungan 7 hari</h2>
      <span class="muted">Termasuk halaman publik &amp; admin</span>
    </header>
    <div class="line-chart" role="img" aria-label="Grafik kunjungan">
      @foreach ($days as $d)
        <div class="lc-col">
          <span class="lc-val">{{ $d['n'] }}</span>
          <i style="height:{{ max(8, (int) round(($d['n'] / $maxDay) * 140)) }}px"></i>
          <small>{{ $d['label'] }}</small>
        </div>
      @endforeach
    </div>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Resep per kategori</h2></header>
    <ul class="bar-list">
      @foreach ($byCat as $c)
        <li>
          <span>{{ $c->name }}</span>
          <div class="bar"><i style="width:{{ (int) round(($c->n / $maxCat) * 100) }}%"></i></div>
          <b>{{ $c->n }}</b>
        </li>
      @endforeach
    </ul>
  </section>

  <section class="panel span-2">
    <header class="panel-h">
      <h2>Paling ramai</h2>
      <a href="{{ route('admin.resep.index') }}">Kelola</a>
    </header>
    <div class="bar-list v-bars">
      @foreach ($top as $r)
        <div class="v-row">
          <a href="{{ route('recipes.show', $r->slug) }}">{{ $r->title }}</a>
          <div class="bar"><i style="width:{{ (int) round(($r->views / $maxTop) * 100) }}%"></i></div>
          <span>{{ format_number($r->views) }}</span>
        </div>
      @endforeach
    </div>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Tingkat kesulitan</h2></header>
    <svg viewBox="0 0 36 36" class="donut">
      @foreach ($diff as $key => $n)
        @php $pct = ($n / $totalD) * 100; @endphp
        <circle cx="18" cy="18" r="14" fill="none" stroke="{{ $colors[$key] ?? '#8f3d14' }}" stroke-width="5"
          stroke-dasharray="{{ round($pct, 2) }} {{ round(100 - $pct, 2) }}"
          stroke-dashoffset="{{ round(-$off, 2) }}" transform="rotate(-90 18 18)"></circle>
        @php $off += $pct; @endphp
      @endforeach
    </svg>
    <ul class="legend">
      @foreach ($diff as $key => $n)
        <li><i style="background:{{ $colors[$key] ?? '#999' }}"></i>{{ difficulty_label($key) }} ({{ $n }})</li>
      @endforeach
    </ul>
  </section>
</div>

<div class="dash-grid">
  <section class="panel">
    <header class="panel-h"><h2>Ulasan terbaru</h2></header>
    @forelse ($latestRev as $rv)
      <div class="feed-item">
        <strong>{{ $rv->user?->name ?? 'Anonim' }}</strong> · {{ str_repeat('★', $rv->rating) }}
        <div class="muted">{{ $rv->recipe?->title }}</div>
        <p>{{ excerpt_text($rv->body ?? '', 90) }}</p>
      </div>
    @empty
      <p class="muted">Belum ada ulasan.</p>
    @endforelse
  </section>
  <section class="panel">
    <header class="panel-h"><h2>Pengguna baru</h2></header>
    @foreach ($latestUsers as $usr)
      <div class="feed-item"><strong>{{ $usr->name }}</strong><div class="muted">{{ $usr->email }} · {{ $usr->role }}</div></div>
    @endforeach
  </section>
  <section class="panel">
    <header class="panel-h"><h2>Pesan kontak</h2></header>
    @forelse ($latestMsg as $m)
      <div class="feed-item">
        <strong>{{ $m->subject ?: '(tanpa subjek)' }}</strong>
        <div class="muted">{{ $m->name }} · {{ $m->created_at?->translatedFormat('d M Y') ?? '—' }}</div>
      </div>
    @empty
      <p class="muted">Kotak masuk kosong.</p>
    @endforelse
  </section>
</div>

<section class="panel">
  <header class="panel-h"><h2>Aksi cepat</h2></header>
  <div class="quick-grid">
    <a href="{{ route('admin.resep.create') }}">Tulis resep baru</a>
    <a href="{{ route('admin.resep.index') }}">Kelola resep</a>
    <a href="{{ route('recipes.index') }}">Lihat katalog</a>
    <a href="{{ route('community.index') }}">Buka komunitas</a>
  </div>
</section>
@endsection
