@extends('layouts.admin')
@section('title', 'Pengaturan')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Situs</p>
    <h1>Pengaturan</h1>
    <p class="muted">Identitas situs, kontak, dan preferensi tampilan.</p>
  </div>
</header>

<form method="post" action="{{ route('admin.pengaturan.update') }}">
  @csrf @method('PUT')

  <div class="dash-grid">
    <section class="panel span-2">
      <header class="panel-h"><h2>Identitas situs</h2></header>
      <div class="form-grid">
        <label class="fld">Nama situs *
          <input class="input" name="site_name" required maxlength="60" value="{{ old('site_name', $values['site_name']) }}">
        </label>
        <label class="fld">Tagline
          <input class="input" name="tagline" maxlength="120" value="{{ old('tagline', $values['tagline']) }}">
        </label>
        <label class="fld">Email kontak
          <input class="input" type="email" name="contact_email" maxlength="120" value="{{ old('contact_email', $values['contact_email']) }}">
        </label>
        <label class="fld">Telepon / WhatsApp
          <input class="input" name="contact_phone" maxlength="40" value="{{ old('contact_phone', $values['contact_phone']) }}">
        </label>
        <label class="fld">Instagram (tanpa @)
          <input class="input" name="instagram" maxlength="80" value="{{ old('instagram', $values['instagram']) }}">
        </label>
        <label class="fld">Catatan footer
          <input class="input" name="footer_note" maxlength="200" value="{{ old('footer_note', $values['footer_note']) }}">
        </label>
      </div>
    </section>

    <section class="panel">
      <header class="panel-h"><h2>Tampilan &amp; mode</h2></header>
      <div class="form-grid">
        <label class="fld">Item per halaman
          <input class="input" type="number" name="items_per_page" min="6" max="60" value="{{ old('items_per_page', $values['items_per_page'] ?: 12) }}">
        </label>
      </div>
      <label class="checkbox">
        <input type="checkbox" name="maintenance" value="1" @checked(old('maintenance', $maintenance))>
        Mode perawatan (tampilkan pemberitahuan di situs)
      </label>
      <p class="muted small">Kosongkan item per halaman untuk memakai nilai bawaan (12).</p>
    </section>
  </div>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">Simpan pengaturan</button>
    <a class="btn btn-ghost" href="{{ route('home') }}" target="_blank" rel="noopener">Pratinjau situs ↗</a>
  </div>
</form>
@endsection
