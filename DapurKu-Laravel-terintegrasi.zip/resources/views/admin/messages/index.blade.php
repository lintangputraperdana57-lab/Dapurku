@extends('layouts.admin')
@section('title', 'Pesan')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Pesan</h1>
    <p class="muted">Kotak masuk formulir kontak di situs.</p>
  </div>
  <span class="pill">{{ $counts['unread'] }} belum dibaca</span>
</header>

<nav class="tabs">
  @foreach (['' => 'Semua', 'unread' => 'Belum dibaca', 'replied' => 'Sudah dibalas'] as $key => $label)
    <a class="tab {{ $filter === $key ? 'is-on' : '' }}" href="{{ route('admin.pesan.index', array_filter(['filter' => $key])) }}">
      {{ $label }} <b>{{ $counts[$key === 'replied' ? 'replied' : ($key === 'unread' ? 'unread' : 'all')] }}</b>
    </a>
  @endforeach
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Status</th><th>Pengirim</th><th>Subjek</th><th>Pesan</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        @forelse ($messages as $msg)
          <tr class="{{ $msg->is_read ? '' : 'row-unread' }}">
            <td>
              @if ($msg->reply)
                <span class="status status-approved">Dibalas</span>
              @elseif ($msg->is_read)
                <span class="status status-pending">Dibaca</span>
              @else
                <span class="status status-open">Baru</span>
              @endif
            </td>
            <td>
              <strong>{{ $msg->name }}</strong>
              <div class="muted small">{{ $msg->email }}</div>
            </td>
            <td>{{ $msg->subject ?: '(tanpa subjek)' }}</td>
            <td class="cell-body muted">{{ excerpt_text($msg->body, 90) }}</td>
            <td class="muted nowrap">{{ $msg->created_at?->translatedFormat('d M Y H:i') ?? '—' }}</td>
            <td>
              <div class="row-actions">
                <a class="btn btn-sm btn-ghost" href="{{ route('admin.pesan.show', $msg) }}">Buka</a>
                <form method="post" action="{{ route('admin.pesan.read', $msg) }}" style="display:inline">
                  @csrf @method('PATCH')
                  <button class="btn btn-sm btn-ghost" type="submit">{{ $msg->is_read ? 'Tandai baru' : 'Tandai dibaca' }}</button>
                </form>
                <form method="post" action="{{ route('admin.pesan.destroy', $msg) }}" onsubmit="return confirm('Hapus pesan ini?')" style="display:inline">
                  @csrf @method('DELETE')
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        @empty
          <tr><td colspan="6" class="muted">Kotak masuk kosong.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $messages])
</section>
@endsection
