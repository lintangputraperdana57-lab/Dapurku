@extends('layouts.admin')
@section('title', 'Pesan · ' . ($message->subject ?: $message->name))
@section('content')
<header class="page-head">
  <h1>{{ $message->subject ?: '(tanpa subjek)' }}</h1>
  <a class="btn btn-ghost" href="{{ route('admin.pesan.index') }}">← Kotak masuk</a>
</header>

<div class="dash-grid">
  <section class="panel span-2">
    <header class="panel-h">
      <h2>Isi pesan</h2>
      <span class="muted">{{ $message->created_at?->translatedFormat('d M Y H:i') ?? '—' }}</span>
    </header>
    <p class="msg-meta">
      <strong>{{ $message->name }}</strong> ·
      <a href="mailto:{{ $message->email }}">{{ $message->email }}</a>
    </p>
    <div class="msg-body">{!! nl2br(e($message->body)) !!}</div>

    <header class="panel-h" style="margin-top:18px"><h2>Balasan</h2></header>
    <form method="post" action="{{ route('admin.pesan.reply', $message) }}">
      @csrf
      <label class="fld">Tulis balasan (disimpan sebagai catatan &amp; dikirim manual lewat email)
        <textarea class="input" name="reply" rows="5" required maxlength="4000">{{ old('reply', $message->reply) }}</textarea>
      </label>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit">Simpan balasan</button>
        <a class="btn btn-ghost" href="mailto:{{ $message->email }}?subject=Re: {{ $message->subject }}">Balas lewat email</a>
      </div>
    </form>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Info</h2></header>
    <ul class="info-list">
      <li><span>Status</span><b>{{ $message->reply ? 'Sudah dibalas' : ($message->is_read ? 'Dibaca' : 'Baru') }}</b></li>
      <li><span>Dibalas pada</span><b>{{ $message->replied_at?->translatedFormat('d M Y H:i') ?? '—' }}</b></li>
      <li><span>Email</span><b><a href="mailto:{{ $message->email }}">{{ $message->email }}</a></b></li>
    </ul>
    <form method="post" action="{{ route('admin.pesan.destroy', $message) }}" onsubmit="return confirm('Hapus pesan ini?')">
      @csrf @method('DELETE')
      <button class="btn btn-danger" type="submit" style="width:100%">Hapus pesan</button>
    </form>
  </section>
</div>
@endsection
