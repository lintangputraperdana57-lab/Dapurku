@extends('layouts.admin')
@section('title', 'Laporan')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Laporan</h1>
    <p class="muted">Aduan pengunjung atas resep, ulasan, komentar, atau akun.</p>
  </div>
  <span class="pill">{{ $counts['open'] }} terbuka</span>
</header>

<nav class="tabs">
  @foreach (['open' => 'Terbuka', 'resolved' => 'Selesai', 'dismissed' => 'Diabaikan', '' => 'Semua'] as $key => $label)
    <a class="tab {{ $status === $key ? 'is-on' : '' }}" href="{{ route('admin.laporan.index', array_filter(['status' => $key])) }}">
      {{ $label }} <b>{{ $counts[$key ?: 'all'] }}</b>
    </a>
  @endforeach
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pelapor</th><th>Jenis</th><th>Konten</th><th>Alasan</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        @forelse ($reports as $rp)
          <tr>
            <td>
              <strong>{{ $rp->user?->name ?? 'Tamu' }}</strong>
              @if ($rp->user) <div class="muted small">{{ $rp->user->email }}</div> @endif
            </td>
            <td><span class="pill pill-quiet">{{ $rp->targetLabel() }}</span></td>
            <td class="cell-body">{{ $rp->targetSummary() }}</td>
            <td class="cell-body muted">{{ $rp->reason ?: '—' }}</td>
            <td><span class="{{ status_class($rp->status) }}">{{ $rp->statusLabel() }}</span></td>
            <td class="muted nowrap">{{ $rp->created_at?->translatedFormat('d M Y') ?? '—' }}</td>
            <td>
              <div class="row-actions">
                <form method="post" action="{{ route('admin.laporan.update', $rp) }}" class="inline-form">
                  @csrf @method('PATCH')
                  <select class="input input-sm" name="status">
                    @foreach (['open' => 'Terbuka', 'resolved' => 'Selesai', 'dismissed' => 'Diabaikan'] as $k => $v)
                      <option value="{{ $k }}" @selected($rp->status === $k)>{{ $v }}</option>
                    @endforeach
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                @if ($rp->status === 'open')
                  <form method="post" action="{{ route('admin.laporan.takedown', $rp) }}" onsubmit="return confirm('Sembunyikan konten yang dilaporkan?')" style="display:inline">
                    @csrf
                    <button class="btn btn-sm btn-ghost" type="submit">Sembunyikan</button>
                  </form>
                @endif
                <form method="post" action="{{ route('admin.laporan.destroy', $rp) }}" onsubmit="return confirm('Hapus laporan ini?')" style="display:inline">
                  @csrf @method('DELETE')
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        @empty
          <tr><td colspan="7" class="muted">Tidak ada laporan pada filter ini.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $reports])
</section>
@endsection
