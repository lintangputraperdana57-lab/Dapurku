@extends('layouts.admin')
@section('title', 'Pengguna')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Pengguna</h1>
    <p class="muted">Atur peran dan status akun warga DapurKu.</p>
  </div>
  <div class="dash-actions">
    <span class="pill">{{ $counts['all'] }} akun</span>
    <span class="pill">{{ $counts['banned'] }} diblokir</span>
  </div>
</header>

<div class="kpi-grid kpi-grid-4">
  <article class="kpi"><span>Admin</span><b>{{ $counts['admin'] }}</b><small>akses penuh panel</small></article>
  <article class="kpi"><span>Moderator</span><b>{{ $counts['moderator'] }}</b><small>boleh masuk panel</small></article>
  <article class="kpi kpi-leaf"><span>Pengguna</span><b>{{ $counts['user'] }}</b><small>akun biasa</small></article>
  <article class="kpi kpi-clay"><span>Resep disimpan</span><b>{{ $counts['favorites'] }}</b><small>total favorit</small></article>
</div>

<form class="filter-bar" method="get" action="{{ route('admin.pengguna.index') }}">
  <input class="input" type="search" name="q" value="{{ $q }}" placeholder="Cari nama atau email…">
  <select class="input" name="role">
    <option value="">Semua peran</option>
    @foreach (['admin' => 'Admin', 'moderator' => 'Moderator', 'user' => 'Pengguna'] as $k => $v)
      <option value="{{ $k }}" @selected($role === $k)>{{ $v }}</option>
    @endforeach
  </select>
  <button class="btn btn-sm btn-ghost" type="submit">Terapkan</button>
  @if ($q !== '' || $role !== '')
    <a class="btn btn-sm btn-ghost" href="{{ route('admin.pengguna.index') }}">Reset</a>
  @endif
</form>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Nama</th><th>Email</th><th>Resep</th><th>Ulasan</th><th>Peran &amp; status</th><th>Bergabung</th><th></th></tr>
      </thead>
      <tbody>
        @foreach ($users as $u)
          <tr>
            <td>
              <strong>{{ $u->name }}</strong>
              @if ($u->is(auth()->user())) <span class="pill pill-quiet">kamu</span> @endif
            </td>
            <td class="muted">{{ $u->email }}</td>
            <td>{{ $u->recipes_count }}</td>
            <td>{{ $u->reviews_count }}</td>
            <td>
              <form method="post" action="{{ route('admin.pengguna.update', $u) }}" class="inline-form">
                @csrf @method('PATCH')
                <select class="input input-sm" name="role">
                  @foreach (['admin' => 'Admin', 'moderator' => 'Moderator', 'user' => 'Pengguna'] as $k => $v)
                    <option value="{{ $k }}" @selected($u->role === $k)>{{ $v }}</option>
                  @endforeach
                </select>
                <select class="input input-sm" name="status">
                  <option value="active" @selected($u->status === 'active')>Aktif</option>
                  <option value="banned" @selected($u->status === 'banned')>Blokir</option>
                </select>
                <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
              </form>
            </td>
            <td class="muted nowrap">{{ $u->created_at?->translatedFormat('d M Y') ?? '—' }}</td>
            <td class="row-actions">
              <form method="post" action="{{ route('admin.pengguna.destroy', $u) }}" onsubmit="return confirm('Hapus akun {{ $u->name }}?')" style="display:inline">
                @csrf @method('DELETE')
                <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $users])
</section>
@endsection
