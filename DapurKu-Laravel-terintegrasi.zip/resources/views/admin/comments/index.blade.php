@extends('layouts.admin')
@section('title', 'Komentar')
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Komunitas</p>
    <h1>Komentar</h1>
    <p class="muted">Komentar pada halaman resep — termasuk balasan bertingkat.</p>
  </div>
</header>

<nav class="tabs">
  @foreach (['' => 'Semua', 'pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'] as $key => $label)
    <a class="tab {{ $status === $key ? 'is-on' : '' }}" href="{{ route('admin.komentar.index', array_filter(['status' => $key])) }}">
      {{ $label }} <b>{{ $counts[$key ?: 'all'] }}</b>
    </a>
  @endforeach
</nav>

<section class="panel">
  <div class="table-wrap">
    <table class="admin-table">
      <thead><tr><th>Pengguna</th><th>Resep</th><th>Komentar</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
      <tbody>
        @forelse ($comments as $cm)
          <tr>
            <td><strong>{{ $cm->user?->name ?? 'Anonim' }}</strong></td>
            <td>
              @if ($cm->recipe)
                <a href="{{ route('recipes.show', $cm->recipe->slug) }}" target="_blank" rel="noopener">{{ $cm->recipe->title }}</a>
              @else
                <span class="muted">—</span>
              @endif
            </td>
            <td class="cell-body">
              @if ($cm->parent_id) <span class="pill pill-quiet">balasan</span> @endif
              {{ $cm->body }}
            </td>
            <td><span class="{{ status_class($cm->status) }}">{{ status_label($cm->status) }}</span></td>
            <td class="muted nowrap">{{ $cm->created_at?->translatedFormat('d M Y H:i') ?? '—' }}</td>
            <td>
              <div class="row-actions">
                <form method="post" action="{{ route('admin.komentar.update', $cm) }}" class="inline-form">
                  @csrf @method('PATCH')
                  <select class="input input-sm" name="status">
                    @foreach (['approved' => 'Setujui', 'pending' => 'Tahan', 'rejected' => 'Tolak'] as $k => $v)
                      <option value="{{ $k }}" @selected($cm->status === $k)>{{ $v }}</option>
                    @endforeach
                  </select>
                  <button class="btn btn-sm btn-leaf" type="submit">Simpan</button>
                </form>
                <form method="post" action="{{ route('admin.komentar.destroy', $cm) }}" onsubmit="return confirm('Hapus komentar ini?')" style="display:inline">
                  @csrf @method('DELETE')
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        @empty
          <tr><td colspan="6" class="muted">Belum ada komentar pada filter ini.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @include('partials.pager', ['paginator' => $comments])
</section>
@endsection
