@extends('layouts.admin')
@section('title', 'Statistik')
@php
    $maxPath = max(1, ...($paths->pluck('n')->all() ?: [1]));
    $maxTop = max(1, ...($topRecipes->pluck('views')->all() ?: [1]));
@endphp
@section('content')
<header class="page-head">
  <div>
    <p class="kicker">Situs</p>
    <h1>Statistik</h1>
    <p class="muted">Lalu lintas kunjungan dan denyut katalog resep.</p>
  </div>
  <nav class="tabs tabs-flat">
    @foreach ([7 => '7 hari', 30 => '30 hari', 90 => '90 hari'] as $d => $label)
      <a class="tab {{ $range === $d ? 'is-on' : '' }}" href="{{ route('admin.statistik', ['hari' => $d]) }}">{{ $label }}</a>
    @endforeach
  </nav>
</header>

<div class="kpi-grid kpi-grid-4">
  <article class="kpi kpi-clay"><span>Kunjungan {{ $range }} hari</span><b>{{ format_number($total) }}</b><small>± {{ $avg }} per hari</small></article>
  <article class="kpi"><span>Hari ini</span><b>{{ format_number($today) }}</b><small>sejak 00:00</small></article>
  <article class="kpi kpi-leaf"><span>Pengunjung unik</span><b>{{ format_number($unique) }}</b><small>berdasarkan IP</small></article>
  <article class="kpi"><span>Puncak harian</span><b>{{ format_number($maxDay) }}</b><small>kunjungan terbanyak</small></article>
</div>

<section class="panel" style="margin-bottom:14px">
  <header class="panel-h">
    <h2>Kunjungan harian</h2>
    <span class="muted">{{ $range }} hari terakhir</span>
  </header>
  <div class="line-chart {{ $range > 30 ? 'dense' : '' }}" role="img" aria-label="Grafik kunjungan harian">
    @foreach ($byDay as $day)
      <div class="lc-col" title="{{ $day['label'] }}: {{ $day['n'] }}">
        @if ($range <= 30) <span class="lc-val">{{ $day['n'] }}</span> @endif
        <i style="height:{{ max(6, (int) round(($day['n'] / $maxDay) * 150)) }}px"></i>
        <small>{{ $day['label'] }}</small>
      </div>
    @endforeach
  </div>
</section>

<div class="dash-grid">
  <section class="panel span-2">
    <header class="panel-h"><h2>Halaman terpopuler</h2></header>
    <div class="bar-list v-bars">
      @forelse ($paths as $p)
        <div class="v-row">
          <code class="path">{{ $p->path }}</code>
          <div class="bar"><i style="width:{{ (int) round(($p->n / $maxPath) * 100) }}%"></i></div>
          <span>{{ format_number($p->n) }}</span>
        </div>
      @empty
        <p class="muted">Belum ada kunjungan tercatat.</p>
      @endforelse
    </div>
  </section>

  <section class="panel">
    <header class="panel-h"><h2>Isi katalog</h2></header>
    <ul class="info-list">
      @foreach ($content as $label => $n)
        <li><span>{{ $label }}</span><b>{{ format_number($n) }}</b></li>
      @endforeach
    </ul>
  </section>

  <section class="panel span-2">
    <header class="panel-h">
      <h2>Resep paling banyak dilihat</h2>
      <a href="{{ route('admin.resep.index') }}">Kelola</a>
    </header>
    <div class="bar-list v-bars">
      @foreach ($topRecipes as $r)
        <div class="v-row">
          <a href="{{ route('recipes.show', $r->slug) }}" target="_blank" rel="noopener">{{ $r->title }}</a>
          <div class="bar"><i style="width:{{ (int) round(($r->views / $maxTop) * 100) }}%"></i></div>
          <span>{{ format_number($r->views) }}</span>
        </div>
      @endforeach
    </div>
  </section>
</div>
@endsection
