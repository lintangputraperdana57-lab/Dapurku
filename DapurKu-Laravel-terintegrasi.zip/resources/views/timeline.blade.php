<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="Perjalanan Dapur — alur masak rendang divisualisasikan sebagai timeline orbital interaktif.">
    <meta name="theme-color" content="#000000">
    <title>Perjalanan Dapur · DapurKu-Pro</title>

    <link rel="icon" href="{{ asset('assets/icons/logo.svg') }}">

    @vite(['resources/css/app.css', 'resources/js/app.tsx'])
    @viteReactRefresh
</head>
<body style="background:#000;margin:0">
    <div id="react-timeline"></div>
</body>
</html>
