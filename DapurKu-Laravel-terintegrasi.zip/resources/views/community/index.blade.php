@extends('layouts.app')
@section('title', 'Komunitas')
@section('content')
<section class="section rv">
    <div class="section-head">
        <div>
            <p class="cb-eyebrow">Dapur bersama</p>
            <h2>Komunitas DapurKu</h2>
            <p class="muted">Cerita, tips, dan hasil masakan dari anggota.</p>
        </div>
    </div>

    <div class="detail-grid">
        <div class="detail-main">
            <ul class="posts">
                @forelse ($posts as $post)
                    <li class="panel post">
                        <div class="rev-head">
                            <b>{{ $post->user?->name ?? 'Anonim' }}</b>
                            @if ($post->recipe)
                                <a href="{{ route('recipes.show', $post->recipe->slug) }}">{!! dk_icon('pot', 13) !!} {{ $post->recipe->title }}</a>
                            @endif
                            <span class="muted">{{ $post->created_at->translatedFormat('d M Y H:i') }}</span>
                        </div>
                        <h3>{{ $post->title }}</h3>
                        <p>{{ $post->body }}</p>
                    </li>
                @empty
                    <li class="empty"><p class="muted">Belum ada cerita. Tulis yang pertama!</p></li>
                @endforelse
            </ul>
        </div>
        <aside class="detail-side">
            <div class="panel">
                <h3>{!! dk_icon('send', 17) !!} Tulis cerita</h3>
                @auth
                    <form method="post" action="{{ route('community.store') }}" class="form">
                        @csrf
                        <label>Judul
                            <input class="input" name="title" maxlength="120" required value="{{ old('title') }}">
                        </label>
                        <label>Cerita
                            <textarea class="input" name="body" rows="5" maxlength="2000" required>{{ old('body') }}</textarea>
                        </label>
                        <button class="btn btn-primary btn-sm" type="submit">Kirim</button>
                    </form>
                @else
                    <p class="muted"><a href="{{ route('login') }}">Masuk</a> untuk ikut berbagi cerita.</p>
                @endauth
            </div>
        </aside>
    </div>
</section>
@endsection
