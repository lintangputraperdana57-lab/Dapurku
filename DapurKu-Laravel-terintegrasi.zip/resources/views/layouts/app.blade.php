<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="{{ $pageDesc ?? 'DapurKu-Pro — katalog resep masakan rumahan Indonesia: lauk Nusantara, menu 30 menit, rencana makan, dan daftar belanja.' }}">
    <meta name="theme-color" content="#c45c26">
    <meta name="csrf" content="{{ csrf_token() }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Beranda') · DapurKu-Pro</title>

    <link rel="icon" href="{{ asset('assets/icons/logo.svg') }}">
    <script>window.DK_BASE = '';</script>
    <script>
        window.DK_ROUTES = {
            search: @json(route('api.search')),
            favorites: @json(route('favorites.toggle')),
            ratings: @json(route('ratings.store')),
        };
    </script>
    <script>if(localStorage.getItem('dk-dark')==='1')document.documentElement.classList.add('dark');</script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Source+Sans+3:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/nav.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/conveyor.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/works-wheel.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/dark-mode.css') }}">
</head>
<body>
@include('partials.navbar')
@if (setting('maintenance', '0') === '1')
    <div class="container"><div class="alert alert-error" style="margin-top:12px">
        Situs sedang dalam mode perawatan. Sebagian fitur mungkin belum stabil.
    </div></div>
@endif
<main class="container">
    @include('partials.alerts')
    @yield('content')
</main>
@include('partials.footer')

<script src="{{ asset('assets/js/app.js') }}"></script>
<script src="{{ asset('assets/js/liquid-navbar.js') }}"></script>
<script src="{{ asset('assets/js/conveyor-belt.js') }}"></script>
<script src="{{ asset('assets/js/works-wheel.js') }}"></script>
<script src="{{ asset('assets/js/search.js') }}"></script>
<script src="{{ asset('assets/js/favorite.js') }}"></script>
<script src="{{ asset('assets/js/rating.js') }}"></script>
<script src="{{ asset('assets/js/cook-tools.js') }}"></script>
</body>
</html>
