<!DOCTYPE html>
<html lang="id" data-base="{{ url('/') }}">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf" content="{{ csrf_token() }}">
<title>Admin · @yield('title', 'Dasbor')</title>
<script>window.DK_BASE = '';</script>
<script>if(localStorage.getItem('dk-dark')==='1')document.documentElement.classList.add('dark');</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Source+Sans+3:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/admin.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/dark-mode.css') }}">
</head>
<body>
@php
    $cur = \Illuminate\Support\Facades\Route::currentRouteName();
    /** Tandai menu aktif berdasarkan awalan nama rute. */
    $act = fn (array $prefixes): string => collect($prefixes)->contains(fn ($p) => str_starts_with((string) $cur, $p)) ? 'active' : '';
    $unreadMsg = \App\Models\Message::where('is_read', false)->count();
    $openReports = \App\Models\Report::where('status', 'open')->count();
@endphp
<div class="admin-shell">
<aside class="admin-side">
  <div class="brand-mini"><span>{!! dk_icon('pot', 18) !!}</span><strong>DapurKu Admin</strong></div>

  <div class="nav-sec">Utama</div>
  <a class="{{ $act(['admin.dashboard']) }}" href="{{ route('admin.dashboard') }}">Dasbor</a>
  <a class="{{ $act(['admin.resep']) }}" href="{{ route('admin.resep.index') }}">Resep</a>
  <a class="{{ $act(['admin.kategori']) }}" href="{{ route('admin.kategori.index') }}">Kategori</a>
  <a class="{{ $act(['admin.bahan']) }}" href="{{ route('admin.bahan.index') }}">Bahan</a>

  <div class="nav-sec">Komunitas</div>
  <a class="{{ $act(['admin.pengguna']) }}" href="{{ route('admin.pengguna.index') }}">Pengguna</a>
  <a class="{{ $act(['admin.ulasan']) }}" href="{{ route('admin.ulasan.index') }}">Ulasan</a>
  <a class="{{ $act(['admin.komentar']) }}" href="{{ route('admin.komentar.index') }}">Komentar</a>
  <a class="{{ $act(['admin.laporan']) }}" href="{{ route('admin.laporan.index') }}">
    Laporan @if ($openReports > 0)<span class="side-count">{{ $openReports }}</span>@endif
  </a>
  <a class="{{ $act(['admin.pesan']) }}" href="{{ route('admin.pesan.index') }}">
    Pesan @if ($unreadMsg > 0)<span class="side-count">{{ $unreadMsg }}</span>@endif
  </a>

  <div class="nav-sec">Situs</div>
  <a class="{{ $act(['admin.banner']) }}" href="{{ route('admin.banner.index') }}">Banner</a>
  <a class="{{ $act(['admin.statistik']) }}" href="{{ route('admin.statistik') }}">Statistik</a>
  <a class="{{ $act(['admin.pengaturan']) }}" href="{{ route('admin.pengaturan.index') }}">Pengaturan</a>
  <a class="{{ $act(['admin.log']) }}" href="{{ route('admin.log.index') }}">Log</a>

  <div class="nav-sec">Akun</div>
  <a href="{{ route('home') }}" target="_blank" rel="noopener">Lihat situs</a>
  <form method="post" action="{{ route('logout') }}">@csrf<button type="submit" class="side-link">Keluar</button></form>
</aside>
<main class="admin-main">
    @include('partials.alerts')
    @yield('content')
</main>
</div>
<script src="{{ asset('assets/js/app.js') }}"></script>
<script src="{{ asset('assets/js/admin.js') }}"></script>
</body>
</html>
