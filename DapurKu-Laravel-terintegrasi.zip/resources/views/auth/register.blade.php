@extends('layouts.app')
@section('title', 'Daftar')
@section('content')
<section class="section rv" style="max-width:460px;margin:0 auto">
    <div class="panel">
        <h2 style="text-align:center">Buat akun</h2>
        <p class="muted" style="text-align:center">Gratis — langsung bisa menyimpan favorit.</p>
        <form method="post" action="{{ route('register') }}" class="form" style="margin-top:14px">
            @csrf
            <label>Nama
                <input class="input" type="text" name="name" value="{{ old('name') }}" required autofocus>
            </label>
            <label>Email
                <input class="input" type="email" name="email" value="{{ old('email') }}" required>
            </label>
            <label>Kata sandi
                <input class="input" type="password" name="password" required minlength="6">
            </label>
            <label>Ulangi kata sandi
                <input class="input" type="password" name="password_confirmation" required minlength="6">
            </label>
            <button class="btn btn-primary" type="submit">Daftar</button>
        </form>
        <p class="muted" style="text-align:center;margin-top:12px">Sudah punya akun? <a href="{{ route('login') }}">Masuk</a></p>
    </div>
</section>
@endsection
