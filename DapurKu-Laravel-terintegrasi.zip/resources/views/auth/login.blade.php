@extends('layouts.app')
@section('title', 'Masuk')
@section('content')
<section class="section rv" style="max-width:460px;margin:0 auto">
    <div class="panel">
        <h2 style="text-align:center">Masuk ke DapurKu</h2>
        <p class="muted" style="text-align:center">Simpan favorit, beri ulasan, dan kirim cerita ke komunitas.</p>
        <form method="post" action="{{ route('login') }}" class="form" style="margin-top:14px">
            @csrf
            <label>Email
                <input class="input" type="email" name="email" value="{{ old('email') }}" required autofocus>
            </label>
            <label>Kata sandi
                <input class="input" type="password" name="password" required>
            </label>
            <label class="checkbox"><input type="checkbox" name="remember" value="1"> Ingat saya</label>
            <button class="btn btn-primary" type="submit">Masuk</button>
        </form>
        <p class="muted" style="text-align:center;margin-top:12px">Belum punya akun? <a href="{{ route('register') }}">Daftar</a></p>
        <p class="muted" style="text-align:center;font-size:13px">Demo: <code>admin@dapurku.pro / admin123</code> · <code>sari@dapurku.pro / user123</code></p>
    </div>
</section>
@endsection
