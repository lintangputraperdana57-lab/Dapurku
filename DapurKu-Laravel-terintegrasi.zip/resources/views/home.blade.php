@extends('layouts.app')
@section('title', 'Beranda')
@section('content')
@php
    $heroStats = $hero
        ? [
            ['clock', format_minutes($hero->cook_time)],
            ['users', ($hero->servings ?: 4) . ' porsi'],
            ['scale', difficulty_label($hero->difficulty)],
        ]
        : [];
    $regions = [
        ['sumatera', 'Sumatera', 'Rendang, pempek, mie Aceh'],
        ['jawa', 'Jawa', 'Soto, gudeg, rawon'],
        ['bali-nusa', 'Bali & Nusa', 'Betutu, sate lilit, plecing'],
        ['kalimantan', 'Kalimantan', 'Soto Banjar, ikan bakar'],
        ['sulawesi', 'Sulawesi', 'Coto, dabu-dabu, konro'],
        ['maluku-papua', 'Maluku & Papua', 'Papeda, ikan kuah kuning'],
    ];
@endphp

@if ($banners->isNotEmpty())
    @php $b = $banners->first(); @endphp
    <section class="banner">
        <div class="banner-copy">
            <p class="kicker">{!! dk_icon('sparkle', 14) !!} Dapur rumahan</p>
            <h1>{{ $b->title }}</h1>
            <p>{{ $b->subtitle }}</p>
            <a class="btn btn-ghost" href="{{ $b->link ? url($b->link) : route('recipes.index') }}">
                Lihat resep {!! dk_icon('arrow-right', 16) !!}
            </a>
        </div>
        <div class="banner-art" aria-hidden="true">
            <span></span><span></span><span></span>
        </div>
    </section>
@endif

<section class="hero">
    <div class="hero-copy">
        <p class="kicker">{!! dk_icon('flame', 14) !!} Masak hari ini</p>
        <h1>Resep yang terasa seperti <em>rumah</em>.</h1>
        <p class="lede">Lauk Nusantara, menu 30 menit, dan ide belanja dari bahan yang sudah ada di dapurmu — {{ format_number($counts['recipes']) }} resep siap dimasak.</p>

        <form class="search-hero" action="{{ route('recipes.search') }}" method="get" role="search">
            <span class="search-ico" aria-hidden="true">{!! dk_icon('search', 18) !!}</span>
            <input data-live-search name="q" placeholder="Cari rendang, soto, atau “pakai telur”…" autocomplete="off" aria-label="Cari resep">
            <button class="btn btn-primary" type="submit">Cari</button>
        </form>
        <div data-search-out class="toolbar search-out"></div>

        <dl class="hero-stats">
            <div><dt>{!! dk_icon('pot', 16) !!} Resep</dt><dd>{{ format_number($counts['recipes']) }}</dd></div>
            <div><dt>{!! dk_icon('grid', 16) !!} Kategori</dt><dd>{{ format_number($counts['cats']) }}</dd></div>
            <div><dt>{!! dk_icon('map', 16) !!} Daerah</dt><dd>{{ count(region_labels()) }}</dd></div>
        </dl>
    </div>

    <div class="hero-plate">
        @if ($hero && $hero->image)
            <img src="{{ recipe_image($hero->image) }}" alt="{{ $hero->title }}">
        @else
            <div class="placeholder-art"></div>
        @endif
        @if ($hero)
            <figcaption>
                <span class="hero-plate-kicker">{!! dk_icon('star', 13) !!} Unggulan dapur</span>
                <a href="{{ route('recipes.show', $hero->slug) }}"><strong>{{ $hero->title }}</strong></a>
                <span class="muted">{{ excerpt_text($hero->excerpt ?? $hero->description ?? '', 78) }}</span>
                <span class="hero-plate-meta">
                    @foreach ($heroStats as $s)
                        <span>{!! dk_icon($s[0], 14) !!} {{ $s[1] }}</span>
                    @endforeach
                </span>
            </figcaption>
        @endif
    </div>
</section>

@include('partials.conveyor', [
    'items' => $conveyor,
    'eyebrow' => 'Kaiten · Sabuk dapur',
    'heading' => 'Sabuk resep yang terus berputar, langsung di halaman.',
    'caption' => 'Arahkan kursor untuk menghentikan sabuk, sentil untuk memutar, pilih piring untuk melihat resep.',
    'action' => new \Illuminate\Support\HtmlString('<a class="btn btn-primary" href="' . route('recipes.popular') . '">' . dk_icon('flame', 16) . ' Semua terpopuler</a>'),
])

<section class="section">
    <div class="section-head">
        <h2>{!! dk_icon('grid', 20) !!} Kategori dapur</h2>
        <a class="section-link" href="{{ route('recipes.allCategories') }}">Semua {!! dk_icon('arrow-right', 15) !!}</a>
    </div>
    <div class="grid-4">
        @foreach ($cats as $c)
            <a class="cat-chip" href="{{ route('recipes.category', $c->slug) }}">
                <span class="cat-chip-ico">{!! dk_icon($c->icon ?: 'chef', 18) !!}</span>
                <strong>{{ $c->name }}</strong>
                <span class="muted">{{ excerpt_text($c->description ?? '', 48) }}</span>
            </a>
        @endforeach
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>{!! dk_icon('map', 20) !!} Dari Sabang sampai Merauke</h2>
        <a class="section-link" href="{{ route('recipes.allRegions') }}">Semua daerah {!! dk_icon('arrow-right', 15) !!}</a>
    </div>
    <div class="grid-4 region-grid">
        @foreach ($regions as $rg)
            <a class="cat-chip region-chip" href="{{ route('recipes.region', $rg[0]) }}">
                <strong>{{ $rg[1] }}</strong>
                <span class="muted">{{ $rg[2] }}</span>
            </a>
        @endforeach
    </div>
</section>

<section class="section">
    <div class="quick-actions">
        <a class="qa qa-primary" href="{{ route('recipes.daily') }}">
            <span class="qa-ico">{!! dk_icon('sun', 22) !!}</span>
            <span><strong>Resep hari ini</strong><em>Pilihan redaksi dapur</em></span>
        </a>
        <a class="qa" href="{{ route('recipes.roulette') }}">
            <span class="qa-ico">{!! dk_icon('dice', 22) !!}</span>
            <span><strong>Roulette menu</strong><em>Bingung? Biar diacak</em></span>
        </a>
        <a class="qa" href="{{ route('recipes.allergy') }}">
            <span class="qa-ico">{!! dk_icon('shield', 22) !!}</span>
            <span><strong>Filter alergi</strong><em>Masak dengan aman</em></span>
        </a>
        <a class="qa" href="{{ route('recipes.topRated') }}">
            <span class="qa-ico">{!! dk_icon('star', 22) !!}</span>
            <span><strong>Rating tertinggi</strong><em>Favorit pembaca</em></span>
        </a>
    </div>
</section>

@include('partials.wheel', ['items' => $wheel])

<section class="section">
    <div class="section-head">
        <h2>{!! dk_icon('star', 20) !!} Unggulan dapur</h2>
        <a class="section-link" href="{{ route('recipes.popular') }}">Terpopuler {!! dk_icon('arrow-right', 15) !!}</a>
    </div>
    <div class="grid-cards">
        @foreach ($featured as $recipe)
            @include('partials.recipe-card', ['recipe' => $recipe])
        @endforeach
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>{!! dk_icon('flame', 20) !!} Baru dari kompor</h2>
        <a class="section-link" href="{{ route('recipes.latest') }}">Terbaru {!! dk_icon('arrow-right', 15) !!}</a>
    </div>
    <div class="grid-cards">
        @foreach ($latest as $recipe)
            @include('partials.recipe-card', ['recipe' => $recipe])
        @endforeach
    </div>
</section>
@endsection
