@extends('layouts.app')
@section('title', 'Kebijakan privasi')
@section('content')
<section class="section rv" style="max-width:760px;margin:0 auto">
    <div class="panel">
        <h2>Kebijakan privasi</h2>
        <p>Kami hanya menyimpan data yang kamu berikan: nama, email, serta aktivitas favorit dan ulasan.
           Data tidak dijual maupun dibagikan ke pihak ketiga. Progres langkah memasak disimpan lokal di
           perambanmu (localStorage) dan tidak dikirim ke server.</p>
        <p>Kamu dapat menghapus akun beserta datanya kapan pun melalui tim kami di halaman kontak.</p>
    </div>
</section>
@endsection
