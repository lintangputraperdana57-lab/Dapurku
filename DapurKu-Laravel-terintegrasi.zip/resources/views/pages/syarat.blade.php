@extends('layouts.app')
@section('title', 'Syarat & ketentuan')
@section('content')
<section class="section rv" style="max-width:760px;margin:0 auto">
    <div class="panel">
        <h2>Syarat &amp; ketentuan</h2>
        <p>Dengan menggunakan DapurKu-Pro kamu setuju untuk berbagi konten yang sopan dan relevan dengan memasak.
           Resep yang dibagikan anggota menjadi tanggung jawab penulisnya; tim kami dapat menghapus konten yang
           melanggar.</p>
        <p>Hasil masakan bisa berbeda tergantung bahan dan peralatan. Selalu pastikan makanan matang sempurna,
           terutama untuk anak-anak, ibu hamil, dan anggota keluarga dengan alergi.</p>
    </div>
</section>
@endsection
