@extends('layouts.app')
@section('title', 'Kontak')
@section('content')
<section class="section rv" style="max-width:640px;margin:0 auto">
    <div class="panel">
        <h2>Hubungi kami</h2>
        <p class="muted">Ada usulan resep, koreksi, atau kerja sama? Kirim pesan di bawah.</p>
        <form method="post" action="{{ route('pages.kontak') }}" class="form" style="margin-top:12px">
            @csrf
            <label>Nama
                <input class="input" name="name" required value="{{ old('name') }}">
            </label>
            <label>Email
                <input class="input" type="email" name="email" required value="{{ old('email') }}">
            </label>
            <label>Subjek
                <input class="input" name="subject" maxlength="120" value="{{ old('subject') }}">
            </label>
            <label>Pesan
                <textarea class="input" name="body" rows="5" required>{{ old('body') }}</textarea>
            </label>
            <button class="btn btn-primary" type="submit">{!! dk_icon('send', 15) !!} Kirim pesan</button>
        </form>
    </div>
</section>
@endsection
