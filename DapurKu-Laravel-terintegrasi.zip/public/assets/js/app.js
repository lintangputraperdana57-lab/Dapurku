/* ============================================================
   DapurKu-Pro · app.js
   Basis URL, sakelar tema, menu tarik-turun navbar, drawer ponsel.
   ============================================================ */
(function () {
  const fromPath = () => {
    const p = window.location.pathname || '';
    const m = p.match(/^(.*?)\/(?:admin|resep|auth|api|profil|favorit|kategori|bahan|ulasan|komentar|koleksi|notifikasi|meal-plan|daftar-belanja|actions|riwayat|komunitas)(?:\/|$)/);
    if (m) return m[1];
    if (p.toLowerCase().includes('/dapurku-pro')) {
      const i = p.toLowerCase().indexOf('/dapurku-pro');
      return p.slice(0, i + '/dapurku-pro'.length);
    }
    return '';
  };
  window.DK_BASE = (window.DK_BASE || fromPath() || '').replace(/\/$/, '');
  window.dkUrl = function (p) {
    const path = String(p || '').replace(/^\//, '');
    return (window.DK_BASE ? window.DK_BASE + '/' : '/') + path;
  };
})();

/* ---------- sakelar tema ---------- */
(function theme() {
  const root = document.documentElement;
  const apply = (on) => {
    root.classList.toggle('dark', on);
    document.body.classList.toggle('dark', on);
    localStorage.setItem('dk-dark', on ? '1' : '0');
    // Navbar air ikut menyesuaikan nada kaca & warna air shader.
    document.querySelectorAll('[data-liquid-nav]').forEach((nav) => {
      nav.dataset.tone = on ? 'dark' : 'light';
    });
  };
  apply(localStorage.getItem('dk-dark') === '1');
  document.getElementById('dkDarkBtn')?.addEventListener('click', () => {
    apply(!root.classList.contains('dark'));
  });
})();

/* ---------- menu tarik-turun navbar ---------- */
(function menus() {
  const toggles = Array.from(document.querySelectorAll('[data-nav-more],[data-nav-account]'));
  if (!toggles.length) return;

  const menuOf = (btn) => document.getElementById(btn.getAttribute('aria-controls'));

  const setOpen = (btn, open) => {
    const menu = menuOf(btn);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (menu) menu.dataset.open = open ? 'true' : 'false';
  };
  const closeAll = (except) => {
    toggles.forEach((b) => { if (b !== except) setOpen(b, false); });
  };

  toggles.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = btn.getAttribute('aria-expanded') !== 'true';
      closeAll(btn);
      setOpen(btn, open);
      if (open) {
        const first = menuOf(btn)?.querySelector('a,button');
        first?.focus({ preventScroll: true });
      }
    });

    // Navigasi papan ketik di dalam menu.
    menuOf(btn)?.addEventListener('keydown', (e) => {
      const items = Array.from(menuOf(btn).querySelectorAll('a,button')).filter((n) => !n.disabled);
      const i = items.indexOf(document.activeElement);
      if (e.key === 'Escape') { e.preventDefault(); setOpen(btn, false); btn.focus(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length]?.focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length]?.focus(); }
      else if (e.key === 'Tab' && !e.shiftKey && i === items.length - 1) { e.preventDefault(); setOpen(btn, false); btn.focus(); }
    });
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-nav-menu],[data-nav-more],[data-nav-account]')) closeAll(null);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAll(null);
  });
  window.addEventListener('resize', () => closeAll(null), { passive: true });
})();

/* ---------- drawer ponsel ---------- */
(function drawer() {
  const drawer = document.querySelector('[data-nav-drawer]');
  if (!drawer) return;

  const openBtn = document.querySelector('[data-menu-toggle]');
  const setOpen = (open) => {
    drawer.dataset.open = open ? 'true' : 'false';
    drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.style.overflow = open ? 'hidden' : '';
    openBtn?.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) drawer.querySelector('input,a,button')?.focus({ preventScroll: true });
  };

  openBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    setOpen(drawer.dataset.open !== 'true');
  });
  drawer.querySelectorAll('[data-nav-drawer-close]').forEach((n) => {
    n.addEventListener('click', () => setOpen(false));
  });
  drawer.addEventListener('click', (e) => {
    if (e.target.closest('a')) setOpen(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.dataset.open === 'true') setOpen(false);
  });
})();

/* ---------- sapuan halus saat kartu masuk viewport ---------- */
(function reveal() {
  if (!('IntersectionObserver' in window)) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      }
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
  document.querySelectorAll('.card, .cat-chip, .stat, .side-card, .step').forEach((el, i) => {
    el.style.setProperty('--rv-i', String(i % 12));
    el.classList.add('rv');
    io.observe(el);
  });
})();
