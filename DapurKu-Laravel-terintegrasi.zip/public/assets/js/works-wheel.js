/* ============================================================
   DapurKu-Pro · works-wheel.js
   Roda kreasi: cincin foto berputar pelan mengelilingi hub kaca.

   Markup dirender includes/works-wheel.php:

     <div data-works-wheel data-items='[{"title","image","href"}]'>
       <div data-ww-ring>
         <button data-ww-item>…</button>…
         <div class="ww-hub">…</div>
       </div>
     </div>

   Perilaku:
   • Berputar otomatis (kecepatan `data-speed`, derajat/detik).
   • Kursor di atas roda → melambat; keluar → pulih.
   • Seret horizontal → memutar manual dengan inersia.
   • Butir terdekat ke puncak ditandai .is-front (judul muncul).
   • Menghormati prefers-reduced-motion (tidak berputar sendiri).
   ============================================================ */
(function () {
  'use strict';

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function Wheel(root) {
    this.root = root;
    this.ring = root.querySelector('[data-ww-ring]');
    this.items = [].slice.call(root.querySelectorAll('[data-ww-item]'));
    if (!this.ring || this.items.length < 2) return;

    this.speed = parseFloat(root.dataset.speed || '4.2');   // derajat/detik
    this.angle = parseFloat(root.dataset.angle || '0');
    this.v = this.speed;
    this.hover = 0;          // 0..1 faktor perlambatan saat kursor masuk
    this.dragging = false;
    this.raf = 0;
    this.last = 0;
    this.front = -1;
    this.visible = true;
    this.reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    this.n = this.items.length;
    this.step = 360 / this.n;

    this.bind();
    this.observe();
    this.layout();
    this.kick();
  }

  Wheel.prototype.observe = function () {
    var self = this;
    this.io = new IntersectionObserver(function (entries) {
      self.visible = entries.some(function (en) { return en.isIntersecting; }) && !document.hidden;
      if (self.visible) self.kick();
      else if (self.raf) { cancelAnimationFrame(self.raf); self.raf = 0; self.last = 0; }
    });
    this.io.observe(this.root);
    this.onVis = function () { if (!document.hidden && self.visible) self.kick(); };
    document.addEventListener('visibilitychange', this.onVis);
    this.ro = new ResizeObserver(function () { self.layout(); });
    this.ro.observe(this.ring);
  };

  Wheel.prototype.bind = function () {
    var self = this;

    this.ring.addEventListener('pointerenter', function (e) {
      if (e.pointerType !== 'mouse') return;
      self.hoverGoal = 1;
    });
    this.ring.addEventListener('pointerleave', function (e) {
      if (e.pointerType !== 'mouse') return;
      self.hoverGoal = 0;
    });

    this.ring.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) return;
      self.dragging = true;
      self.dragX = e.clientX;
      self.dragV = 0;
      self.dragT = e.timeStamp;
      self.pointerId = e.pointerId;
      if (self.ring.setPointerCapture) self.ring.setPointerCapture(e.pointerId);
      self.kick();
    });
    this.ring.addEventListener('pointermove', function (e) {
      if (!self.dragging || e.pointerId !== self.pointerId) return;
      var dx = e.clientX - self.dragX;
      var dt = Math.max(8, e.timeStamp - self.dragT);
      self.dragX = e.clientX;
      self.dragT = e.timeStamp;
      // Satu putaran penuh ≈ lebar cincin dalam px.
      var perDeg = (self.ring.clientWidth * Math.PI) / 360;
      self.angle += dx / Math.max(6, perDeg);
      self.dragV = (dx / dt) * 1000 / Math.max(6, perDeg); // derajat/detik
      self.layout();
    });
    function up(e) {
      if (!self.dragging || e.pointerId !== self.pointerId) return;
      self.dragging = false;
      self.v = clamp(self.dragV, -220, 220);
      if (self.ring.releasePointerCapture && self.ring.hasPointerCapture(e.pointerId)) {
        self.ring.releasePointerCapture(e.pointerId);
      }
      self.kick();
    }
    this.ring.addEventListener('pointerup', up);
    this.ring.addEventListener('pointercancel', up);

    // Navigasi papan ketik: panah memindahkan fokus antar butir.
    this.ring.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      var i = self.items.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      var n = (i + (e.key === 'ArrowRight' ? 1 : -1) + self.n) % self.n;
      self.items[n].focus();
    });
  };

  Wheel.prototype.layout = function () {
    var r = this.ring.clientWidth / 2;
    if (!r) return;
    for (var i = 0; i < this.n; i++) {
      var a = (this.angle + i * this.step) * Math.PI / 180;
      // 0° = puncak cincin; berputar searah jarum jam.
      var x = Math.sin(a) * r;
      var y = -Math.cos(a) * r;
      // Kedalaman: butir di "belakang" (atas) sedikit mengecil & meredup.
      var depth = (1 - Math.cos(a)) / 2;              // 0 depan, 1 belakang
      var k = 1 - 0.22 * depth;
      var el = this.items[i];
      el.style.transform = 'translate3d(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px,0) scale(' + k.toFixed(3) + ')';
      el.style.zIndex = String(100 + Math.round((1 - depth) * 100));
      el.style.filter = depth > 0.55 ? 'saturate(.82) brightness(.9)' : 'none';
    }
    // Butir terdepan (paling bawah-depan) mendapat sorotan.
    var frontIdx = Math.round(((( -this.angle % 360) + 360) % 360) / this.step) % this.n;
    if (frontIdx !== this.front) {
      if (this.items[this.front]) this.items[this.front].classList.remove('is-front');
      this.front = frontIdx;
      this.items[frontIdx].classList.add('is-front');
    }
  };

  Wheel.prototype.tick = function (now) {
    var self = this;
    this.raf = 0;
    if (!this.visible) { this.last = 0; return; }
    var dt = this.last ? clamp((now - this.last) / 1000, 0, 0.1) : 1 / 60;
    this.last = now;

    var goal = this.hoverGoal || 0;
    this.hover += (goal - this.hover) * Math.min(1, dt * 6);

    if (!this.dragging) {
      var cruise = this.reduced ? 0 : this.speed * (1 - 0.92 * this.hover);
      // Inersia seretan meluruh kembali ke kecepatan jelajah.
      this.v += (cruise - this.v) * Math.min(1, dt * 2.6);
      if (Math.abs(this.v) < 0.002 && cruise === 0) this.v = 0;
      this.angle += this.v * dt;
      this.layout();
    }

    var settled = !this.dragging && Math.abs(this.v - (this.reduced ? 0 : this.speed * (1 - 0.92 * this.hover))) < 0.01;
    if (this.dragging || !settled || (!this.reduced && this.speed !== 0)) {
      this.raf = requestAnimationFrame(function (t) { self.tick(t); });
    } else {
      this.last = 0;
    }
  };

  Wheel.prototype.kick = function () {
    var self = this;
    if (this.raf || !this.visible) return;
    this.last = 0;
    this.raf = requestAnimationFrame(function (t) { self.tick(t); });
  };

  function boot() {
    var nodes = document.querySelectorAll('[data-works-wheel]');
    for (var i = 0; i < nodes.length; i++) {
      if (!nodes[i].__dkWheel) nodes[i].__dkWheel = new Wheel(nodes[i]);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.addEventListener('load', boot);

  window.DKWorksWheel = Wheel;
})();
