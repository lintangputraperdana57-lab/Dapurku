/* ============================================================
   DapurKu-Pro · liquid-navbar.js
   Port vanilla dari komponen React "Nimbus UI — Liquid Navbar
   (Waterline)". Tidak ada dependensi selain browser API.

   Cara pakai (markup sudah dirender oleh includes/navbar.php):

     <nav class="nimbus-nav" data-liquid-nav data-tone="light" data-sound="off">
       <span class="nimbus-glass"></span>
       <canvas class="nimbus-water"></canvas>
       <span class="nimbus-drop"></span>
       <a class="nimbus-item" data-fx="glow" href="...">
         <span class="nv-ico">…svg…</span><span class="nimbus-label">Beranda</span>
       </a>
     </nav>

   Perilaku:
   • Tetes air meregang menuju item aktif; lompatan jauh
     memecahnya jadi droplet yang lalu menyatu kembali + riak.
   • Kursor mengangkat meniskus; tiap klik mengirim gelombang.
   • `data-fx` pada ikon memainkan animasi satu kali saat dipilih.
   • Air digambar shader WebGL, dijeda saat pil off-screen / tab
     tidak aktif. Tanpa WebGL → jatuh ke tetes CSS `.nimbus-drop`.
   • Menghormati prefers-reduced-motion.
   ============================================================ */
(function () {
  'use strict';

  var PAD = 14; // bleed kanvas di sekeliling pil, untuk bayangan & riak

  /* ---------- shader air ---------- */
  var VERT = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';

  var FRAG = [
    'precision highp float;',
    'uniform vec2 uRes;uniform float uDpr;uniform float uTime;uniform vec4 uPill;',
    'uniform vec4 uBlob[6];uniform float uSy[6];uniform vec4 uRip[6];uniform vec3 uMouse;uniform float uDark;uniform float uAmb;',
    'float sdRB(vec2 p,vec2 b,float r){vec2 q=abs(p)-b+r;return length(max(q,0.))+min(max(q.x,q.y),0.)-r;}',
    'float sdCap(vec2 p,vec4 B,float sy){p-=B.xy;p.y/=sy;p.x=max(abs(p.x)-B.z,0.);return(length(p)-B.w)*min(1.,sy);}',
    'float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}',
    'float dropD(vec2 p){float d=1e4;for(int i=0;i<6;i++){if(uBlob[i].w>.5){d=smin(d,sdCap(p,uBlob[i],uSy[i]),13.);}}return d;}',
    'float pillD(vec2 p){vec2 h=uPill.zw*.5;return sdRB(p-uPill.xy-h,h,h.y);}',
    'float lens(float d,float w){float t=clamp(-d/w,0.,1.);return sqrt(1.-(1.-t)*(1.-t));}',
    'float waves(vec2 p){float w=0.;',
    ' for(int i=0;i<6;i++){vec4 R=uRip[i];if(R.w>0.){float x=length(p-R.xy)-R.z*240.;w+=R.w*exp(-R.z*1.7)*sin(x*.3)*exp(-x*x/700.);}}',
    ' vec2 m=p-uMouse.xy;w+=uMouse.z*3.6*exp(-dot(m,m)/1000.);',
    ' w+=uAmb*(sin(p.x*.05+uTime*1.2)*.45+sin(p.x*.13-uTime*.85+p.y*.2)*.25);return w;}',
    'float H(vec2 p){float dp=pillD(p);return lens(dp,uPill.w*.36)*2.4+lens(dropD(p),11.)*7.5+waves(p)*smoothstep(0.,7.,-dp);}',
    'float caus(vec2 p,float t){vec2 q=p;float c=0.;for(int i=0;i<3;i++){q+=vec2(sin(q.y*1.1+t),cos(q.x*1.3-t*.7))*.6;c+=1./(1.+16.*abs(sin(q.x)*sin(q.y)));}return c/3.;}',
    'void main(){',
    ' vec2 p=vec2(gl_FragCoord.x,uRes.y*uDpr-gl_FragCoord.y)/uDpr;',
    ' float dp=pillD(p);float dd=dropD(p);',
    ' float h0=H(p);vec3 n=normalize(vec3(h0-H(p+vec2(1.,0.)),h0-H(p+vec2(0.,1.)),1.));',
    ' vec3 V=vec3(0.,0.,1.);',
    ' float spec=pow(max(dot(reflect(-normalize(vec3(-.45,-.8,.85)),n),V),0.),70.);',
    ' float spec2=pow(max(dot(reflect(-normalize(vec3(.6,.75,.7)),n),V),0.),22.)*.3;',
    ' float fres=clamp((1.-n.z)*4.,0.,1.);',
    ' vec3 irid=.5+.5*cos(6.2831*(vec3(0.,.33,.67)+fres*.85+p.x*.0028+uTime*.035));',
    ' float pm=smoothstep(1.,-1.,dp);float dm=smoothstep(1.,-1.,dd)*smoothstep(1.,-2.,dp);',
    ' float sh=smoothstep(9.,-9.,dropD(p-vec2(0.,5.)))*(1.-dm)*pm*(.11+.07*uDark);',
    ' vec3 c=vec3(0.,.14,.36)*sh;float a=sh;',
    ' float pa=clamp(pm*(fres*.5+spec*.9+spec2),0.,1.);',
    ' c=mix(vec3(1.),irid,.5*fres)*pa+c*(1.-pa);a=pa+a*(1.-pa);',
    ' float th=lens(dd,11.);',
    ' float cs=caus((p+n.xy*th*18.)*.085,uTime*.9);',
    ' vec3 tint=mix(vec3(.80,.95,1.),vec3(.55,.82,1.),uDark);',
    ' float rim=dm*(1.-smoothstep(0.,8.,-dd));',
    ' float cres=dm*smoothstep(.12,.55,dot(n.xy,normalize(vec2(.55,.85))))*smoothstep(0.,3.,-dd);',
    ' float body=.5+.5*clamp(-n.y*3.,-1.,1.);',
    ' float da=dm*(.26+.14*body)*(1.-.35*uDark);vec3 dc=mix(tint,vec3(1.),body*.6);',
    ' float la=rim*.22;vec3 lc=mix(vec3(0.,.42,.78),vec3(.1,.55,.95),uDark);dc=lc*la+dc*da*(1.-la);da=la+da*(1.-la);',
    ' la=clamp(cres*.7+smoothstep(.6,1.,cs)*.28*th*dm,0.,1.);dc=vec3(1.)*la+dc*(1.-la);da=la+da*(1.-la);',
    ' la=clamp(dm*(spec*1.2+spec2*.5),0.,1.);dc=vec3(1.)*la+dc*(1.-la);da=la+da*(1.-la);',
    ' la=dm*smoothstep(-2.,0.,dd)*.4;dc=mix(vec3(1.),irid,.35)*la+dc*(1.-la);da=la+da*(1.-la);',
    ' c=dc+c*(1.-da);a=da+a*(1.-da);',
    ' gl_FragColor=vec4(c,a);',
    '}'
  ].join('\n');

  var RUN = 0;

  function makeState() {
    return {
      a: { x: 0, v: 0 },
      b: { x: 0, v: 0 },
      sy: { s: 1, v: 0 },
      lead: 0,
      lagFrom: 0,
      sats: [],
      rips: [],
      t: { x: 0, cy: 0, q: 0, r: 20 },
      q: 0,
      mouse: { x: 0, y: 0, s: 0, on: false },
      moving: false,
      split: false,
      ready: false,
      w: 0,
      h: 0,
      visible: true,
      reduce: false,
      raf: 0,
      last: 0,
      time: 0,
      glc: null
    };
  }

  function initGL(canvas) {
    var gl = null;
    try {
      gl = canvas.getContext('webgl', { premultipliedAlpha: true, alpha: true, antialias: false });
    } catch (e) {
      return null;
    }
    if (!gl) return null;

    function sh(type, src) {
      var s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null;
    }

    var vs = sh(gl.VERTEX_SHADER, VERT);
    var fs = sh(gl.FRAGMENT_SHADER, FRAG);
    if (!vs || !fs) return null;

    var p = gl.createProgram();
    gl.attachShader(p, vs);
    gl.attachShader(p, fs);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) return null;
    gl.useProgram(p);

    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(p, 'a');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    var u = {};
    ['uRes', 'uDpr', 'uTime', 'uPill', 'uBlob', 'uSy', 'uRip', 'uMouse', 'uDark', 'uAmb'].forEach(function (n) {
      u[n] = gl.getUniformLocation(p, n);
    });
    return { gl: gl, u: u };
  }

  /* Refraksi SVG lewat backdrop-filter hanya didukung Chromium. */
  function supportsRefraction() {
    if (typeof CSS === 'undefined' || !CSS.supports) return false;
    var ua = navigator.userAgent;
    return /Chrome\/|Chromium\/|Edg\//.test(ua) && !/Firefox\//.test(ua) &&
      CSS.supports('backdrop-filter', 'url(#a)');
  }

  function LiquidNav(nav) {
    this.nav = nav;
    this.canvas = nav.querySelector('.nimbus-water');
    this.drop = nav.querySelector('.nimbus-drop');
    this.items = [].slice.call(nav.querySelectorAll('.nimbus-item'));
    this.audio = null;
    this.sound = nav.dataset.sound === 'on';
    this.st = makeState();
    this._destroyed = false;

    if (!this.items.length) return;

    var s = this.st;
    s.reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    /* Item yang sedang "diinginkan": halaman aktif dulu, lalu seksi
       halaman (data-page), lalu pilihan pengguna saat klik. */
    var cur = this.items.findIndex(function (el) { return el.getAttribute('aria-current') === 'page'; });
    if (cur < 0) cur = this.items.findIndex(function (el) { return el.dataset.page === '1'; });
    this.picked = cur >= 0 ? cur : 0;
    this.current = this.picked;

    if (this.canvas) {
      s.glc = initGL(this.canvas);
      if (!s.glc) nav.dataset.gl = 'off';
    } else {
      nav.dataset.gl = 'off';
    }

    this.bind();
    this.measure();
    this.observe();
  }

  LiquidNav.prototype.bind = function () {
    var self = this;
    var nav = this.nav;
    var s = this.st;

    this._onLost = function (e) { e.preventDefault(); s.glc = null; nav.dataset.gl = 'off'; self.measure(); };
    if (this.canvas) this.canvas.addEventListener('webglcontextlost', this._onLost);

    this._onMove = function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      var p = self.local(e.clientX, e.clientY);
      s.mouse.x = p.x; s.mouse.y = p.y; s.mouse.on = true;
      self.loop();
    };
    this._onLeave = function () { s.mouse.on = false; self.loop(); };
    this._onDown = function (e) {
      var p = self.local(e.clientX, e.clientY);
      self.ripple(p.x, p.y, 0.8);
    };
    this._onKey = function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      if (!nav.contains(document.activeElement)) return;
      e.preventDefault();
      var n = (self.current + (e.key === 'ArrowRight' ? 1 : -1) + self.items.length) % self.items.length;
      self.select(n);
      self.items[n].focus();
    };

    nav.addEventListener('pointermove', this._onMove);
    nav.addEventListener('pointerleave', this._onLeave);
    nav.addEventListener('pointerdown', this._onDown);
    nav.addEventListener('keydown', this._onKey);

    this._onClick = function (e) {
      var el = e.target.closest ? e.target.closest('.nimbus-item') : null;
      if (!el || self.items.indexOf(el) < 0) return;
      self.select(self.items.indexOf(el));
    };
    nav.addEventListener('click', this._onClick);

    /* Perubahan tema / drawer mengubah lebar pil → ukur ulang. */
    this._mo = new MutationObserver(function () { self.measure(); });
    this._mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    this._mo.observe(nav, { attributes: true, attributeFilter: ['data-tone', 'data-compact', 'data-labels', 'class'] });
  };

  LiquidNav.prototype.observe = function () {
    var self = this;
    var s = this.st;

    this._io = new IntersectionObserver(function (entries) {
      s.visible = entries[0].isIntersecting;
      if (s.visible) self.loop();
    });
    this._io.observe(this.nav);

    this._vis = function () {
      s.visible = document.visibilityState === 'visible';
      if (s.visible) self.loop();
    };
    document.addEventListener('visibilitychange', this._vis);

    var lastW = -1;
    this._ro = new ResizeObserver(function () {
      var w = self.nav.offsetWidth;
      if (w !== lastW) { lastW = w; s.ready = false; self.measure(); }
    });
    this._ro.observe(this.nav);
  };

  LiquidNav.prototype.local = function (clientX, clientY) {
    var r = this.nav.getBoundingClientRect();
    return { x: clientX - r.left + PAD, y: clientY - r.top + PAD };
  };

  LiquidNav.prototype.ripple = function (x, y, amp) {
    var s = this.st;
    if (s.reduce) return;
    s.rips.push({ x: x, y: y, age: 0, amp: amp });
    this.loop();
  };

  LiquidNav.prototype.iconCenter = function (i) {
    var el = this.items[i] && this.items[i].querySelector('.nv-ico');
    if (!el) return null;
    var b = el.getBoundingClientRect();
    return this.local(b.left + b.width / 2, b.top + b.height / 2);
  };

  /* "plip" sintetis — tanpa berkas audio. */
  LiquidNav.prototype.plip = function () {
    if (!this.sound) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!this.audio) this.audio = new AC();
      var ctx = this.audio;
      if (ctx.state === 'suspended') ctx.resume();
      var t = ctx.currentTime;
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(420 + Math.random() * 80, t);
      o.frequency.exponentialRampToValueAtTime(1500, t + 0.07);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.16, t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      o.connect(g); g.connect(ctx.destination);
      o.start(t); o.stop(t + 0.18);
    } catch (e) { /* audio tidak wajib */ }
  };

  LiquidNav.prototype.select = function (i) {
    var item = this.items[i];
    if (!item) return;
    var kind = item.dataset.fx || 'pop';
    this.picked = i;
    this.plip();

    var c = this.iconCenter(i);
    var self = this;
    if (c && kind === 'drop') setTimeout(function () { self.ripple(c.x, self.st.t.cy, 1.4); }, 430);
    if (c && kind === 'plane') this.ripple(c.x, c.y, 0.6);

    this.playFx(i, kind);
    this.measure();
  };

  /* Putar ulang animasi ikon dengan melepas lalu memasang kembali data-fx. */
  LiquidNav.prototype.playFx = function (i, kind) {
    var ico = this.items[i].querySelector('.nv-ico');
    if (!ico || kind === 'none') return;
    ico.removeAttribute('data-fx');
    void ico.offsetWidth; // paksa reflow agar keyframe mulai dari awal
    ico.setAttribute('data-fx', kind);
  };

  /* ---------- tata letak ---------- */
  LiquidNav.prototype.measure = function () {
    if (this._destroyed) return;
    var s = this.st;
    var nav = this.nav;
    var el = this.items[this.picked] || this.items[0];
    if (!el) return;

    s.w = nav.offsetWidth;
    s.h = nav.offsetHeight;
    if (!s.w || !s.h) return;

    var T = s.t;
    T.r = el.offsetHeight / 2;
    T.q = Math.max(0, el.offsetWidth / 2 - T.r);
    T.cy = PAD + el.offsetTop + el.offsetHeight / 2;
    var nx = PAD + el.offsetLeft + el.offsetWidth / 2;

    if (!s.ready) {
      s.a.x = s.b.x = nx;
      s.q = T.q;
      s.ready = true;
    } else if (Math.abs(nx - T.x) > 0.5) {
      s.lead = Math.abs(nx - s.a.x) <= Math.abs(nx - s.b.x) ? 0 : 1;
      s.lagFrom = performance.now() + 70;
      s.moving = true;
      s.split = false;
    }
    T.x = nx;

    /* Sorot item pilihan (aria-current tunggal, dikelola JS). */
    this.current = this.picked;
    for (var i = 0; i < this.items.length; i++) {
      if (i === this.current) this.items[i].setAttribute('aria-current', 'page');
      else this.items[i].removeAttribute('aria-current');
    }

    var cv = this.canvas;
    if (cv) {
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var W = s.w + PAD * 2, H = s.h + PAD * 2;
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) {
        cv.width = Math.round(W * dpr);
        cv.height = Math.round(H * dpr);
        cv.style.width = W + 'px';
        cv.style.height = H + 'px';
      }
    }
    this.loop();
  };

  /* ---------- menggambar ---------- */
  LiquidNav.prototype.draw = function () {
    var s = this.st;
    var T = s.t;
    var sep = Math.abs(s.a.x - s.b.x);
    var thin = Math.min(sep / (2 * (s.q + T.r) || 1), 1);
    var r = T.r * (1 - 0.3 * thin);

    if (s.glc) {
      var g = s.glc.gl, u = s.glc.u;
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      g.viewport(0, 0, g.drawingBufferWidth, g.drawingBufferHeight);
      g.uniform2f(u.uRes, s.w + PAD * 2, s.h + PAD * 2);
      g.uniform1f(u.uDpr, dpr);
      g.uniform1f(u.uTime, s.time);
      g.uniform4f(u.uPill, PAD, PAD, s.w, s.h);

      var blobs = new Float32Array(24);
      var sy = new Float32Array(6); sy.fill(1);
      var head = s.lead === 0 ? s.a : s.b;
      var tail = s.lead === 0 ? s.b : s.a;
      blobs.set([
        head.x, T.cy, s.q * (1 - 0.25 * thin), T.r * (1 - 0.12 * thin),
        tail.x, T.cy, s.q * (1 - 0.8 * thin), T.r * (1 - 0.5 * thin)
      ], 0);
      sy[0] = sy[1] = s.sy.s;
      s.sats.slice(0, 4).forEach(function (d, i) { blobs.set([d.x, d.y, 0, d.r], 8 + i * 4); });
      g.uniform4fv(u.uBlob, blobs);
      g.uniform1fv(u.uSy, sy);

      var rips = new Float32Array(24);
      s.rips.slice(-6).forEach(function (p, i) { rips.set([p.x, p.y, p.age, p.amp], i * 4); });
      g.uniform4fv(u.uRip, rips);

      g.uniform3f(u.uMouse, s.mouse.x, s.mouse.y, s.mouse.s);
      g.uniform1f(u.uDark, this.nav.dataset.tone === 'dark' ? 1 : 0);
      g.uniform1f(u.uAmb, s.reduce ? 0 : 1);
      g.clearColor(0, 0, 0, 0);
      g.clear(g.COLOR_BUFFER_BIT);
      g.drawArrays(g.TRIANGLES, 0, 3);
    } else if (this.drop) {
      var left = Math.min(s.a.x, s.b.x) - s.q - r - PAD;
      var width = sep + 2 * (s.q + r);
      this.drop.style.width = width + 'px';
      this.drop.style.transform = 'translateX(' + left + 'px) scaleY(' + s.sy.s + ')';
    }
  };

  /* ---------- fisika ---------- */
  LiquidNav.prototype.step = function (dt, now) {
    var s = this.st;
    var T = s.t;
    s.time += dt;
    s.q += (T.q - s.q) * Math.min(1, dt * 12);

    var bodies = [s.a, s.b];
    var still = true;

    if (s.reduce) {
      s.a.x = s.b.x = T.x; s.a.v = s.b.v = 0; s.sy.s = 1; s.sats = [];
    } else {
      bodies.forEach(function (B, i) {
        var lead = i === s.lead;
        var k = lead ? 210 : 72;
        var c = lead ? 25 : 13;
        var f = (!lead && now < s.lagFrom) ? 0.08 : 1;
        B.v += (k * (T.x - B.x) - c * B.v) * dt * f;
        B.x += B.v * dt;
        var lo = PAD + 6 + s.q + T.r - 3, hi = PAD + s.w - 6 - s.q - T.r + 3;
        if (B.x < lo || B.x > hi) {
          s.sy.v -= Math.min(Math.abs(B.v), 900) * 0.0016;
          B.x = Math.max(lo, Math.min(hi, B.x));
          B.v *= -0.25;
        }
        if (Math.abs(T.x - B.x) > 0.3 || Math.abs(B.v) > 3) still = false;
      });

      var L = bodies[s.lead];
      var syT = 1 - 0.2 * Math.min(Math.abs(L.v) / 1500, 1);
      s.sy.v += (280 * (syT - s.sy.s) - 9 * s.sy.v) * dt;
      s.sy.s += s.sy.v * dt;
      if (Math.abs(s.sy.s - 1) > 0.002 || Math.abs(s.sy.v) > 0.02) still = false;

      // Putuskan "leher": lahirkan droplet antara kepala dan ekor
      var sep = Math.abs(s.a.x - s.b.x);
      var r = T.r * (1 - 0.3 * Math.min(sep / (2 * (T.q + T.r) || 1), 1));
      if (!s.split && s.moving && sep - 2 * T.q - 2 * r > -6) {
        s.split = true;
        var lo2 = bodies[1 - s.lead], hi2 = bodies[s.lead];
        [0.3, 0.5, 0.72].forEach(function (t, j) {
          s.sats.push({
            x: lo2.x + (hi2.x - lo2.x) * t + (Math.random() - 0.5) * 6,
            y: T.cy + (Math.random() - 0.5) * 10,
            vx: (lo2.v + hi2.v) * 0.45,
            vy: (Math.random() - 0.5) * 60,
            r: 5 + Math.random() * 3 - j * 0.5,
            k: 70 + Math.random() * 90
          });
        });
      }

      s.sats = s.sats.filter(function (d) {
        d.vx += (d.k * (T.x - d.x) - 9 * d.vx) * dt;
        d.vy += (90 * (T.cy - d.y) - 7 * d.vy) * dt;
        d.x += d.vx * dt;
        d.y += d.vy * dt;
        d.x = Math.max(PAD + 8 + d.r, Math.min(PAD + s.w - 8 - d.r, d.x));
        d.y = Math.max(T.cy - T.r + d.r, Math.min(T.cy + T.r - d.r, d.y));
        if (Math.abs(T.x - d.x) < T.q + T.r * 0.5) d.r -= dt * 26;
        return d.r > 0.6;
      });
      if (s.sats.length) still = false;
    }

    if (s.moving && still) {
      s.moving = false;
      if (s.split || !s.reduce) s.rips.push({ x: T.x, y: T.cy, age: 0, amp: s.split ? 1.2 : 0.7 });
    }
    s.rips.forEach(function (p) { p.age += dt; });
    s.rips = s.rips.filter(function (p) { return p.age < 2.4; });

    var target = s.mouse.on ? 1 : 0;
    s.mouse.s += (target - s.mouse.s) * Math.min(1, dt * 7);
  };

  LiquidNav.prototype.loop = function () {
    var self = this;
    var s = this.st;
    if (s.raf || this._destroyed) return;
    s.last = performance.now();
    var tick = function (now) {
      var dt = Math.min((now - s.last) / 1000, 1 / 30);
      s.last = now;
      self.step(dt, now);
      self.draw();
      var busy = s.moving || s.rips.length || s.sats.length || s.mouse.s > 0.01;
      // Air ambien terus bergerak selama terlihat; reduced-motion hanya saat ada perubahan
      if (s.visible && (!s.reduce || busy)) s.raf = requestAnimationFrame(tick);
      else s.raf = 0;
    };
    s.raf = requestAnimationFrame(tick);
  };

  /* ---------- boot ---------- */
  function boot() {
    var navs = document.querySelectorAll('[data-liquid-nav]');
    for (var i = 0; i < navs.length; i++) {
      if (!navs[i].__dkLiquid) navs[i].__dkLiquid = new LiquidNav(navs[i]);
    }
    if (navs.length && supportsRefraction()) {
      for (var j = 0; j < navs.length; j++) navs[j].dataset.refract = 'on';
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  // Tata letak bisa bergeser setelah font & gambar siap.
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(function () {
      var navs = document.querySelectorAll('[data-liquid-nav]');
      for (var i = 0; i < navs.length; i++) {
        if (navs[i].__dkLiquid) { navs[i].__dkLiquid.st.ready = false; navs[i].__dkLiquid.measure(); }
      }
    });
  }
  window.addEventListener('load', function () {
    var navs = document.querySelectorAll('[data-liquid-nav]');
    for (var i = 0; i < navs.length; i++) {
      if (navs[i].__dkLiquid) { navs[i].__dkLiquid.st.ready = false; navs[i].__dkLiquid.measure(); }
    }
  });

  window.DKLiquidNav = LiquidNav;
  void RUN;
})();
