/* Tombol favorit (ikon hati) di kartu resep & halaman detail.
   Mendukung data-favorite (baru) dan data-fav (lama). */
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-favorite],[data-fav]');
  if (!btn) return;
  e.preventDefault();

  const id = Number(btn.dataset.favorite || btn.dataset.fav || 0);
  if (!id) return;

  const apply = (on) => {
    btn.classList.toggle('is-on', !!on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    const label = on ? 'Hapus dari favorit' : 'Simpan ke favorit';
    btn.setAttribute('aria-label', label);
    btn.title = label;
    // Tombol lama berupa teks.
    if (btn.dataset.fav && !btn.querySelector('svg')) btn.textContent = on ? '♥ Favorit' : '♡ Simpan';
    btn.classList.remove('is-busy');
    btn.classList.add('is-pop');
    setTimeout(() => btn.classList.remove('is-pop'), 420);
  };

  btn.classList.add('is-busy');
  try {
    const res = await fetch(window.DK_ROUTES?.favorites || dkUrl('api/favorites.php'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf]')?.content || '',
      },
      body: JSON.stringify({ recipe_id: id }),
    });
    if (res.status === 401) {
      window.location.href = dkUrl('masuk');
      return;
    }
    const data = await res.json();
    apply(!!data.favorited);
    // Sinkronkan semua tombol untuk resep yang sama di halaman ini.
    document.querySelectorAll(`[data-favorite="${id}"],[data-fav="${id}"]`).forEach((other) => {
      if (other !== btn) {
        other.classList.toggle('is-on', !!data.favorited);
        other.setAttribute('aria-pressed', data.favorited ? 'true' : 'false');
      }
    });
  } catch (err) {
    btn.classList.remove('is-busy');
  }
});
