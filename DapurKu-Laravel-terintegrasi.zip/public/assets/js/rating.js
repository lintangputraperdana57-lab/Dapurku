document.addEventListener('click', async (e) => {
  const star = e.target.closest('[data-rate]');
  if (!star) return;
  const wrap = star.parentElement;
  const recipe = wrap.dataset.recipe;
  const rating = star.dataset.rate;
  await fetch(window.DK_ROUTES?.ratings || dkUrl('api/ratings.php'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ recipe_id: Number(recipe), rating: Number(rating) })
  });
  wrap.querySelectorAll('[data-rate]').forEach((s) => {
    s.textContent = Number(s.dataset.rate) <= Number(rating) ? '★' : '☆';
  });
});
