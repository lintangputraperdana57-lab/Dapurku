const box = document.querySelector('[data-live-search]');
if (box) {
  let timer;
  const out = document.querySelector('[data-search-out]');
  box.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = box.value.trim();
      if (q.length < 2 || !out) return;
      const res = await fetch((window.DK_ROUTES?.search || dkUrl('api/search.php')) + `?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      out.innerHTML = (data.items || []).map(i => `<a class="chip" href="${dkUrl('resep/') + encodeURIComponent(i.slug)}">${i.title}</a>`).join(' ');
    }, 250);
  });
}
