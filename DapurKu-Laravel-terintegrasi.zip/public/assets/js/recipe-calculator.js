document.addEventListener('input', (e) => {
  const inp = e.target.closest('[data-servings]');
  if (!inp) return;
  const base = Number(inp.dataset.base || 1) || 1;
  const now = Number(inp.value) || base;
  const factor = now / base;
  document.querySelectorAll('[data-qty]').forEach((el) => {
    const q = Number(el.dataset.qty);
    if (!Number.isFinite(q)) return;
    const n = Math.round(q * factor * 10) / 10;
    el.textContent = String(n);
  });
});
