(() => {
  const start = document.getElementById('timerStart');
  const disp = document.getElementById('timerDisp');
  let t = null, left = 0;
  const fmt = (s) => {
    const m = Math.floor(s / 60), r = s % 60;
    return String(m).padStart(2, '0') + ':' + String(r).padStart(2, '0');
  };
  if (start && disp) {
    start.addEventListener('click', () => {
      const min = Number(document.getElementById('timerMin')?.value || 0);
      left = Math.max(1, Math.round(min * 60));
      clearInterval(t);
      disp.textContent = fmt(left);
      t = setInterval(() => {
        left -= 1;
        disp.textContent = fmt(Math.max(0, left));
        if (left <= 0) {
          clearInterval(t);
          disp.textContent = 'Selesai!';
          try { new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=').play(); } catch (_) {}
          alert('Timer masak selesai.');
        }
      }, 1000);
    });
    document.getElementById('timerStop')?.addEventListener('click', () => { clearInterval(t); });
  }

  const wrap = document.querySelector('[data-check-steps]');
  if (wrap) {
    const key = 'dk-steps-' + wrap.dataset.checkSteps;
    const saved = JSON.parse(localStorage.getItem(key) || '[]');
    wrap.querySelectorAll('[data-step]').forEach((cb) => {
      cb.checked = saved.includes(Number(cb.dataset.step));
      cb.addEventListener('change', () => {
        const on = [...wrap.querySelectorAll('[data-step]:checked')].map((c) => Number(c.dataset.step));
        localStorage.setItem(key, JSON.stringify(on));
      });
    });
  }

  const cal = document.querySelector('[data-cal-total]');
  const serv = document.querySelector('[data-servings]');
  if (cal && serv) {
    serv.addEventListener('input', () => {
      const n = Number(serv.value) || 1;
      cal.textContent = String(Math.round(Number(cal.dataset.cal || 0) * n));
    });
  }
})();
