/* ============================================================
   DapurKu-Pro · conveyor-belt.js
   Port vanilla dari komponen React "Sushi Conveyor Menu".

   Sabuk kaiten berbentuk stadion (loop) yang digambar sebagai
   jalur SVG; piring resep berjalan di atasnya dengan proyeksi
   pseudo-3D (jalur belakang menyusut ke `kb` dan sumbu kedalaman
   dipendekkan oleh TILT). Piring terangkat saat disorot, bisa
   dilempar (flick) dengan momentum, dan membuka dialog detail
   yang "terbang" dari posisi piring.

   Markup dirender oleh includes/conveyor-belt.php:

     <section data-conveyor data-items='[...]'>
       <div data-conveyor-stage>
         <div data-conveyor-belt>…svg…</div>
         …piring (button)…
       </div>
     </section>
   ============================================================ */
(function () {
  'use strict';

  /* ---- konstanta geometri (sama seperti komponen sumber) ---- */
  var SPACING = 1.35;
  var CURVE = 0.95;
  var BAND = 1.22;
  var TILT = 0.8;
  var SLAT = 0.34;
  var LIFT_Y = -6;          // % tinggi piring
  var LIFT_SCALE = 0.08;
  var BACK_SHADE = 0.15;
  var CHIP_ROOM = 34;       // ruang untuk chip nama di atas piring
  var WIDE = 1024;
  var HOLD = 1400;          // ms piring autoplay tetap terangkat

  var RUN = 0, SEEK = 1, DRAG = 2;

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function pad(n) { return String(n).padStart(2, '0'); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------- geometri loop stadion ---------- */

  /**
   * Posisi pada loop. `u` adalah panjang busur pada sabuk;
   * jalur depan berjalan kanan→kiri, jalur belakang kiri→kanan.
   */
  function along(g, u) {
    var s = g.s, r = g.r;
    var t = ((u % g.l) + g.l) % g.l;
    if (t < s) return { x: s / 2 - t, z: r, nx: 0, nz: 1, tx: -1, tz: 0 };
    t -= s;
    var arc = Math.PI * r;
    if (t < arc) {
      var f = t / r, sin = Math.sin(f), cos = Math.cos(f);
      return { x: -s / 2 - r * sin, z: r * cos, nx: -sin, nz: cos, tx: -cos, tz: -sin };
    }
    t -= arc;
    if (t < s) return { x: -s / 2 + t, z: -r, nx: 0, nz: -1, tx: 1, tz: 0 };
    t -= s;
    var f2 = Math.min(Math.PI, t / r), sin2 = Math.sin(f2), cos2 = Math.cos(f2);
    return { x: s / 2 + r * sin2, z: -r * cos2, nx: sin2, nz: -cos2, tx: cos2, tz: sin2 };
  }

  /** Proyeksi pseudo-perspektif: jalur belakang menyusut ke kb, kedalaman dipendekkan TILT. */
  function project(g, x, z) {
    var k = g.a + g.b * z;
    return { x: g.cx + x * k, y: g.ym + TILT * (g.a * z + (g.b * z * z) / 2), k: k };
  }

  function makeGeo(width, n, d, kb) {
    var l = Math.max(1, n) * SPACING * d;
    var r = Math.min(CURVE * d, l / (2 * Math.PI));
    var s = Math.max(0, (l - 2 * Math.PI * r) / 2);
    var g = {
      width: width, height: 0, d: d, r: r, s: s, l: l,
      pitch: l / Math.max(1, n), n: Math.max(1, n), kb: kb,
      cx: width / 2, ym: 0, a: (1 + kb) / 2, b: (1 - kb) / (2 * r),
      band: BAND * d, slats: Math.max(10, Math.round(l / (SLAT * d))),
      side: Math.max(3, d * 0.07), edgeTop: 0
    };

    var top = Infinity, bottom = -Infinity, edge = Infinity;
    for (var j = 0; j < 120; j++) {
      var p = along(g, (j / 120) * l);
      var rim = project(g, p.x + (p.nx * g.band) / 2, p.z + (p.nz * g.band) / 2);
      var plate = project(g, p.x, p.z);
      var half = (plate.k * d * TILT) / 2;
      edge = Math.min(edge, rim.y);
      top = Math.min(top, rim.y, plate.y + (LIFT_Y / 100) * half * 2 - half * (1 + LIFT_SCALE) - CHIP_ROOM);
      bottom = Math.max(bottom, rim.y + g.side + d * 0.06, plate.y + half + d * 0.08);
    }
    g.ym = Math.ceil(-top) + 2;
    g.height = Math.ceil(bottom - top) + 4;
    g.edgeTop = edge + g.ym;
    return g;
  }

  function halfSpan(g) {
    var span = 0;
    for (var j = 0; j < 120; j++) {
      var p = along(g, (j / 120) * g.l);
      var rim = project(g, p.x + (p.nx * g.band) / 2, p.z + (p.nz * g.band) / 2);
      var plate = project(g, p.x, p.z);
      span = Math.max(span,
        Math.abs(rim.x - g.cx) + 3,
        Math.abs(plate.x - g.cx) + (plate.k * g.d * (1 + LIFT_SCALE)) / 2);
    }
    return span;
  }

  function edgePath(g, offset) {
    var d = '', steps = 168;
    for (var j = 0; j < steps; j++) {
      var p = along(g, (j / steps) * g.l);
      var q = project(g, p.x + p.nx * offset, p.z + p.nz * offset);
      d += (j ? 'L' : 'M') + q.x.toFixed(1) + ' ' + q.y.toFixed(1);
    }
    return d + 'Z';
  }

  /** Sambungan slat berbentuk bulan sabit; digambar ulang tiap frame agar ikut berjalan. */
  function slatPath(g, offset, shift) {
    var half = g.band * 0.46;
    var pitch = g.l / g.slats;
    var bulge = pitch * 0.2;
    var d = '';
    for (var j = 0; j < g.slats; j++) {
      var p = along(g, offset + shift + j * pitch);
      var inner = project(g, p.x - p.nx * half, p.z - p.nz * half);
      var outer = project(g, p.x + p.nx * half, p.z + p.nz * half);
      var mid = project(g, p.x + p.tx * bulge, p.z + p.tz * bulge);
      d += 'M' + inner.x.toFixed(1) + ' ' + inner.y.toFixed(1) +
        'Q' + (2 * mid.x - (inner.x + outer.x) / 2).toFixed(1) +
        ' ' + (2 * mid.y - (inner.y + outer.y) / 2).toFixed(1) +
        ' ' + outer.x.toFixed(1) + ' ' + outer.y.toFixed(1);
    }
    return d;
  }

  function pose(g, offset, i) {
    var p = along(g, offset - i * g.pitch);
    var q = project(g, p.x, p.z);
    return { x: q.x, y: q.y, k: q.k, depth: (p.z + g.r) / (2 * g.r) };
  }

  function centerOf(g, offset) {
    return ((Math.round((offset - g.s / 2) / g.pitch) % g.n) + g.n) % g.n;
  }

  /* ---------- komponen ---------- */

  function Conveyor(section) {
    this.section = section;
    this.items = [];
    try { this.items = JSON.parse(section.dataset.items || '[]') || []; } catch (e) { this.items = []; }
    this.count = this.items.length;
    if (!this.count) return;

    this.speed = Math.max(0, parseFloat(section.dataset.speed || '26'));
    this.autoplay = section.dataset.autoplay === 'true';
    this.interval = parseInt(section.dataset.interval || '3000', 10);
    this.labels = {
      open: section.dataset.labelOpen || 'Lihat resep',
      close: section.dataset.labelClose || 'Tutup',
      previous: section.dataset.labelPrevious || 'Piring sebelumnya',
      next: section.dataset.labelNext || 'Piring berikut',
      pause: section.dataset.labelPause || 'Hentikan sabuk',
      play: section.dataset.labelPlay || 'Jalankan sabuk'
    };

    this.stage = section.querySelector('[data-conveyor-stage]');
    this.layout = section.querySelector('[data-conveyor-layout]');
    this.belt = section.querySelector('[data-conveyor-belt]');
    this.svg = section.querySelector('[data-conveyor-svg]');
    this.seam = section.querySelector('[data-conveyor-seam]');
    this.glint = section.querySelector('[data-conveyor-glint]');
    this.caption = section.querySelector('[data-conveyor-caption]');
    this.plates = [].slice.call(section.querySelectorAll('[data-dish]'));
    this.uid = 'dk' + Math.random().toString(36).slice(2, 8);

    this.sim = {
      offset: 0, v: 0, mode: RUN, target: 0,
      lift: [], vlift: [], z: [], lane: [],
      raf: 0, last: 0, visible: true, init: false, touched: false,
      l: 0, center: -1, published: '',
      px: 0, py: 0, inside: false, lock: false, lockX: 0, lockY: 0
    };
    this.pointer = { id: -1, index: -1, x: 0, y: 0, moved: false, start: 0, lane: 1, lastX: 0, lastT: 0, v: 0 };
    this.pendingOpen = -1;
    this.autoActive = null;
    this.autoLast = null;
    this.playing = this.autoplay;
    this.active = null;
    this.paused = false;
    this.openIndex = null;
    this.lifted = null;
    this.reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    this.size = { section: 0, stage: 0 };
    this.geo = null;
    this.center = 0;
    this.failed = {};

    this.build();
    this.observe();
    this.bind();
    this.measure();
  }

  /* ---------- bangun DOM dinamis ---------- */
  Conveyor.prototype.build = function () {
    var self = this;
    var g0 = null;

    // SVG sabuk
    this.svg.setAttribute('focusable', 'false');
    this.svg.innerHTML =
      '<defs>' +
        '<filter id="' + this.uid + '-soft" x="-10%" y="-30%" width="120%" height="160%">' +
          '<feGaussianBlur stdDeviation="6"/></filter>' +
        '<linearGradient id="' + this.uid + '-island" x1="0" x2="0" y1="0" y2="1">' +
          '<stop offset="0" style="stop-color:var(--island)"/>' +
          '<stop offset="1" style="stop-color:var(--island-low)"/>' +
        '</linearGradient>' +
      '</defs>' +
      '<path data-belt-shadow fill="black" class="cb-shadow" filter="url(#' + this.uid + '-soft)"/>' +
      '<path data-belt-side fill-rule="evenodd" style="fill:var(--belt-side)"/>' +
      '<path data-belt-top fill-rule="evenodd" style="fill:var(--belt)"/>' +
      '<path data-belt-seam fill="none" stroke="black" stroke-opacity=".42" stroke-linecap="round"/>' +
      '<path data-belt-glint fill="none" stroke="white" stroke-opacity=".14" stroke-linecap="round"/>' +
      '<path data-rail-outer fill="none" style="stroke:var(--rail)"/>' +
      '<path data-rail-outer-hi fill="none" stroke="white" stroke-opacity=".5"/>' +
      '<path data-rail-inner fill="none" style="stroke:var(--rail)"/>' +
      '<path data-rail-inner-hi fill="none" stroke="white" stroke-opacity=".38"/>' +
      '<path data-island-wall style="fill:var(--island-wall)"/>' +
      '<path data-island-top style="fill:url(#' + this.uid + '-island)"/>' +
      '<path data-island-hi fill="none" stroke="white" stroke-opacity=".5"/>';

    this.el = {
      shadow: this.svg.querySelector('[data-belt-shadow]'),
      side: this.svg.querySelector('[data-belt-side]'),
      top: this.svg.querySelector('[data-belt-top]'),
      seam: this.svg.querySelector('[data-belt-seam]'),
      glint: this.svg.querySelector('[data-belt-glint]'),
      railOuter: this.svg.querySelector('[data-rail-outer]'),
      railOuterHi: this.svg.querySelector('[data-rail-outer-hi]'),
      railInner: this.svg.querySelector('[data-rail-inner]'),
      railInnerHi: this.svg.querySelector('[data-rail-inner-hi]'),
      islandWall: this.svg.querySelector('[data-island-wall]'),
      islandTop: this.svg.querySelector('[data-island-top]'),
      islandHi: this.svg.querySelector('[data-island-hi]')
    };
    void g0;

    // Piring
    this.plates.forEach(function (btn, i) {
      var item = self.items[i];
      btn.innerHTML =
        '<span class="cb-plate-shadow"><span data-shadow></span></span>' +
        '<span class="cb-lift" data-lift>' +
          '<span class="cb-placeholder" data-placeholder><span></span></span>' +
          '<img class="cb-img" src="' + esc(item.image) + '" alt="" draggable="false" data-img>' +
          '<span class="cb-shade" data-shade></span>' +
          '<span class="cb-ring" data-ring></span>' +
          '<span class="cb-anchor" data-anchor><span class="cb-chip" data-chip>' +
            '<span class="cb-chip-dot" data-chip-dot></span>' +
            '<b>' + esc(item.name) + '</b>' +
            (item.labels || []).map(function (t) { return '<span>' + esc(t) + '</span>'; }).join('<i class="cb-sep">·</i>') +
          '</span></span>' +
        '</span>';
      btn._lift = btn.querySelector('[data-lift]');
      btn._shade = btn.querySelector('[data-shade]');
      btn._shadow = btn.querySelector('[data-shadow]');
      btn._anchor = btn.querySelector('[data-anchor]');
      btn._chip = btn.querySelector('[data-chip]');
      btn._img = btn.querySelector('[data-img]');
      btn._ph = btn.querySelector('[data-placeholder]');
      btn._ring = btn.querySelector('[data-ring]');
      btn._dot = btn.querySelector('[data-chip-dot]');
      btn.setAttribute('data-tier', String(item.tier || 1));
      btn.setAttribute('aria-label', item.name + (item.price ? ', ' + item.price : ''));
      btn.setAttribute('aria-haspopup', 'dialog');
      btn._img.addEventListener('error', function () {
        self.failed[item.id] = true;
        btn._img.style.display = 'none';
        btn._shade.style.display = 'none';
        btn._ph.classList.add('is-broken');
      });
    });
  };

  /* ---------- ukuran & geometri ---------- */
  Conveyor.prototype.measure = function () {
    var next = {
      section: Math.round(this.section.clientWidth),
      stage: Math.round(this.stage.clientWidth)
    };
    if (next.section === this.size.section && next.stage === this.size.stage) return;
    this.size = next;
    this.recalc();
  };

  Conveyor.prototype.recalc = function () {
    var wide = this.size.section >= WIDE;
    var narrow = this.size.section > 0 && this.size.section < 480;
    var kb = narrow ? 0.6 : 0.68;
    this.wide = wide;
    this.layout.dataset.wide = wide ? 'true' : 'false';

    if (!this.size.stage) { this.geo = null; return; }
    var span = halfSpan(makeGeo(1000, this.count, 100, kb)) / 100;
    var cap = wide ? 150 : clamp(this.size.section * 0.143, 64, 150);
    var lo = wide ? 96 : 44; // layar sempit boleh memakai piring lebih kecil
    var fit = (this.size.stage - 8) / (2 * span);
    var geo = makeGeo(this.size.stage, this.count, Math.round(clamp(fit, Math.min(lo, cap), cap)), kb);

    var changed = !this.geo || this.geo.l !== geo.l || this.geo.width !== geo.width;
    this.geo = geo;
    this.layoutStatic();
    if (changed) this.paintAll();
    if (!this.sim.init) this.init();
    else this.kick();
  };

  /** Gambar bagian sabuk yang tidak berubah tiap frame. */
  Conveyor.prototype.layoutStatic = function () {
    var g = this.geo;
    if (!g) return;
    var e = this.el;
    var outer = edgePath(g, g.band / 2);
    var inner = edgePath(g, -g.band / 2);
    var island = edgePath(g, -g.band / 2 - g.d * 0.035);

    this.stage.style.height = g.height + 'px';
    this.svg.setAttribute('width', g.width);
    this.svg.setAttribute('height', g.height);
    this.svg.setAttribute('viewBox', '0 0 ' + g.width + ' ' + g.height);

    e.shadow.setAttribute('d', outer);
    e.shadow.setAttribute('transform', 'translate(0 ' + (g.side + g.d * 0.07).toFixed(1) + ')');
    e.side.setAttribute('d', outer + inner);
    e.side.setAttribute('transform', 'translate(0 ' + g.side.toFixed(1) + ')');
    e.top.setAttribute('d', outer + inner);

    var sw1 = Math.max(1, g.d * 0.013), sw2 = Math.max(0.8, g.d * 0.009);
    e.seam.setAttribute('stroke-width', sw1);
    e.glint.setAttribute('stroke-width', sw2);

    e.railOuter.setAttribute('d', outer);
    e.railOuter.setAttribute('stroke-width', Math.max(2, g.d * 0.026));
    e.railOuterHi.setAttribute('d', outer);
    e.railOuterHi.setAttribute('stroke-width', Math.max(0.8, g.d * 0.008));
    e.railOuterHi.setAttribute('transform', 'translate(0 -0.8)');
    e.railInner.setAttribute('d', inner);
    e.railInner.setAttribute('stroke-width', Math.max(1.6, g.d * 0.02));
    e.railInnerHi.setAttribute('d', inner);
    e.railInnerHi.setAttribute('stroke-width', Math.max(0.8, g.d * 0.008));
    e.railInnerHi.setAttribute('transform', 'translate(0 -0.7)');

    e.islandWall.setAttribute('d', island);
    e.islandTop.setAttribute('d', island);
    e.islandTop.setAttribute('transform', 'translate(0 ' + (-g.side * 0.6).toFixed(1) + ')');
    e.islandHi.setAttribute('d', island);
    e.islandHi.setAttribute('transform', 'translate(0 ' + (-g.side * 0.6 - 0.6).toFixed(1) + ')');
    e.islandHi.setAttribute('stroke-width', Math.max(0.8, g.d * 0.008));
    this.svg.querySelector('feGaussianBlur').setAttribute('stdDeviation', (g.d * 0.06).toFixed(1));

    this.plates.forEach(function (btn) {
      btn.style.width = g.d + 'px';
      btn.style.height = (g.d * TILT) + 'px';
      var blur = Math.max(2, g.d * 0.045).toFixed(1);
      btn._shadow.style.filter = 'blur(' + blur + 'px)';
    });

    // Latar counter di belakang sabuk
    var counter = this.section.querySelector('[data-conveyor-counter]');
    if (counter) {
      var top = Math.max(0, g.edgeTop - g.d * 0.34);
      counter.style.top = top + 'px';
      counter.style.height = Math.max(0, g.ym - top) + 'px';
    }
  };

  /* ---------- melukis tiap frame ---------- */
  Conveyor.prototype.paintPlate = function (i) {
    var g = this.geo, s = this.sim;
    var btn = this.plates[i];
    if (!g || !btn) return;
    var q = pose(g, s.offset, i);
    var e = s.lift[i] || 0;

    btn.style.transform = 'translate3d(' + (q.x - g.d / 2).toFixed(2) + 'px,' +
      (q.y - (g.d * TILT) / 2).toFixed(2) + 'px,0) scale(' + q.k.toFixed(4) + ')';

    var z = i === this.active ? 2000 : 100 + Math.round(q.y);
    if (s.z[i] !== z) { s.z[i] = z; btn.style.zIndex = String(z); }

    var lane = q.depth >= 0.5 ? 'front' : 'back';
    if (s.lane[i] !== lane) { s.lane[i] = lane; btn.dataset.lane = lane; }

    btn._lift.style.transform = 'translateY(' + (LIFT_Y * e).toFixed(3) + '%) scale(' + (1 + LIFT_SCALE * e).toFixed(4) + ')';
    btn._shade.style.opacity = (BACK_SHADE * clamp(1 - q.depth, 0, 1) * (1 - 0.7 * clamp(e, 0, 1))).toFixed(3);
    btn._shadow.style.transform = 'translate3d(0,' + (g.d * TILT * 0.05 * e).toFixed(2) + 'px,0) scale(' + (1 + 0.14 * e).toFixed(3) + ')';
    btn._shadow.style.opacity = (1 - 0.5 * clamp(e, 0, 1)).toFixed(3);
    btn._anchor.style.transform = 'scale(' + (1 / (q.k * (1 + LIFT_SCALE * e))).toFixed(4) + ')';

    var chipOn = i === this.active && this.lifted !== i;
    if (btn._chipOn !== chipOn) { btn._chipOn = chipOn; btn._chip.classList.toggle('is-on', chipOn); }
    if (btn._active !== (i === this.active)) {
      btn._active = i === this.active;
      btn.dataset.active = btn._active ? 'true' : undefined;
      if (!btn._active) btn.removeAttribute('data-active');
    }
  };

  Conveyor.prototype.paintBelt = function () {
    var g = this.geo, s = this.sim;
    if (!g) return;
    this.el.seam.setAttribute('d', slatPath(g, s.offset, 0));
    this.el.glint.setAttribute('d', slatPath(g, s.offset, -Math.max(1.4, g.d * 0.024)));
    var v = (Math.abs(s.v) < 0.005 ? 0 : s.v).toFixed(2);
    if (v !== s.published) { s.published = v; this.belt.style.setProperty('--belt-v', v); }
    var c = centerOf(g, s.offset);
    if (c !== s.center) { s.center = c; this.center = c; }
  };

  Conveyor.prototype.paintAll = function () {
    for (var i = 0; i < this.count; i++) this.paintPlate(i);
    this.paintBelt();
  };

  /* ---------- hit-test elips ---------- */
  Conveyor.prototype.hitTest = function (px, py) {
    var g = this.geo, s = this.sim;
    if (!g) return null;
    var best = null, bestY = -Infinity;
    for (var i = 0; i < this.count; i++) {
      var q = pose(g, s.offset, i);
      var e = clamp(s.lift[i] || 0, 0, 1.2);
      var grow = (1 + LIFT_SCALE * e) * (i === this.active ? 1.1 : 1);
      var rx = (g.d * q.k * grow) / 2;
      var ry = (g.d * TILT * q.k * grow) / 2;
      var dx = (px - q.x) / rx;
      var dy = (py - (q.y + (LIFT_Y / 100) * g.d * TILT * q.k * e)) / ry;
      if (dx * dx + dy * dy > 1) continue;
      if (i === this.active) return i;
      if (q.y > bestY) { best = i; bestY = q.y; }
    }
    return best;
  };

  /* ---------- loop animasi ---------- */
  Conveyor.prototype.tick = function (now) {
    var self = this;
    var s = this.sim, g = this.geo;
    s.raf = 0;
    if (!g || !s.visible) { s.last = 0; return; }

    var dt = s.last ? clamp((now - s.last) / 1000, 0, 0.25) : 1 / 60;
    s.last = now;
    // Sub-langkah menjaga pegas tetap stabil saat frame datang terlambat.
    var steps = Math.max(1, Math.ceil(dt / 0.017));
    var h = dt / steps;
    var stopped = this.paused || this.active !== null || this.openIndex !== null;
    var cruise = this.reduced ? 0 : this.speed;

    for (var st = 0; st < steps; st++) {
      if (s.mode === SEEK) {
        var w = 5.6;
        s.v += (w * w * (s.target - s.offset) - 2 * w * s.v) * h;
        s.offset += s.v * h;
        if (Math.abs(s.target - s.offset) < 0.3 && Math.abs(s.v) < 4) { s.offset = s.target; s.v = 0; s.mode = RUN; }
      } else if (s.mode === RUN) {
        if (stopped) {
          s.v *= Math.exp(-7.2 * h);
          if (Math.abs(s.v) < 0.02) s.v = 0;
        } else {
          var e = s.v - cruise;
          if (Math.abs(e) > Math.max(6, cruise * 0.5)) {
            e = (e < 0 ? -1 : 1) * Math.max(0, Math.abs(e) * Math.exp(-2.4 * h) - 90 * h);
          } else {
            e *= Math.exp(-3.4 * h);
          }
          s.v = cruise + (Math.abs(e) < 0.01 ? 0 : e);
        }
        s.offset += s.v * h;
      }
      for (var i = 0; i < this.count; i++) {
        var goal = i === this.active ? 1 : 0;
        if (this.reduced) { s.lift[i] = goal; s.vlift[i] = 0; continue; }
        var x = s.lift[i] || 0;
        var v = (s.vlift[i] || 0) + (330 * (goal - x) - 23 * (s.vlift[i] || 0)) * h;
        s.lift[i] = x + v * h;
        s.vlift[i] = v;
      }
    }

    var busy = s.mode !== RUN || s.v !== 0 || (!stopped && cruise > 0);
    for (var j = 0; j < this.count; j++) {
      var g2 = j === this.active ? 1 : 0;
      if (Math.abs(g2 - (s.lift[j] || 0)) < 0.002 && Math.abs(s.vlift[j] || 0) < 0.02) { s.lift[j] = g2; s.vlift[j] = 0; }
      else busy = true;
    }

    if (s.inside && !s.lock && s.mode === RUN && this.openIndex === null &&
        this.pointer.id < 0 && Math.abs(s.v) > 0.3) {
      var hit = this.hitTest(s.px, s.py);
      if (hit !== null && hit !== this.active) this.hover(hit);
    }

    this.paintAll();
    if (busy) s.raf = requestAnimationFrame(function (t) { self.tick(t); });
    else s.last = 0;
  };

  Conveyor.prototype.kick = function () {
    var self = this;
    var s = this.sim;
    if (s.raf || !s.visible) return;
    s.last = 0;
    s.raf = requestAnimationFrame(function (t) { self.tick(t); });
  };

  /* ---------- state ---------- */
  Conveyor.prototype.setActive = function (next) {
    if (this.active === next) return;
    this.active = next;
    this.section.dataset.active = next === null ? '' : String(next);
    this.updateCaption();
    var roving = next === null ? this.center : next;
    this.plates.forEach(function (btn, i) { btn.tabIndex = i === roving ? 0 : -1; });
    this.kick();
  };

  Conveyor.prototype.stop = function () {
    this.playing = false;
    this.sim.touched = true;
    if (this.sim.mode === SEEK) this.sim.mode = RUN;
    var auto = this.autoActive;
    if (auto !== null) {
      this.autoActive = null;
      if (this.active === auto) this.setActive(null);
    }
  };

  Conveyor.prototype.seekTo = function (index) {
    var s = this.sim, g = this.geo;
    if (!g) return;
    var base = g.s / 2 + index * g.pitch;
    s.target = base + Math.round((s.offset - base) / g.l) * g.l;
    if (this.reduced) { s.offset = s.target; s.v = 0; s.mode = RUN; this.paintAll(); return; }
    s.mode = SEEK;
    this.kick();
  };

  Conveyor.prototype.focusVisible = function () {
    return !!this.stage.querySelector('[data-dish]:focus-visible');
  };

  Conveyor.prototype.hover = function (hit) {
    var current = this.active;
    if (hit === current) {
      // Pengunjung mengambil alih piring yang diangkat autoplay.
      if (hit !== null && this.autoActive === hit) { this.autoActive = null; this.playing = false; }
      return;
    }
    if (hit !== null) { this.stop(); this.setActive(hit); return; }
    if (current !== null && current !== this.autoActive && !this.focusVisible()) this.setActive(null);
  };

  Conveyor.prototype.go = function (index, focus) {
    if (!this.count) return;
    var next = ((index % this.count) + this.count) % this.count;
    this.stop();
    if (focus) this.plates[next].focus({ preventScroll: true });
    this.setActive(next);
    this.seekTo(next);
  };

  Conveyor.prototype.togglePause = function () {
    this.stop();
    this.paused = !this.paused;
    var btn = this.section.querySelector('[data-control="pause"]');
    if (btn) {
      btn.setAttribute('aria-pressed', this.paused ? 'true' : 'false');
      btn.setAttribute('aria-label', this.paused ? this.labels.play : this.labels.pause);
      btn.dataset.paused = this.paused ? 'true' : undefined;
      if (!this.paused) btn.removeAttribute('data-paused');
      btn.innerHTML = this.paused ? ICON_PLAY : ICON_PAUSE;
    }
    if (!this.paused && this.active !== null && !this.focusVisible() && !this.sim.inside) this.setActive(null);
    this.kick();
  };

  Conveyor.prototype.updateCaption = function () {
    if (!this.caption) return;
    var item = this.active === null ? null : this.items[this.active];
    var base = this.caption.dataset.caption || '';
    if (!item) {
      this.caption.innerHTML = '<p class="cb-caption-idle">' + esc(base) + '</p>';
      return;
    }
    this.caption.innerHTML =
      '<p class="cb-caption-now"><b>' + esc(item.name) + '</b>' +
      '<span class="cb-caption-price">' + esc(item.price) + '</span></p>' +
      (item.description ? '<p class="cb-caption-desc">' + esc(item.description) + '</p>' : '');
  };

  /* ---------- pengamat & peristiwa ---------- */
  Conveyor.prototype.observe = function () {
    var self = this;
    this.ro = new ResizeObserver(function () { self.measure(); });
    this.ro.observe(this.section);
    this.ro.observe(this.stage);

    this.io = new IntersectionObserver(function (entries) {
      var visible = entries.some(function (en) { return en.isIntersecting; }) && !document.hidden;
      if (visible === self.sim.visible) return;
      self.sim.visible = visible;
      if (visible) self.kick();
      else if (self.sim.raf) { cancelAnimationFrame(self.sim.raf); self.sim.raf = 0; self.sim.last = 0; }
    });
    this.io.observe(this.section);

    this.onVis = function () {
      var visible = !document.hidden && self.sim.visible;
      if (visible) self.kick();
      else if (self.sim.raf) { cancelAnimationFrame(self.sim.raf); self.sim.raf = 0; self.sim.last = 0; }
    };
    document.addEventListener('visibilitychange', this.onVis);

    this.mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    this.onMq = function () { self.reduced = self.mq.matches; self.kick(); };
    if (this.mq.addEventListener) this.mq.addEventListener('change', this.onMq);
  };

  Conveyor.prototype.local = function (event) {
    var box = this.stage.getBoundingClientRect();
    return { x: event.clientX - box.left, y: event.clientY - box.top };
  };

  Conveyor.prototype.bind = function () {
    var self = this;
    var s = this.sim;

    this.stage.addEventListener('pointerdown', function (event) {
      var g = self.geo;
      if (event.button !== 0 || !g) return;
      var at = self.local(event);
      var hit = self.hitTest(at.x, at.y);
      self.pendingOpen = -1;
      self.pointer = {
        id: event.pointerId, index: hit === null ? -1 : hit,
        x: event.clientX, y: event.clientY, moved: false,
        start: s.offset, lane: at.y >= g.ym ? 1 : -1,
        lastX: event.clientX, lastT: event.timeStamp, v: 0
      };
    });

    this.stage.addEventListener('pointermove', function (event) {
      var p = self.pointer, g = self.geo;
      if (!g) return;
      var at = self.local(event);
      if (event.pointerType === 'mouse') { s.px = at.x; s.py = at.y; s.inside = true; }
      if (p.id === event.pointerId) {
        var dx = event.clientX - p.x;
        var now = event.timeStamp;
        if (!p.moved && Math.abs(dx) > 6 && Math.abs(dx) > Math.abs(event.clientY - p.y)) {
          p.moved = true;
          self.stop();
          self.setActive(null);
          s.mode = DRAG;
          if (self.stage.isConnected) self.stage.setPointerCapture(event.pointerId);
        }
        if (p.moved) {
          var v = (event.clientX - p.lastX) / Math.max(1, now - p.lastT);
          p.v = p.v * 0.6 + v * 0.4;
          p.lastX = event.clientX;
          p.lastT = now;
          var scale = p.lane > 0 ? 1 : 1 / g.kb;
          s.offset = p.start - p.lane * dx * scale;
          s.v = self.reduced ? 0 : -p.lane * p.v * 1000 * scale;
          self.kick();
        }
        return;
      }
      if (event.pointerType !== 'mouse' || self.openIndex !== null) return;
      if (s.lock) {
        if (Math.hypot(at.x - s.lockX, at.y - s.lockY) < 4) return;
        s.lock = false;
      }
      self.hover(self.hitTest(at.x, at.y));
    });

    function finish(event, cancelled) {
      var p = self.pointer;
      if (p.id !== event.pointerId) return;
      var stage = self.stage;
      if (stage.hasPointerCapture && stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId);
      self.pointer = Object.assign({}, p, { id: -1 });

      if (s.mode === DRAG) {
        s.mode = RUN;
        // Diam sejenak sebelum melepas membuat flick memudar (~70 ms).
        var carry = Math.exp(-Math.max(0, event.timeStamp - p.lastT) / 70);
        s.v = self.reduced ? 0 : clamp(s.v * carry, -1400, 1400);
        if (event.pointerType === 'mouse') {
          var at = self.local(event);
          s.lock = true; s.lockX = at.x; s.lockY = at.y;
        }
        self.kick();
        return;
      }
      if (cancelled || p.moved) return;
      var touch = event.pointerType !== 'mouse';
      if (p.index < 0) {
        if (touch && self.active !== null) { self.stop(); self.setActive(null); }
        return;
      }
      self.stop();
      if (touch && self.active !== p.index) self.setActive(p.index);
      else self.pendingOpen = p.index;
    }

    this.stage.addEventListener('pointerup', function (e) { finish(e, false); });
    this.stage.addEventListener('pointercancel', function (e) { finish(e, true); });
    this.stage.addEventListener('pointerleave', function (event) {
      if (event.pointerType !== 'mouse') return;
      s.inside = false; s.lock = false;
      var current = self.active;
      if (self.pointer.id < 0 && self.openIndex === null && current !== null &&
          current !== self.autoActive && !self.focusVisible()) self.setActive(null);
    });

    this.stage.addEventListener('focusin', function (event) {
      var btn = event.target.closest ? event.target.closest('[data-dish]') : null;
      if (!btn) return;
      var i = Number(btn.dataset.dish);
      if (self.pointer.id < 0) { self.stop(); self.setActive(i); }
    });
    this.stage.addEventListener('focusout', function (event) {
      var next = event.relatedTarget;
      if ((next && self.stage.contains(next)) || self.openIndex !== null || s.inside) return;
      var current = self.active;
      if (current !== null && current !== self.autoActive) self.setActive(null);
    });

    this.plates.forEach(function (btn, i) {
      btn.addEventListener('click', function (event) {
        var pending = self.pendingOpen;
        self.pendingOpen = -1;
        // Klik papan ketik (detail 0) atau ketukan pada piring yang sudah aktif.
        if (event.detail === 0 || pending === i) self.open(i);
      });
    });

    this.stage.addEventListener('keydown', function (event) {
      if (['ArrowRight', 'ArrowLeft', 'Home', 'End'].indexOf(event.key) < 0 || !self.count) return;
      event.preventDefault();
      var own = event.target.closest && event.target.closest('[data-dish]');
      var from = own ? Number(own.dataset.dish) : (self.active === null ? self.center : self.active);
      self.go(event.key === 'Home' ? 0 : event.key === 'End' ? self.count - 1 : from + (event.key === 'ArrowRight' ? 1 : -1), true);
    });

    var prev = this.section.querySelector('[data-control="previous"]');
    var nextB = this.section.querySelector('[data-control="next"]');
    var pause = this.section.querySelector('[data-control="pause"]');
    if (prev) prev.addEventListener('click', function () { self.go((self.active === null ? s.center : self.active) - 1, false); });
    if (nextB) nextB.addEventListener('click', function () { self.go((self.active === null ? s.center : self.active) + 1, false); });
    if (pause) pause.addEventListener('click', function () { self.togglePause(); });
  };

  /* ---------- inisialisasi posisi ---------- */
  Conveyor.prototype.init = function () {
    var s = this.sim, g = this.geo;
    if (!g) return;
    if (!s.init) {
      s.init = true;
      s.offset = g.s / 2 - Math.min(this.speed * 1.62, g.pitch * 0.45);
      s.v = (this.reduced || this.paused) ? 0 : this.speed;
    } else if (s.l > 0 && s.l !== g.l) {
      var f = g.l / s.l;
      s.offset *= f;
      s.target *= f;
    }
    if (this.reduced) {
      s.v = 0;
      if (s.mode !== DRAG) s.mode = RUN;
      if (!s.touched) s.offset = g.s / 2;
    }
    s.l = g.l;
    s.z = [];
    s.lane = [];
    this.updateCaption();
    this.plates.forEach(function (btn, i) { btn.tabIndex = i === 0 ? 0 : -1; });
    this.paintAll();
    this.kick();

    if (this.playing && !this._autoStarted) { this._autoStarted = true; this.startAutoplay(); }
  };

  /* ---------- autoplay ---------- */
  Conveyor.prototype.startAutoplay = function () {
    var self = this;
    this.clearAutoplay();
    if (!this.autoplay) return;

    var show = function () {
      if (!self.playing || self.reduced || self.paused || self.openIndex !== null || !self.geo) return;
      var g = self.geo;
      var last = self.autoLast;
      var index = last === null ? centerOf(g, self.sim.offset + self.speed * 0.25) : (last + 1) % self.count;
      self.autoLast = index;
      self.autoActive = index;
      self.setActive(index);
      self.seekTo(index);
      self._autoTimer = window.setTimeout(function () {
        if (self.autoActive === index) {
          self.autoActive = null;
          if (self.active === index) self.setActive(null);
        }
        self._autoTimer = window.setTimeout(show, Math.max(300, self.interval - HOLD));
      }, HOLD);
    };

    this._autoTimer = window.setTimeout(show, this.autoLast === null ? 1600 : Math.max(300, this.interval - HOLD));
  };

  Conveyor.prototype.clearAutoplay = function () {
    if (this._autoTimer) { window.clearTimeout(this._autoTimer); this._autoTimer = 0; }
  };

  /* ---------- dialog ---------- */
  Conveyor.prototype.open = function (index) {
    var item = this.items[index];
    if (!item) return;
    this.stop();
    this.setActive(index);
    this.clearAutoplay();
    this.sim.v = 0;
    this.sim.mode = RUN;
    this.openIndex = index;
    this.paintBelt();
    this.section.dataset.open = String(index);
    this.showDialog(index);
  };

  Conveyor.prototype.closeDialog = function () {
    this.openIndex = null;
    this.section.dataset.open = '';
    this.kick();
    if (this.playing) this.startAutoplay();
  };

  Conveyor.prototype.sourceRect = function () {
    if (this.openIndex === null) return null;
    var lift = this.plates[this.openIndex] && this.plates[this.openIndex]._lift;
    return lift ? lift.getBoundingClientRect() : null;
  };

  Conveyor.prototype.showDialog = function (index) {
    var self = this;
    var item = this.items[index];
    var tier = clamp(Math.round(item.tier || 1), 1, 5);
    var from = this.sourceRect();

    var wrap = document.createElement('div');
    wrap.className = 'cb-dialog';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.setAttribute('data-tier', String(tier));
    wrap.innerHTML =
      '<div class="cb-dialog-scrim" data-close></div>' +
      '<div class="cb-dialog-card">' +
        '<button type="button" class="cb-dialog-close" data-close-btn>' + esc(this.labels.close) + ICON_CLOSE + '</button>' +
        '<div class="cb-dialog-figure" data-figure>' +
          '<span class="cb-dialog-glow"></span>' +
          '<img src="' + esc(item.image) + '" alt="' + esc(item.name) + '" draggable="false">' +
          '<span class="cb-dialog-ring"></span>' +
        '</div>' +
        '<div class="cb-dialog-body">' +
          '<p class="cb-dialog-index"><span class="cb-chip-dot"></span>' + pad(index + 1) + ' / ' + pad(this.count) + '</p>' +
          '<h3 id="' + this.uid + '-title">' + esc(item.name) + '</h3>' +
          (item.description ? '<p class="cb-dialog-desc">' + esc(item.description) + '</p>' : '') +
          ((item.details && item.details.length)
            ? '<ul class="cb-dialog-details">' + item.details.map(function (d) { return '<li>' + esc(d) + '</li>'; }).join('') + '</ul>'
            : '') +
          '<div class="cb-dialog-foot">' +
            '<p class="cb-dialog-price">' + esc((item.labels && item.labels[0]) || item.price || '') + '</p>' +
            (item.labels && item.labels.length > 1
              ? '<p class="cb-dialog-sub">' + item.labels.slice(1).map(esc).join(' · ') + '</p>' : '') +
            (item.href ? '<a class="cb-dialog-cta" href="' + esc(item.href) + '">' + esc(this.labels.open) + ICON_ARROW + '</a>' : '') +
          '</div>' +
        '</div>' +
      '</div>';
    wrap.setAttribute('aria-labelledby', this.uid + '-title');

    var overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    document.body.appendChild(wrap);
    this.lifted = index;
    this.plates[index].style.visibility = 'hidden';

    var figure = wrap.querySelector('[data-figure]');
    var closeBtn = wrap.querySelector('[data-close-btn]');
    var anim = null;

    if (figure && from && !this.reduced && from.width > 0) {
      var to = figure.getBoundingClientRect();
      var sx = from.width / to.width, sy = from.height / to.height;
      var dx = from.left + from.width / 2 - (to.left + to.width / 2);
      var dy = from.top + from.height / 2 - (to.top + to.height / 2);
      var rise = Math.min(120, Math.abs(dy) * 0.3 + 40);
      anim = figure.animate([
        { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(' + sx + ',' + sy + ')' },
        {
          transform: 'translate(' + (dx * 0.42) + 'px,' + (dy * 0.42 - rise) + 'px) scale(' +
            (((sx + 1) / 2) * 1.05) + ',' + (((sy + 1) / 2) * 1.05) + ') rotate(' + (dx > 0 ? -6 : 6) + 'deg)',
          offset: 0.5
        },
        { transform: 'none' }
      ], { duration: 680, easing: 'cubic-bezier(.22,.85,.3,1)' });
    }

    var raf = requestAnimationFrame(function () { wrap.classList.add('is-shown'); });
    closeBtn.focus({ preventScroll: true });

    var closed = false;
    var dismiss = function () {
      if (closed) return;
      closed = true;
      wrap.classList.remove('is-shown');
      var target = self.sourceRect();
      var done = function () {
        cancelAnimationFrame(raf);
        if (anim) anim.cancel();
        document.removeEventListener('keydown', onKey);
        wrap.remove();
        document.body.style.overflow = overflow;
        self.lifted = null;
        self.plates[index].style.visibility = '';
        self.plates[index].focus({ preventScroll: true });
        self.closeDialog();
      };
      if (!figure || !target || self.reduced || target.width === 0) { done(); return; }
      var f = figure.getBoundingClientRect();
      var sx2 = target.width / f.width, sy2 = target.height / f.height;
      var dx2 = target.left + target.width / 2 - (f.left + f.width / 2);
      var dy2 = target.top + target.height / 2 - (f.top + f.height / 2);
      var a2 = figure.animate([
        { transform: 'none' },
        {
          transform: 'translate(' + (dx2 * 0.58) + 'px,' + (dy2 * 0.58 - 36) + 'px) scale(' +
            ((sx2 + 1) / 2) + ',' + ((sy2 + 1) / 2) + ')',
          offset: 0.55
        },
        { transform: 'translate(' + dx2 + 'px,' + dy2 + 'px) scale(' + sx2 + ',' + sy2 + ')' }
      ], { duration: 540, easing: 'cubic-bezier(.45,0,.55,1)', fill: 'forwards' });
      a2.onfinish = done;
      a2.oncancel = done;
    };

    var onKey = function (event) {
      if (event.key === 'Escape') { event.preventDefault(); dismiss(); return; }
      if (event.key !== 'Tab') return;
      var controls = [].slice.call(wrap.querySelectorAll('a,button')).filter(function (n) { return !n.disabled; });
      var first = controls[0], last = controls[controls.length - 1];
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey);
    wrap.addEventListener('click', function (event) {
      if (event.target.closest('[data-close]')) dismiss();
    });
    this._dismiss = dismiss;
  };

  /* ---------- ikon kontrol ---------- */
  var ICON_PREV = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3.5 5.5 8l4.5 4.5"/></svg>';
  var ICON_NEXT = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3.5 10.5 8 6 12.5"/></svg>';
  var ICON_PAUSE = '<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="4" y="3" width="2.6" height="10" rx="0.8"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.8"/></svg>';
  var ICON_PLAY = '<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M5 3.4v9.2a.6.6 0 0 0 .9.5l7.4-4.6a.6.6 0 0 0 0-1L5.9 2.9a.6.6 0 0 0-.9.5Z"/></svg>';
  var ICON_CLOSE = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="M3.5 3.5l9 9M12.5 3.5l-9 9"/></svg>';
  var ICON_ARROW = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8h9.5M8.5 4l4 4-4 4"/></svg>';

  /* ---------- boot ---------- */
  function boot() {
    var nodes = document.querySelectorAll('[data-conveyor]');
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].__dkConveyor) continue;
      var c = new Conveyor(nodes[i]);
      nodes[i].__dkConveyor = c;
      if (!c.count) continue;
      // Ikon kontrol
      var prev = nodes[i].querySelector('[data-control="previous"]');
      var nextB = nodes[i].querySelector('[data-control="next"]');
      var pause = nodes[i].querySelector('[data-control="pause"]');
      if (prev) prev.innerHTML = ICON_PREV;
      if (nextB) nextB.innerHTML = ICON_NEXT;
      if (pause) pause.innerHTML = ICON_PAUSE;
      // Inisialisasi sabuk; ResizeObserver akan memicu recalc saat lebar siap.
      c.measure();
      if (c.geo) c.init();
      window.addEventListener('load', (function (cv) {
        return function () { cv.measure(); if (cv.geo && !cv.sim.init) cv.init(); };
      })(c));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.DKConveyor = Conveyor;
})();
