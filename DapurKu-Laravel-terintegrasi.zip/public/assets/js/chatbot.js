(() => {
  if (document.querySelector('.dk-chat-root')) return;
  if (typeof window.dkUrl !== 'function') {
    const p = window.location.pathname || '';
    const m = p.match(/^(.*?)\/(?:admin|resep|auth|api|profil)\b/);
    window.DK_BASE = (window.DK_BASE || (m ? m[1] : '')).replace(/\/$/, '');
    window.dkUrl = (path) => (window.DK_BASE ? window.DK_BASE + '/' : '/') + String(path).replace(/^\//, '');
  }

  const root = document.createElement('div');
  root.className = 'dk-chat-root';
  root.innerHTML = `
    <button class="dk-chat-launcher" type="button" aria-label="Buka asisten dapur">
      <span class="dk-ava">👨‍🍳</span>
      <span class="dk-launch-copy"><strong>Chef DapurKu</strong><small>Ngobrol masak di sini</small></span>
    </button>
    <section class="dk-chat-panel" role="dialog" aria-label="Asisten DapurKu">
      <header class="dk-chat-head">
        <div class="dk-head-id">
          <span class="dk-ava">👨‍🍳</span>
          <div>
            <strong>Chef DapurKu</strong>
            <small><i class="dk-dot"></i> Online · bahasa dapur</small>
          </div>
        </div>
        <button class="dk-chat-x" type="button" aria-label="Tutup">×</button>
      </header>
      <div class="dk-chat-log"></div>
      <form class="dk-chat-form">
        <input name="q" autocomplete="off" maxlength="500" placeholder="Hay Chef, bingung mau masak apa…">
        <button type="submit">Kirim</button>
      </form>
    </section>`;
  document.body.appendChild(root);

  const panel = root.querySelector('.dk-chat-panel');
  const log = root.querySelector('.dk-chat-log');
  const form = root.querySelector('.dk-chat-form');
  const input = form.querySelector('input');

  root.querySelector('.dk-chat-launcher').addEventListener('click', () => {
    panel.classList.toggle('open');
    if (panel.classList.contains('open')) input.focus();
  });
  root.querySelector('.dk-chat-x').addEventListener('click', () => panel.classList.remove('open'));

  const md = (t) => String(t || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>');

  const addMe = (text) => {
    const el = document.createElement('div');
    el.className = 'dk-bubble me';
    el.textContent = text;
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
  };

  const addBot = (data) => {
    const wrap = document.createElement('div');
    wrap.className = 'dk-bubble bot';
    wrap.innerHTML = md(data.text || data.error || 'Tidak ada jawaban.');
    if (data.recipes?.length) {
      const rec = document.createElement('div');
      rec.className = 'dk-recs';
      data.recipes.forEach((r) => {
        const a = document.createElement('a');
        a.className = 'dk-rec';
        a.href = dkUrl(r.url || ('resep/detail.php?slug=' + encodeURIComponent(r.slug || '')));
        const thumb = r.image ? `<img src="${dkUrl(r.image)}" alt="">` : '';
        a.innerHTML = `${thumb}<span><strong>${r.title}</strong><br><em>${r.cook_time || 0} mnt · ${r.difficulty || ''}</em></span>`;
        rec.appendChild(a);
      });
      wrap.appendChild(rec);
    }
    if (data.suggestions?.length) {
      const sug = document.createElement('div');
      sug.className = 'dk-sugs';
      data.suggestions.forEach((s) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = s;
        b.addEventListener('click', () => send(s));
        sug.appendChild(b);
      });
      wrap.appendChild(sug);
    }
    log.appendChild(wrap);
    log.scrollTop = log.scrollHeight;
  };

  const typing = (on) => {
    log.querySelector('.dk-typing')?.remove();
    if (!on) return;
    const t = document.createElement('div');
    t.className = 'dk-typing';
    t.textContent = 'Asisten meracik jawaban…';
    log.appendChild(t);
    log.scrollTop = log.scrollHeight;
  };

  async function send(text) {
    const q = (text || '').trim();
    if (!q) return;
    addMe(q);
    typing(true);
    try {
      const res = await fetch(dkUrl('api/chatbot.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: q }),
      });
      const data = await res.json();
      typing(false);
      addBot(data);
    } catch (err) {
      typing(false);
      addBot({ text: 'Koneksi terputus. Pastikan API `/api/chatbot.php` bisa diakses, lalu kirim ulang.' });
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const v = input.value;
    input.value = '';
    send(v);
  });

  addBot({
    text: 'Hay, aku Chef DapurKu. Bingung mau masak apa hari ini? Pencet salah satu di bawah, atau ketik bahannya.',
    suggestions: [
      'Hay Chef, bingung mau masak apa hari ini',
      'Resep rumahan yang simpel',
      'Cuma punya ayam dan telur',
      'Stok tahu dan tempe',
      'Ada sisa daging sapi',
      'Cuma ada sayuran di kulkas',
      'Kurang dari 15 menit',
      'Resep pemula, dijamin berhasil',
      'Sarapan cepat',
      'Bekal kantor yang praktis',
      'Pedas dan segar',
      'Soto buat cuaca dingin',
      'Masakan tanggal tua',
      'Jajanan pasar tradisional',
    ],
  });
})();
