async function refreshNotif() {
  const el = document.querySelector('[data-notif-count]');
  if (!el) return;
  try {
    const r = await fetch(dkUrl('api/notifications.php'));
    const d = await r.json();
    el.textContent = d.unread || 0;
  } catch (_) {}
}
refreshNotif();
