# DapurKu-Pro · versi Laravel

Port penuh aplikasi katalog resep **DapurKu-Pro** (PHP native) ke **Laravel 12/13** dengan desain yang sama:
navbar kaca-cair (liquid glass), sabuk konveyor *kaiten*, dan roda kreasi berputar.

## Menjalankan di Laragon (Windows) — tanpa Composer

Paket ini sudah menyertakan folder `vendor/`, kunci aplikasi (`.env` + APP_KEY),
dan database SQLite berisi data contoh, jadi tidak perlu `composer install`
maupun MySQL.

1. **PHP 8.3+**: ikon Laragon di tray → **PHP → Version** → pilih 8.3 / 8.4
   (cek lewat menu **Apache → Version**? tidak perlu; yang penting versi PHP).
2. Ekstrak zip ke `C:\laragon\www\DapurKu-Laravel`.
3. Buka salah satu alamat ini (semuanya berfungsi karena `.htaccess` akar
   meneruskan permintaan ke folder `public/`):
   - virtual host otomatis: `http://dapurku-laravel.test`
   - tanpa virtual host:   `http://localhost/DapurKu-Laravel`
   - atau terminal Laragon: `cd C:\laragon\www\DapurKu-Laravel && php artisan serve`
     lalu buka `http://localhost:8000`.
4. Masuk dengan akun demo di bawah. Selesai — tidak ada langkah lain.

Catatan Laragon:
- Database memakai **SQLite** (`database/database.sqlite`) yang didukung PHP
  bawaan Laragon; MySQL tidak diperlukan. Ingin reset data?
  `php artisan migrate:fresh --seed`.
- Jika virtual host `.test` tidak muncul, klik kanan ikon Laragon →
  **Reload** (atau berhenti-mulai Apache) agar `auto.dapurku-laravel.conf` dibuat.

## Menjalankan umum (server bawaan)

```bash
composer install            # hanya jika vendor/ tidak disertakan
cp .env.example .env        # jika .env belum ada
php artisan key:generate    # jika APP_KEY kosong
php artisan migrate:fresh --seed   # isi ulang dari database/legacy.sqlite
php artisan serve --host=0.0.0.0 --port=8080
```

Buka `http://localhost:8080`.

Akun demo: `admin@dapurku.pro / admin123` (admin) · `sari@dapurku.pro / user123` (pengguna).

## Yang dipindahkan dari aplikasi lama

- **Katalog publik**: beranda (banner, hero + pencarian langsung, sabuk konveyor, roda kreasi),
  daftar resep + pagination, kategori, daerah, terpopuler/terbaru/rating/mudah, resep harian,
  roulette, filter alergi, indeks bahan, detail resep (bahan berskala porsi, langkah tercentang,
  timer masak, kalkulator kalori, rating bintang, ulasan, komentar dapur, resep serupa).
- **Auth**: masuk, daftar, keluar (session database), proteksi rute favorit/ulasan/komentar.
- **API JSON**: `/api/cari` (saran pencarian), `/api/favorit` (toggle), `/api/nilai` (rating bintang)
  — dipakai `search.js`, `favorite.js`, `rating.js` lewat `window.DK_ROUTES`.
- **Komunitas & halaman statis**: komunitas (baca + tulis), tentang, kontak (tersimpan ke `messages`),
  privasi, syarat.
- **Admin** (`/admin`, middleware `admin`): dasbor (KPI, grafik kunjungan 7 hari dari tabel `visits`,
  resep per kategori, paling ramai, donat kesulitan, feed ulasan/pengguna/pesan) dan CRUD resep
  lengkap (unggah foto, bahan & langkah dari textarea per baris).
- **Data**: 52 resep, 14 kategori, 20 bahan, 4 postingan komunitas, dsb. diimpor otomatis oleh
  `DatabaseSeeder` dari `database/legacy.sqlite`.

## Struktur penting

| Path | Isi |
| --- | --- |
| `app/Http/Controllers` | Home, Recipe, Auth, Favorite, Review, Rating, Comment, Search, Community, Page, Admin\* |
| `app/Http/Middleware` | `EnsureAdmin` (alias `admin`), `TrackVisits` (isi tabel `visits`) |
| `app/Models` | 13 model Eloquent mengikuti skema lama |
| `app/Helpers.php` | `dk_icon()`, `format_minutes()`, `recipe_image()`, `region_labels()`, dll. |
| `resources/views` | Blade: `layouts/app`, `layouts/admin`, `partials/*` (navbar, konveyor, roda, kartu, sidebar, pager), halaman publik & admin |
| `public/assets` | CSS/JS desain lama apa adanya; `search/favorite/rating.js` disesuaikan ke `window.DK_ROUTES` |
| `database/migrations` | Seluruh 26 tabel aplikasi lama + kolom ekstra (`region`, `region_slug`) |
| `database/legacy.sqlite` | Sumber impor seeder |

## Belum dipindahkan (tabel tetap ada)

Rencana makan mingguan, daftar belanja, koleksi, notifikasi, dan widget chatbot tidak memiliki
halaman di versi Laravel ini; tabelnya tetap dibuat migrasi agar data lama aman.
